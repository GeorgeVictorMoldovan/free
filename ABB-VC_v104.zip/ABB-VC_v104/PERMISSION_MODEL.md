# Request Permission Model

## Overview
The Internal Application Lifecycle Portal implements a role-based permission system for request management that ensures data privacy and proper access control.

## Permission Rules

### 1. **Request Creation**
- **Default Status**: All new requests are automatically set to `PENDING` status
- **Who Can Create**: Any authenticated user with `request` permission
- **Auto-Assignment**: Requests are automatically assigned to the user who created them

### 2. **Request Visibility**

#### **Regular Users**
- Can **ONLY** see their own requests
- Cannot view requests created by other users
- Cannot filter by department or other users
- API automatically filters results to show only their requests

#### **Admin Users**
- Can see **ALL** requests from all users
- Can filter by user, department, application, etc.
- Have full visibility into the system
- Can access admin-only endpoints

### 3. **Request Status Management**

#### **User Permissions**
- **Cannot** change request status
- Can only view status changes made by admins
- Can edit their own request details (future enhancement)

#### **Admin Permissions**
- Can change request status to **ACCEPTED** or **REJECTED** only
- Cannot set other statuses (in_progress, completed, etc.)
- Must provide admin notes when changing status
- Status changes are logged with timestamp and admin ID

## API Endpoints & Permissions

### **Public Endpoints** (No Authentication)
- `GET /api/requests/stats` - General statistics (no sensitive data)
- `GET /api/requests/types` - Available request types and statuses

### **User Endpoints** (Requires Authentication)
```
GET /api/requests                    # Users see only their requests, admins see all
GET /api/requests/:id                # Users can only access their own requests
GET /api/requests/user/:userId       # Users can only access their own user ID
POST /api/requests                   # Create new request (defaults to PENDING)
```

### **Admin-Only Endpoints**
```
PUT /api/requests/:id/status         # Update status to ACCEPTED/REJECTED
DELETE /api/requests/:id             # Delete any request
GET /api/requests?userId=X           # Filter by specific user
GET /api/requests?department=X       # Filter by department
```

## Status Workflow

```
[USER CREATES REQUEST] 
        ↓
    PENDING (automatic)
        ↓
[ADMIN REVIEWS REQUEST]
        ↓
ACCEPTED  or  REJECTED (admin action only)
```

## Implementation Details

### **Frontend Changes**
- **My Requests** page for regular users (shows only their requests)
- **All Requests** page for admins (shows all requests with full filters)
- Status terminology updated from "Approved" to "Accepted"
- Request form updated to use new comprehensive data structure

### **Backend Security**
- Authentication required for all request operations
- Permission-based filtering at the API level
- Role-based access control for admin functions
- Input validation for status changes

### **User Experience**
- **Regular Users**: Simple, personal view of their requests
- **Admins**: Comprehensive management interface
- Clear visual indicators for request status
- Easy request submission process

## Error Handling

### **Access Denied Scenarios**
- User tries to access another user's request: `403 Access denied`
- User tries to change request status: `403 Insufficient permissions`
- Invalid status provided: `400 Invalid status. Only "accepted" and "rejected" are allowed`
- Request not found: `404 Request not found`

### **Authentication Errors**
- No token provided: `401 Unauthorized`
- Invalid token: `401 Invalid token`
- Expired token: `401 Token expired`

## Migration Notes

### **Status Changes**
- Old `approved` status → New `accepted` status
- All existing data updated automatically
- Frontend components updated to use new terminology

### **API Compatibility**
- Legacy endpoints still work but are deprecated
- New comprehensive endpoints are the recommended approach
- Backward compatibility maintained for existing integrations

## Security Features

1. **Data Isolation**: Users can only see their own data
2. **Role-Based Access**: Admins have elevated permissions
3. **Audit Trail**: All status changes logged with admin ID and timestamp
4. **Input Validation**: Strict validation on all inputs
5. **Permission Checks**: Every endpoint validates user permissions

## Testing

### **Test Scenarios**
1. Regular user can create requests (status = pending)
2. Regular user can only see their own requests
3. Regular user cannot access other users' requests
4. Admin can see all requests
5. Admin can change status to accepted/rejected
6. Non-admin cannot change request status
7. Invalid status changes are rejected

### **Sample Test Commands**
```bash
# Test user permissions (should fail without auth)
curl -X GET http://localhost:3001/api/requests

# Test admin status change
curl -X PUT http://localhost:3001/api/requests/1/status \
  -H "Authorization: Bearer <admin-token>" \
  -H "Content-Type: application/json" \
  -d '{"status": "accepted", "adminNotes": "Request approved"}'
```

This permission model ensures data privacy, proper access control, and a clear workflow for request management.
