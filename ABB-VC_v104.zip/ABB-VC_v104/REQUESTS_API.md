# Comprehensive Requests API Documentation

## Overview
The Internal Application Lifecycle Portal now includes a comprehensive requests system that tracks all types of requests associated with applications and users. This system replaces and extends the previous simple reuse request functionality.

## Request Types
The system supports 8 different types of requests:

### 1. **Access Requests** (`access`)
- Request access to existing applications
- Fields: `requestedAccess`, `estimatedCost`, `timeline`
- Use cases: User needs permissions, team access, role-based access

### 2. **Reuse Requests** (`reuse`)
- Request to reuse components or entire applications
- Fields: `requestedComponents`, `estimatedCost`, `timeline`
- Use cases: Code reuse, module sharing, template usage

### 3. **Support Requests** (`support`) 
- Request help, training, or issue resolution
- Fields: `issueType`, `estimatedResolutionTime`, `assignedTo`
- Use cases: Bug reports, performance issues, training needs

### 4. **Lifecycle Promotion** (`lifecycle_promotion`)
- Request to move apps between lifecycle stages
- Fields: `fromStage`, `toStage`, `requiredApprovals`
- Use cases: Dev → Test → Production promotions

### 5. **Technology Updates** (`technology_update`)
- Request to update technologies, frameworks, or dependencies
- Fields: `currentTechnology`, `proposedTechnology`, `estimatedEffort`
- Use cases: Security updates, version upgrades, migration requests

### 6. **Bug Reports** (`bug_report`)
- Report bugs and issues in applications
- Fields: `bugSeverity`, `reproducible`, `estimatedResolutionTime`
- Use cases: System errors, functional issues, data problems

### 7. **Feature Requests** (`feature_request`)
- Request new features or enhancements
- Fields: `requestedFeatures`, `estimatedEffort`
- Use cases: New functionality, UI improvements, integrations

### 8. **Feedback Requests** (`feedback`)
- Request structured feedback from users
- Fields: `feedbackType`, `responseCount`
- Use cases: User surveys, experience collection, system evaluation

## API Endpoints

### Core Endpoints

#### `GET /api/requests`
Get all requests with optional filtering
```
Query Parameters:
- type: Filter by request type
- applicationId: Filter by application ID  
- userId: Filter by user ID
- status: Filter by request status (pending, approved, rejected, etc.)
- priority: Filter by priority (low, medium, high, urgent)
- department: Filter by department
- limit: Number of results (default: 50)
- offset: Pagination offset (default: 0)
```

#### `GET /api/requests/:id`
Get specific request by ID with full details

#### `GET /api/requests/app/:applicationId`
Get all requests for a specific application

#### `GET /api/requests/user/:userId` 
Get all requests created by a specific user

#### `POST /api/requests`
Create a new request (requires authentication)
```json
{
  "type": "access|reuse|support|lifecycle_promotion|technology_update|bug_report|feature_request|feedback",
  "applicationId": 1,
  "title": "Request title",
  "description": "Detailed description",
  "businessJustification": "Why this request is needed",
  "priority": "low|medium|high|urgent",
  "timeline": "When this is needed",
  // Type-specific fields...
}
```

#### `PUT /api/requests/:id/status`
Update request status (admin only)
```json
{
  "status": "pending|approved|rejected|in_progress|completed|cancelled",
  "adminNotes": "Admin notes",
  "assignedTo": 123
}
```

### Utility Endpoints

#### `GET /api/requests/stats`
Get comprehensive statistics about all requests
```json
{
  "total": 15,
  "byType": {
    "access": 2,
    "reuse": 2,
    "support": 2,
    // ...
  },
  "byStatus": {
    "pending": 4,
    "approved": 6,
    // ...
  },
  "byPriority": {
    "high": 3,
    "medium": 7,
    // ...
  },
  "byDepartment": {
    "Engineering": 4,
    "Finance": 3,
    // ...
  }
}
```

#### `GET /api/requests/types`
Get available request types, statuses, and priorities

#### `DELETE /api/requests/:id`
Delete a request (admin only)

## Data Structure

### Request Object
```json
{
  "id": 1,
  "type": "access",
  "applicationId": 1,
  "requesterId": 2,
  "title": "Access to Customer Portal",
  "description": "Need access for support team",
  "businessJustification": "Required for customer support",
  "priority": "medium",
  "status": "pending",
  "timeline": "This week",
  "department": "Engineering",
  "requestedAt": "2024-03-02T10:30:00Z",
  "reviewedAt": null,
  "approvedBy": null,
  "assignedTo": null,
  "adminNotes": null,
  
  // Enriched data (populated by API)
  "requester": {
    "id": 2,
    "name": "Bob Smith",
    "email": "bob.smith@company.com",
    "department": "Engineering"
  },
  "application": {
    "id": 1,
    "name": "Opendaw",
    "owner": "Bob Smith",
    "lifecycle": "Production"
  },
  "approver": null,
  "assignee": null,
  
  // Type-specific fields
  "requestedAccess": ["read", "write"],
  "estimatedCost": 500
}
```

## Mock Data

The system comes with 15 pre-populated requests covering all request types:
- 2 Access requests
- 2 Reuse requests  
- 2 Support requests
- 2 Lifecycle promotion requests
- 2 Technology update requests
- 2 Bug reports
- 2 Feature requests
- 1 Feedback request

Each request includes realistic data with proper relationships to users, applications, and departments.

## Usage Examples

### Frontend Integration
```javascript
import { apiService } from '../services/api'

// Get all pending requests
const pendingRequests = await apiService.getAllRequests({ status: 'pending' })

// Get requests for specific app
const appRequests = await apiService.getRequestsByApp(applicationId)

// Submit new access request
const newRequest = await apiService.submitRequest({
  type: 'access',
  applicationId: 1,
  title: 'Portal Access Request',
  description: 'Need access for new project',
  businessJustification: 'Required for customer onboarding',
  priority: 'medium',
  timeline: 'This week',
  requestedAccess: ['read', 'write']
})

// Get request statistics
const stats = await apiService.getRequestStats()
```

### Backend Queries
```javascript
const { 
  getRequestsByType,
  getRequestsByApplication,
  getRequestsByUser,
  getRequestsByStatus,
  getRequestStats
} = require('../data/requestsData')

// Query requests by various criteria
const accessRequests = getRequestsByType('access')
const appRequests = getRequestsByApplication(1)
const userRequests = getRequestsByUser(2)
const pendingRequests = getRequestsByStatus('pending')
const statistics = getRequestStats()
```

## Authentication & Authorization

- **Read operations**: No authentication required for basic request viewing
- **Create requests**: Requires authentication (`request` permission)
- **Update status**: Requires admin permissions (`admin` role)
- **Delete requests**: Requires admin permissions (`admin` role)
- **Assign requests**: Requires admin permissions

## File Locations

- **Mock Data**: `/backend/src/data/requestsData.js`
- **API Routes**: `/backend/src/routes/requests.js`
- **Frontend Service**: `/frontend/src/services/api.js`
- **Test Script**: `/backend/test-requests.js`

## Migration from Legacy System

The new system is backward compatible with the existing reuse request functionality. Legacy endpoints continue to work while new comprehensive features are available through the new endpoints.

Old: `GET /api/requests` → Now: `GET /api/requests` (enhanced)
New: `GET /api/requests/stats`, `GET /api/requests/app/:id`, etc.
