# Internal Application Lifecycle Portal

An internal portal to track the lifecycle of ~100 applications, enabling teams to discover, reuse, and provide feedback on existing applications rather than building new ones.

## Business Purpose

**Application Inventory & Lifecycle Management**
- Track application lifecycle stages (Planning → Development → Testing → Production → Maintenance → Retired)
- Enable application discovery and reuse
- Collect feedback and ratings on usability, stability, performance
- Admin approval workflows for lifecycle transitions
- Search and request capabilities (ready for chatbot integration)

## Tech Stack

### Frontend
- React 18 with Vite
- Material UI (MUI) with custom theming
- Axios for API communication
- Advanced search and filtering

### Backend  
- Node.js with Express.js
- RESTful API design
- CORS enabled for development
- Mock data structure (ready for SQLite3 migration)

## Core Features

### 1. **Application Lifecycle Tracking**
- Visual lifecycle stages with status indicators
- Automated notifications for stage transitions
- Historical tracking and audit trail

### 2. **Feedback & Rating System**
- Multi-dimensional rating scales (usability, stability, performance, documentation)
- Comment system with threaded discussions
- Anonymous feedback options

### 3. **Admin Workflow**
- Approval gates for lifecycle transitions
- Role-based permissions (Developer, Admin, Viewer)
- Batch operations for multiple applications

### 4. **Discovery & Reuse**
- Advanced search with filters (technology, team, lifecycle stage)
- Application similarity recommendations
- Reuse request workflow

### 5. **Future Chatbot Integration**
- API endpoints structured for chatbot queries
- Natural language search capabilities
- Request and comment submission via chat

## Project Structure

```
├── backend/          # Node.js API server
│   ├── src/
│   │   ├── routes/   # API routes (apps, feedback, admin)
│   │   ├── data/     # Mock application data
│   │   └── middleware/ # Auth & permissions
│   ├── package.json
│   └── server.js
└── frontend/         # React portal
    ├── src/
    │   ├── components/ # UI components
    │   ├── pages/     # Portal pages
    │   ├── services/  # API services
    │   └── utils/     # Helper functions
    ├── package.json
    └── vite.config.js
```

## Getting Started

### Backend Setup
```bash
cd backend
npm install
npm start
```
API server: http://localhost:3001

### Frontend Setup  
```bash
cd frontend
npm install
npm run dev
```
Portal: http://localhost:5173

## Portal Pages

- **Dashboard**: Overview of applications by lifecycle stage
- **App Inventory**: Searchable catalog with filters and details
- **Feedback Hub**: Ratings, reviews, and discussions
- **Admin Panel**: Approval workflows and user management
- **Analytics**: Usage statistics and trends

## API Endpoints

```
GET  /api/applications      # Application inventory
POST /api/applications      # Register new application
PUT  /api/applications/:id  # Update application
GET  /api/feedback          # Get feedback/ratings
POST /api/feedback          # Submit feedback
GET  /api/requests          # Reuse requests
POST /api/requests          # Submit reuse request
GET  /api/admin/approvals   # Pending approvals
POST /api/admin/approve     # Approve lifecycle change
```

## License

© 2026 Internal Application Lifecycle Portal. All rights reserved.
