// Test script to demonstrate the comprehensive requests system
// Run with: node test-requests.js

const axios = require('axios');

const API_BASE = 'http://localhost:3001/api';

async function testRequestsAPI() {
  try {
    console.log('🚀 Testing Comprehensive Requests API\n');

    // Test 1: Get all requests
    console.log('1. Getting all requests...');
    const allRequests = await axios.get(`${API_BASE}/requests`);
    console.log(`   Found ${allRequests.data.data.length} total requests`);
    console.log(`   Pagination: ${JSON.stringify(allRequests.data.pagination)}\n`);

    // Test 2: Get requests by type
    console.log('2. Getting access requests...');
    const accessRequests = await axios.get(`${API_BASE}/requests?type=access`);
    console.log(`   Found ${accessRequests.data.data.length} access requests\n`);

    // Test 3: Get requests for specific application
    console.log('3. Getting requests for Application ID 1...');
    const appRequests = await axios.get(`${API_BASE}/requests/app/1`);
    console.log(`   Found ${appRequests.data.count} requests for Application ID 1`);
    if (appRequests.data.data.length > 0) {
      console.log(`   Example request: "${appRequests.data.data[0].title}"\n`);
    }

    // Test 4: Get requests by user
    console.log('4. Getting requests by User ID 2...');
    const userRequests = await axios.get(`${API_BASE}/requests/user/2`);
    console.log(`   Found ${userRequests.data.count} requests by User ID 2\n`);

    // Test 5: Get requests by status
    console.log('5. Getting pending requests...');
    const pendingRequests = await axios.get(`${API_BASE}/requests?status=pending`);
    console.log(`   Found ${pendingRequests.data.data.length} pending requests\n`);

    // Test 6: Get request statistics
    console.log('6. Getting request statistics...');
    const stats = await axios.get(`${API_BASE}/requests/stats`);
    console.log('   Request Statistics:');
    console.log(`   - Total: ${stats.data.data.total}`);
    console.log('   - By Type:', stats.data.data.byType);
    console.log('   - By Status:', stats.data.data.byStatus);
    console.log('   - By Priority:', stats.data.data.byPriority);
    console.log('   - By Department:', stats.data.data.byDepartment);
    console.log('\n');

    // Test 7: Get request types and metadata
    console.log('7. Getting available request types...');
    const types = await axios.get(`${API_BASE}/requests/types`);
    console.log('   Available types:', Object.keys(types.data.data.types));
    console.log('   Available statuses:', Object.keys(types.data.data.statuses));
    console.log('   Available priorities:', Object.keys(types.data.data.priorities));
    console.log('\n');

    // Test 8: Get specific request details
    console.log('8. Getting details for Request ID 1...');
    const requestDetails = await axios.get(`${API_BASE}/requests/1`);
    const request = requestDetails.data.data;
    console.log(`   Title: ${request.title}`);
    console.log(`   Type: ${request.type}`);
    console.log(`   Status: ${request.status}`);
    console.log(`   Requester: ${request.requester?.name || 'Unknown'}`);
    console.log(`   Application: ${request.application?.name || 'Unknown'}`);
    console.log(`   Department: ${request.department}`);
    console.log('\n');

    // Test 9: Filter by multiple criteria
    console.log('9. Getting high priority requests from Engineering department...');
    const filteredRequests = await axios.get(`${API_BASE}/requests?priority=high&department=Engineering`);
    console.log(`   Found ${filteredRequests.data.data.length} high priority Engineering requests\n`);

    // Test 10: Show request types breakdown
    console.log('10. Request Types Breakdown:');
    for (const [type, count] of Object.entries(stats.data.data.byType)) {
      console.log(`    ${type}: ${count} requests`);
    }
    console.log('\n');

    console.log('✅ All tests completed successfully!');
    console.log('\n📊 Summary:');
    console.log(`   - Total requests in system: ${stats.data.data.total}`);
    console.log(`   - Pending requests: ${stats.data.data.byStatus.pending || 0}`);
    console.log(`   - Approved requests: ${stats.data.data.byStatus.approved || 0}`);
    console.log(`   - Most active department: ${Object.entries(stats.data.data.byDepartment).sort((a,b) => b[1] - a[1])[0]?.[0] || 'None'}`);

  } catch (error) {
    console.error('❌ Error testing API:', error.response?.data || error.message);
  }
}

// Run the test
if (require.main === module) {
  testRequestsAPI();
}

module.exports = { testRequestsAPI };
