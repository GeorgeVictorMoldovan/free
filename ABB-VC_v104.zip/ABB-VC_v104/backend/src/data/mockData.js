// Mock data for Internal Application Lifecycle Portal
// This will be replaced with SQLite3 database calls in the future

// Application lifecycle stages
const LIFECYCLE_STAGES = {
  IN_DEV: 'In Dev',
  PILOT: 'Pilot',
  ACTIVE: 'Active',
  MAINTENANCE: 'Maintenance',
  RETIRING: 'Retiring',
  DEPRECATED: 'Deprecated'
};

const TECHNOLOGIES = {
  REACT: 'React',
  NODEJS: 'Node.js',
  PYTHON: 'Python',
  JAVA: 'Java',
  DOTNET: '.NET',
  ANGULAR: 'Angular',
  VUE: 'Vue.js',
  PHP: 'PHP'
};

const users = [
  {
    id: 1,
    name: "Alice Johnson",
    email: "alice.johnson@company.com",
    password: "password123", // We'll hash this in the auth route for demo
    role: "admin", // Catalog Admin - can curate and approve
    permissions: ["read", "write", "approve", "admin"],
    department: "IT Operations",
    status: "active",
    createdAt: "2024-01-15T10:30:00Z",
    lastLogin: null,
    avatar: "https://ui-avatars.com/api/?name=Alice+Johnson&background=0288d1&color=ffffff&size=150"
  },
  {
    id: 2,
    name: "Bob Smith",
    email: "bob.smith@company.com",
    password: "password123", // We'll hash this in the auth route for demo
    role: "requester", // Regular user - can discover and request
    permissions: ["read", "request", "feedback"],
    department: "Engineering", 
    status: "active",
    createdAt: "2024-02-10T14:20:00Z",
    lastLogin: null,
    avatar: "https://ui-avatars.com/api/?name=Bob+Smith&background=388e3c&color=ffffff&size=150"
  },
  {
    id: 3,
    name: "Carol Davis",
    email: "carol.davis@company.com",
    password: "password123", // We'll hash this in the auth route for demo
    role: "requester",
    permissions: ["read", "request", "feedback"],
    department: "Engineering",
    status: "active",
    createdAt: "2024-01-28T09:15:00Z",
    lastLogin: null,
    avatar: "https://ui-avatars.com/api/?name=Carol+Davis&background=f57c00&color=ffffff&size=150"
  },
  {
    id: 4,
    name: "David Wilson", 
    email: "david.wilson@company.com",
    password: "password123", // We'll hash this in the auth route for demo
    role: "requester",
    permissions: ["read", "request", "feedback"],
    department: "Business",
    status: "active",
    createdAt: "2024-02-20T16:45:00Z",
    lastLogin: null,
    avatar: "https://ui-avatars.com/api/?name=David+Wilson&background=7b1fa2&color=ffffff&size=150"
  },
  {
    id: 5,
    name: "Emma Rodriguez",
    email: "emma.rodriguez@company.com",
    password: "password123", // We'll hash this in the auth route for demo
    role: "requester",
    permissions: ["read", "request", "feedback"],
    department: "Marketing",
    status: "active",
    createdAt: "2024-02-28T11:20:00Z",
    lastLogin: null,
    avatar: "https://ui-avatars.com/api/?name=Emma+Rodriguez&background=e91e63&color=ffffff&size=150"
  }
];

const applications = [
  {
    id: 1,
    name: "Opendaw",
    description: "Your own personal AI assistant. Any OS. Any Platform. The lobster way. 💝",
    owner: "Bob Smith",
    team: "Customer Experience",
    technology: [TECHNOLOGIES.REACT, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "2.1.4",
    deploymentDate: "2024-01-15T10:30:00Z",
    lastUpdated: "2024-03-01T14:20:00Z",
    usageMetrics: {
      monthlyUsers: 15420,
      uptime: 99.8,
      performance: 850 // ms avg response time
    },
    documentation: "https://wiki.company.com/customer-portal",
    repository: "https://git.company.com/apps/customer-portal",
    dependencies: ["Auth Service", "Payment Gateway"],
    tags: ["customer-facing", "high-priority", "mobile-ready"]
  },
  {
    id: 2,
    name: "MergeWarden",
    description: "Stops \"just one more commit\" from becoming a 3-day conflict archaeology dig.",
    owner: "Carol Davis",
    team: "Supply Chain",
    technology: [TECHNOLOGIES.ANGULAR, TECHNOLOGIES.JAVA],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "3.0.1",
    deploymentDate: "2023-08-10T09:15:00Z",
    lastUpdated: "2024-02-15T11:30:00Z",
    usageMetrics: {
      monthlyUsers: 234,
      uptime: 99.5,
      performance: 420
    },
    documentation: "https://wiki.company.com/inventory-mgmt",
    repository: "https://git.company.com/apps/inventory-system",
    dependencies: ["ERP Integration", "Barcode Scanner API"],
    tags: ["internal", "warehouse", "legacy"]
  },
  {
    id: 3,
    name: "TicketTamer",
    description: "Turns vague requests into actionable tickets without summoning the Jira gods.",
    owner: "Alice Johnson",
    team: "Human Resources",
    technology: [TECHNOLOGIES.VUE, TECHNOLOGIES.PYTHON],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "1.2.0-beta",
    deploymentDate: null,
    lastUpdated: "2024-03-02T16:45:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/hr-onboarding",
    repository: "https://git.company.com/apps/hr-onboarding",
    dependencies: ["Active Directory", "Document Management"],
    tags: ["hr", "workflow", "new"]
  },
  {
    id: 4,
    name: "Deploy-O-Tron 5000",
    description: "Push to prod with fewer rituals, more guardrails, and dramatically fewer \"who approved this?\" moments.",
    owner: "David Wilson",
    team: "Finance",
    technology: [TECHNOLOGIES.REACT, TECHNOLOGIES.DOTNET],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.8.0-alpha",
    deploymentDate: null,
    lastUpdated: "2024-03-03T10:15:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/finance-dashboard",
    repository: "https://git.company.com/apps/finance-dashboard",
    dependencies: ["Financial Data API", "Chart Library"],
    tags: ["finance", "executive", "dashboards"]
  },
  {
    id: 5,
    name: "ConfigBonsai",
    description: "Trims config sprawl into something small, shaped, and less likely to fall over at 2 AM.",
    owner: "Bob Smith",
    team: "Accounting",
    technology: [TECHNOLOGIES.PHP, "MySQL"],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "1.5.2",
    deploymentDate: "2019-03-15T08:00:00Z",
    lastUpdated: "2023-12-31T23:59:59Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/legacy-invoice",
    repository: "https://git.company.com/apps/legacy-invoice",
    dependencies: [],
    tags: ["legacy", "retired", "replaced"]
  },
  {
    id: 6,
    name: "LogGoblin",
    description: "Finds the one log line you need, then pretends it was easy.",
    owner: "Carol Davis",
    team: "DevOps",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "2.1.0",
    deploymentDate: "2023-05-15T10:00:00Z",
    lastUpdated: "2024-02-01T12:00:00Z",
    usageMetrics: {
      monthlyUsers: 450,
      uptime: 99.2,
      performance: 320
    },
    documentation: "https://wiki.company.com/log-goblin",
    repository: "https://git.company.com/apps/log-goblin",
    dependencies: ["Elasticsearch", "Kibana"],
    tags: ["logging", "monitoring", "devops"]
  },
  {
    id: 7,
    name: "Onboard-O-Matic",
    description: "New team member setup in one place: accounts, access, docs, and the sacred Slack channels.",
    owner: "Alice Johnson",
    team: "HR",
    technology: [TECHNOLOGIES.REACT, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "3.2.1",
    deploymentDate: "2022-01-10T08:00:00Z",
    lastUpdated: "2023-12-15T17:00:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/onboard-matic",
    repository: "https://git.company.com/apps/onboard-matic",
    dependencies: ["Active Directory", "Slack API"],
    tags: ["hr", "onboarding", "retiring"]
  },
  {
    id: 8,
    name: "DocuDuctTape",
    description: "Sticks scattered docs together into something that looks intentional.",
    owner: "Bob Smith",
    team: "Engineering",
    technology: [TECHNOLOGIES.VUE, TECHNOLOGIES.PYTHON],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "1.8.3",
    deploymentDate: "2023-09-20T14:30:00Z",
    lastUpdated: "2024-01-15T09:30:00Z",
    usageMetrics: {
      monthlyUsers: 180,
      uptime: 97.8,
      performance: 580
    },
    documentation: "https://wiki.company.com/docu-ducttape",
    repository: "https://git.company.com/apps/docu-ducttape",
    dependencies: ["Wiki API", "Git Integration"],
    tags: ["documentation", "wiki", "knowledge"]
  },
  {
    id: 9,
    name: "IncidentBingo",
    description: "Track incidents, assign owners, and collect postmortems with fewer spreadsheets and more accountability.",
    owner: "David Wilson",
    team: "SRE",
    technology: [TECHNOLOGIES.ANGULAR, TECHNOLOGIES.JAVA],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "2.5.0",
    deploymentDate: "2023-11-01T12:00:00Z",
    lastUpdated: "2024-02-28T15:45:00Z",
    usageMetrics: {
      monthlyUsers: 95,
      uptime: 99.9,
      performance: 280
    },
    documentation: "https://wiki.company.com/incident-bingo",
    repository: "https://git.company.com/apps/incident-bingo",
    dependencies: ["PagerDuty API", "Slack Integration"],
    tags: ["incidents", "sre", "postmortem"]
  },
  {
    id: 10,
    name: "PatchyMcPatchface",
    description: "Schedules patching and updates so \"we'll do it later\" doesn't become \"we're vulnerable.\"",
    owner: "Carol Davis",
    team: "Security",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.DOTNET],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "1.9.2",
    deploymentDate: "2023-07-15T11:00:00Z",
    lastUpdated: "2024-03-01T08:30:00Z",
    usageMetrics: {
      monthlyUsers: 320,
      uptime: 99.7,
      performance: 410
    },
    documentation: "https://wiki.company.com/patchy-mcpatchface",
    repository: "https://git.company.com/apps/patchy-mcpatchface",
    dependencies: ["Patch Management API", "WSUS"],
    tags: ["security", "patching", "updates"]
  },
  {
    id: 11,
    name: "CacheWhisperer",
    description: "Speaks fluent cache and translates your slow queries into lightning-fast responses.",
    owner: "Alice Johnson",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.PYTHON],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "2.3.1",
    deploymentDate: "2024-01-20T11:00:00Z",
    lastUpdated: "2024-02-28T16:30:00Z",
    usageMetrics: {
      monthlyUsers: 750,
      uptime: 99.5,
      performance: 180
    },
    documentation: "https://wiki.company.com/cache-whisperer",
    repository: "https://git.company.com/apps/cache-whisperer",
    dependencies: ["Redis", "Database API"],
    tags: ["performance", "caching", "backend"]
  },
  {
    id: 12,
    name: "MeetingEscape",
    description: "Schedule smarter meetings or help you escape the ones that could have been emails.",
    owner: "Bob Smith",
    team: "HR",
    technology: [TECHNOLOGIES.REACT, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.1.0-beta",
    deploymentDate: "2024-02-01T14:00:00Z",
    lastUpdated: "2024-03-02T10:45:00Z",
    usageMetrics: {
      monthlyUsers: 125,
      uptime: 98.2,
      performance: 450
    },
    documentation: "https://wiki.company.com/meeting-escape",
    repository: "https://git.company.com/apps/meeting-escape",
    dependencies: ["Calendar API", "Email Service"],
    tags: ["productivity", "meetings", "scheduling"]
  },
  {
    id: 13,
    name: "DataDragon",
    description: "Hoards your data safely and breathes fire on anyone trying to access it without permission.",
    owner: "Carol Davis",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.JAVA],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "3.2.0",
    deploymentDate: "2023-12-05T09:30:00Z",
    lastUpdated: "2024-02-25T13:15:00Z",
    usageMetrics: {
      monthlyUsers: 340,
      uptime: 99.8,
      performance: 220
    },
    documentation: "https://wiki.company.com/data-dragon",
    repository: "https://git.company.com/apps/data-dragon",
    dependencies: ["Data Lake", "Auth Service"],
    tags: ["data", "security", "analytics"]
  },
  {
    id: 14,
    name: "BugZapper",
    description: "Electrifies bugs on contact and keeps your code pest-free with minimal buzzing.",
    owner: "David Wilson",
    team: "Quality Assurance",
    technology: [TECHNOLOGIES.VUE, TECHNOLOGIES.DOTNET],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "2.0.5",
    deploymentDate: "2023-10-12T15:20:00Z",
    lastUpdated: "2024-01-18T11:00:00Z",
    usageMetrics: {
      monthlyUsers: 89,
      uptime: 97.5,
      performance: 380
    },
    documentation: "https://wiki.company.com/bug-zapper",
    repository: "https://git.company.com/apps/bug-zapper",
    dependencies: ["Test Framework", "CI/CD Pipeline"],
    tags: ["testing", "qa", "automation"]
  },
  {
    id: 15,
    name: "CloudNinja",
    description: "Silently manages your cloud resources and vanishes costs you didn't know existed.",
    owner: "Alice Johnson",
    team: "Cloud Operations",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "4.1.2",
    deploymentDate: "2023-09-08T12:45:00Z",
    lastUpdated: "2024-03-01T14:30:00Z",
    usageMetrics: {
      monthlyUsers: 220,
      uptime: 99.9,
      performance: 150
    },
    documentation: "https://wiki.company.com/cloud-ninja",
    repository: "https://git.company.com/apps/cloud-ninja",
    dependencies: ["AWS API", "Cost Management"],
    tags: ["cloud", "cost-optimization", "automation"]
  },
  {
    id: 16,
    name: "TimeWizard",
    description: "Conjures accurate time tracking from thin air and makes billing disputes disappear.",
    owner: "Bob Smith",
    team: "Finance",
    technology: [TECHNOLOGIES.ANGULAR, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "1.8.7",
    deploymentDate: "2022-06-15T08:00:00Z",
    lastUpdated: "2023-11-30T17:00:00Z",
    usageMetrics: {
      monthlyUsers: 45,
      uptime: 95.2,
      performance: 680
    },
    documentation: "https://wiki.company.com/time-wizard",
    repository: "https://git.company.com/apps/time-wizard",
    dependencies: ["Payroll System", "Project API"],
    tags: ["time-tracking", "billing", "legacy"]
  },
  {
    id: 17,
    name: "SecretSafe",
    description: "Locks away your secrets tighter than your grandmother's cookie recipe.",
    owner: "Carol Davis",
    team: "Security",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.PYTHON],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "2.5.3",
    deploymentDate: "2024-01-10T10:15:00Z",
    lastUpdated: "2024-02-29T09:45:00Z",
    usageMetrics: {
      monthlyUsers: 480,
      uptime: 99.95,
      performance: 95
    },
    documentation: "https://wiki.company.com/secret-safe",
    repository: "https://git.company.com/apps/secret-safe",
    dependencies: ["HSM", "Vault API"],
    tags: ["security", "secrets", "encryption"]
  },
  {
    id: 18,
    name: "FlowMaster",
    description: "Orchestrates workflows like a symphony conductor, but with fewer hand gestures.",
    owner: "David Wilson",
    team: "Business Process",
    technology: [TECHNOLOGIES.REACT, TECHNOLOGIES.PYTHON],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.9.2-alpha",
    deploymentDate: null,
    lastUpdated: "2024-03-03T13:20:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/flow-master",
    repository: "https://git.company.com/apps/flow-master",
    dependencies: ["Workflow Engine", "Notification Service"],
    tags: ["workflow", "automation", "business-process"]
  },
  {
    id: 19,
    name: "MetricMagnet",
    description: "Attracts all your scattered metrics into one dashboard that actually makes sense.",
    owner: "Alice Johnson",
    team: "DevOps",
    technology: [TECHNOLOGIES.VUE, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "3.0.8",
    deploymentDate: "2023-11-22T16:30:00Z",
    lastUpdated: "2024-02-27T12:10:00Z",
    usageMetrics: {
      monthlyUsers: 290,
      uptime: 99.3,
      performance: 240
    },
    documentation: "https://wiki.company.com/metric-magnet",
    repository: "https://git.company.com/apps/metric-magnet",
    dependencies: ["Prometheus", "Grafana API"],
    tags: ["monitoring", "metrics", "dashboards"]
  },
  {
    id: 20,
    name: "NotificationNinja",
    description: "Delivers the right message to the right person at the right time, then vanishes without a trace.",
    owner: "Bob Smith",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.JAVA],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "1.4.9",
    deploymentDate: "2022-03-20T11:45:00Z",
    lastUpdated: "2023-10-15T14:00:00Z",
    usageMetrics: {
      monthlyUsers: 12,
      uptime: 92.1,
      performance: 520
    },
    documentation: "https://wiki.company.com/notification-ninja",
    repository: "https://git.company.com/apps/notification-ninja",
    dependencies: ["SMTP Server", "SMS Gateway"],
    tags: ["notifications", "messaging", "deprecated"]
  },
  {
    id: 21,
    name: "BugSquasher",
    description: "Hunts down bugs with relentless precision and squashes them before they can multiply.",
    owner: "Sarah Davis",
    team: "Quality Assurance", 
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "4.2.1",
    deploymentDate: "2023-08-15T09:30:00Z",
    lastUpdated: "2024-03-05T11:20:00Z",
    usageMetrics: {
      monthlyUsers: 85,
      uptime: 98.9,
      performance: 320
    },
    documentation: "https://wiki.company.com/bug-squasher",
    repository: "https://git.company.com/apps/bug-squasher",
    dependencies: ["Issue Tracker API", "Test Framework"],
    tags: ["testing", "bug-tracking", "quality"]
  },
  {
    id: 22,
    name: "CloudHopper",
    description: "Leaps effortlessly between cloud providers, making multi-cloud deployments feel like child's play.",
    owner: "Michael Chen",
    team: "Cloud Operations",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.JAVA],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.8.3",
    deploymentDate: "2024-01-10T14:45:00Z",
    lastUpdated: "2024-02-28T16:15:00Z",
    usageMetrics: {
      monthlyUsers: 45,
      uptime: 97.8,
      performance: 280
    },
    documentation: "https://wiki.company.com/cloud-hopper",
    repository: "https://git.company.com/apps/cloud-hopper",
    dependencies: ["AWS SDK", "Azure CLI", "GCP API"],
    tags: ["cloud", "deployment", "multi-cloud"]
  },
  {
    id: 23,
    name: "TimeWarpinator",
    description: "Manipulates time zones and schedules so masterfully that meetings finally make sense globally.",
    owner: "Lisa Johnson",
    team: "HR",
    technology: [TECHNOLOGIES.REACT, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "2.6.0",
    deploymentDate: "2023-06-20T10:00:00Z",
    lastUpdated: "2024-02-15T09:45:00Z",
    usageMetrics: {
      monthlyUsers: 420,
      uptime: 99.6,
      performance: 195
    },
    documentation: "https://wiki.company.com/time-warpinator",
    repository: "https://git.company.com/apps/time-warpinator",
    dependencies: ["Calendar API", "Time Zone Service"],
    tags: ["scheduling", "time-zones", "meetings"]
  },
  {
    id: 24,
    name: "CodeWhisperer",
    description: "Whispers gentle suggestions to improve your code quality without being judgmental about it.",
    owner: "David Rodriguez",
    team: "Engineering",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.9.2",
    deploymentDate: "2024-02-01T13:20:00Z",
    lastUpdated: "2024-03-03T14:30:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/code-whisperer",
    repository: "https://git.company.com/apps/code-whisperer",
    dependencies: ["Code Analysis Engine", "Git API"],
    tags: ["code-review", "quality", "development"]
  },
  {
    id: 25,
    name: "DatabaseDoctor",
    description: "Diagnoses database ailments and prescribes performance remedies with excellent bedside manner.",
    owner: "Jennifer Wilson",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.PYTHON],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "3.4.7",
    deploymentDate: "2023-04-12T11:15:00Z",
    lastUpdated: "2024-02-20T15:40:00Z",
    usageMetrics: {
      monthlyUsers: 67,
      uptime: 99.2,
      performance: 310
    },
    documentation: "https://wiki.company.com/database-doctor",
    repository: "https://git.company.com/apps/database-doctor",
    dependencies: ["Database Monitoring API", "Performance Analytics"],
    tags: ["database", "performance", "monitoring"]
  },
  {
    id: 26,
    name: "SlackSlacker",
    description: "Automates all the boring Slack stuff so you can focus on the important conversations.",
    owner: "Robert Brown",
    team: "Business Process",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "2.1.4",
    deploymentDate: "2023-09-08T08:25:00Z",
    lastUpdated: "2024-01-18T12:50:00Z",
    usageMetrics: {
      monthlyUsers: 156,
      uptime: 98.7,
      performance: 350
    },
    documentation: "https://wiki.company.com/slack-slacker",
    repository: "https://git.company.com/apps/slack-slacker",
    dependencies: ["Slack API", "Bot Framework"],
    tags: ["automation", "communication", "slack"]
  },
  {
    id: 27,
    name: "PasswordPal",
    description: "Your friendly neighborhood password manager that remembers everything so you don't have to.",
    owner: "Amanda Taylor",
    team: "Security",
    technology: [TECHNOLOGIES.DOTNET, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "5.1.2",
    deploymentDate: "2023-01-25T16:00:00Z",
    lastUpdated: "2024-02-29T10:35:00Z",
    usageMetrics: {
      monthlyUsers: 890,
      uptime: 99.8,
      performance: 120
    },
    documentation: "https://wiki.company.com/password-pal",
    repository: "https://git.company.com/apps/password-pal",
    dependencies: ["Encryption Library", "LDAP"],
    tags: ["security", "passwords", "authentication"]
  },
  {
    id: 28,
    name: "FileFinderPro",
    description: "Finds files faster than you can say 'where did I put that document' and organizes them beautifully.",
    owner: "Christopher Lee",
    team: "Engineering",
    technology: [TECHNOLOGIES.ANGULAR, TECHNOLOGIES.JAVA],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "1.9.8",
    deploymentDate: "2022-11-14T13:45:00Z",
    lastUpdated: "2023-12-20T08:15:00Z",
    usageMetrics: {
      monthlyUsers: 23,
      uptime: 96.4,
      performance: 450
    },
    documentation: "https://wiki.company.com/file-finder-pro",
    repository: "https://git.company.com/apps/file-finder-pro",
    dependencies: ["Search Index", "File System API"],
    tags: ["file-management", "search", "legacy"]
  },
  {
    id: 29,
    name: "MeetingMaster",
    description: "Masters the art of productive meetings by keeping everyone on track and on time.",
    owner: "Patricia Garcia",
    team: "HR",
    technology: [TECHNOLOGIES.VUE, TECHNOLOGIES.PYTHON],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.3.1",
    deploymentDate: "2024-01-30T12:00:00Z",
    lastUpdated: "2024-03-01T14:25:00Z",
    usageMetrics: {
      monthlyUsers: 78,
      uptime: 98.1,
      performance: 220
    },
    documentation: "https://wiki.company.com/meeting-master",
    repository: "https://git.company.com/apps/meeting-master",
    dependencies: ["Calendar Integration", "Video Conference API"],
    tags: ["meetings", "productivity", "scheduling"]
  },
  {
    id: 30,
    name: "APIAdventurer",
    description: "Explores the wild frontier of APIs and brings back valuable integration treasures.",
    owner: "Kevin Martinez",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.PYTHON],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "2.8.5",
    deploymentDate: "2023-07-18T15:20:00Z",
    lastUpdated: "2024-02-25T11:10:00Z",
    usageMetrics: {
      monthlyUsers: 134,
      uptime: 99.1,
      performance: 285
    },
    documentation: "https://wiki.company.com/api-adventurer",
    repository: "https://git.company.com/apps/api-adventurer",
    dependencies: ["API Gateway", "Authentication Service"],
    tags: ["api", "integration", "platform"]
  },
  // Additional 70 applications for balanced lifecycle distribution
  {
    id: 31,
    name: "ServerSheriff",
    description: "Keeps your servers in line with unwavering vigilance and a badge of honor.",
    owner: "Thomas Anderson",
    team: "SRE",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "3.7.2",
    deploymentDate: "2023-05-10T14:20:00Z",
    lastUpdated: "2024-02-18T09:45:00Z",
    usageMetrics: {
      monthlyUsers: 145,
      uptime: 99.4,
      performance: 210
    },
    documentation: "https://wiki.company.com/server-sheriff",
    repository: "https://git.company.com/apps/server-sheriff",
    dependencies: ["Monitoring Stack", "Alert Manager"],
    tags: ["monitoring", "server-management", "infrastructure"]
  },
  {
    id: 32,
    name: "WorkflowWizard",
    description: "Conjures efficient workflows from the chaos of business processes with magical precision.",
    owner: "Emma Watson",
    team: "Business Process",
    technology: [TECHNOLOGIES.ANGULAR, TECHNOLOGIES.DOTNET],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.4.5",
    deploymentDate: "2024-01-15T10:30:00Z",
    lastUpdated: "2024-02-28T13:15:00Z",
    usageMetrics: {
      monthlyUsers: 67,
      uptime: 98.2,
      performance: 340
    },
    documentation: "https://wiki.company.com/workflow-wizard",
    repository: "https://git.company.com/apps/workflow-wizard",
    dependencies: ["Workflow Engine", "Process Manager"],
    tags: ["workflow", "business-process", "automation"]
  },
  {
    id: 33,
    name: "DocumentDruid",
    description: "Channels ancient wisdom to organize and preserve your documents for future generations.",
    owner: "Oliver Stone",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.8.1",
    deploymentDate: "2024-02-05T16:45:00Z",
    lastUpdated: "2024-03-02T11:20:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/document-druid",
    repository: "https://git.company.com/apps/document-druid",
    dependencies: ["Document Store", "Search Engine"],
    tags: ["document-management", "search", "knowledge-base"]
  },
  {
    id: 34,
    name: "SecuritySentry",
    description: "Guards your digital fortress with vigilant eyes and an impenetrable shield of protection.",
    owner: "Diana Prince",
    team: "Security",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "4.2.8",
    deploymentDate: "2022-09-12T08:15:00Z",
    lastUpdated: "2024-01-22T14:50:00Z",
    usageMetrics: {
      monthlyUsers: 234,
      uptime: 99.8,
      performance: 150
    },
    documentation: "https://wiki.company.com/security-sentry",
    repository: "https://git.company.com/apps/security-sentry",
    dependencies: ["LDAP", "Security Scanner"],
    tags: ["security", "authentication", "monitoring"]
  },
  {
    id: 35,
    name: "TaskTornado",
    description: "Whirls through your to-do list with devastating efficiency, leaving completion in its wake.",
    owner: "Bruce Wayne",
    team: "Engineering",
    technology: [TECHNOLOGIES.REACT, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "2.9.4",
    deploymentDate: "2022-04-18T12:30:00Z",
    lastUpdated: "2023-11-15T10:25:00Z",
    usageMetrics: {
      monthlyUsers: 34,
      uptime: 95.6,
      performance: 480
    },
    documentation: "https://wiki.company.com/task-tornado",
    repository: "https://git.company.com/apps/task-tornado",
    dependencies: ["Task Queue", "Notification Service"],
    tags: ["task-management", "productivity", "legacy"]
  },
  {
    id: 36,
    name: "NetworkNinja",
    description: "Moves through network infrastructure with stealth and precision, striking configuration issues silently.",
    owner: "Clark Kent",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "1.7.2",
    deploymentDate: "2021-11-20T09:45:00Z",
    lastUpdated: "2023-08-10T15:30:00Z",
    usageMetrics: {
      monthlyUsers: 8,
      uptime: 89.2,
      performance: 620
    },
    documentation: "https://wiki.company.com/network-ninja",
    repository: "https://git.company.com/apps/network-ninja",
    dependencies: ["SNMP Library", "Network Discovery"],
    tags: ["network", "infrastructure", "deprecated"]
  },
  {
    id: 37,
    name: "DataDetective",
    description: "Investigates data mysteries with keen analytical skills and uncovers hidden insights.",
    owner: "Natasha Romanoff",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.JAVA],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "2.5.6",
    deploymentDate: "2023-03-25T11:00:00Z",
    lastUpdated: "2024-02-20T16:40:00Z",
    usageMetrics: {
      monthlyUsers: 189,
      uptime: 98.9,
      performance: 295
    },
    documentation: "https://wiki.company.com/data-detective",
    repository: "https://git.company.com/apps/data-detective",
    dependencies: ["Data Warehouse", "Analytics Engine"],
    tags: ["data-analysis", "business-intelligence", "reporting"]
  },
  {
    id: 38,
    name: "CloudCustodian",
    description: "Maintains pristine cloud environments with meticulous care and organizational excellence.",
    owner: "Steve Rogers",
    team: "Cloud Operations",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.2.3",
    deploymentDate: "2024-01-08T13:25:00Z",
    lastUpdated: "2024-02-25T10:15:00Z",
    usageMetrics: {
      monthlyUsers: 52,
      uptime: 97.5,
      performance: 380
    },
    documentation: "https://wiki.company.com/cloud-custodian",
    repository: "https://git.company.com/apps/cloud-custodian",
    dependencies: ["Cloud API", "Resource Manager"],
    tags: ["cloud", "resource-management", "cleanup"]
  },
  {
    id: 39,
    name: "MessageMaestro",
    description: "Conducts symphonies of communication across all channels with perfect timing and harmony.",
    owner: "Tony Stark",
    team: "Business Process",
    technology: [TECHNOLOGIES.DOTNET, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.6.8",
    deploymentDate: "2024-02-12T15:50:00Z",
    lastUpdated: "2024-03-01T09:30:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/message-maestro",
    repository: "https://git.company.com/apps/message-maestro",
    dependencies: ["Message Queue", "Notification Hub"],
    tags: ["messaging", "communication", "orchestration"]
  },
  {
    id: 40,
    name: "TestTitan",
    description: "Crushes bugs with the strength of a thousand test cases and never surrenders to defects.",
    owner: "Peter Parker",
    team: "Quality Assurance",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "3.1.9",
    deploymentDate: "2023-01-15T08:20:00Z",
    lastUpdated: "2024-01-30T12:45:00Z",
    usageMetrics: {
      monthlyUsers: 78,
      uptime: 98.7,
      performance: 325
    },
    documentation: "https://wiki.company.com/test-titan",
    repository: "https://git.company.com/apps/test-titan",
    dependencies: ["Test Framework", "CI/CD Pipeline"],
    tags: ["testing", "quality-assurance", "automation"]
  },
  {
    id: 41,
    name: "ConfigCommander",
    description: "Commands configuration files with military precision and maintains order across all environments.",
    owner: "Wade Wilson",
    team: "DevOps",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "2.4.1",
    deploymentDate: "2022-08-10T14:15:00Z",
    lastUpdated: "2023-12-05T16:20:00Z",
    usageMetrics: {
      monthlyUsers: 28,
      uptime: 94.3,
      performance: 510
    },
    documentation: "https://wiki.company.com/config-commander",
    repository: "https://git.company.com/apps/config-commander",
    dependencies: ["Configuration Store", "Deployment Tools"],
    tags: ["configuration", "deployment", "environment-management"]
  },
  {
    id: 42,
    name: "LogLumberjack",
    description: "Chops through massive log forests to find the exact tree of information you need.",
    owner: "Scott Lang",
    team: "SRE",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "1.8.5",
    deploymentDate: "2021-06-14T10:40:00Z",
    lastUpdated: "2023-05-22T11:55:00Z",
    usageMetrics: {
      monthlyUsers: 12,
      uptime: 87.9,
      performance: 650
    },
    documentation: "https://wiki.company.com/log-lumberjack",
    repository: "https://git.company.com/apps/log-lumberjack",
    dependencies: ["Log Aggregator", "Search Index"],
    tags: ["logging", "monitoring", "deprecated"]
  },
  {
    id: 43,
    name: "InventoryIllusionist",
    description: "Makes inventory management appear effortless with sleight of hand and magical organization.",
    owner: "Wanda Maximoff",
    team: "Supply Chain",
    technology: [TECHNOLOGIES.VUE, TECHNOLOGIES.PYTHON],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "4.1.2",
    deploymentDate: "2023-07-08T09:15:00Z",
    lastUpdated: "2024-02-14T14:25:00Z",
    usageMetrics: {
      monthlyUsers: 312,
      uptime: 99.1,
      performance: 220
    },
    documentation: "https://wiki.company.com/inventory-illusionist",
    repository: "https://git.company.com/apps/inventory-illusionist",
    dependencies: ["Inventory Database", "Barcode Scanner"],
    tags: ["inventory", "supply-chain", "warehouse"]
  },
  {
    id: 44,
    name: "BackupButler",
    description: "Serves your data protection needs with impeccable service and never forgets a backup.",
    owner: "Alfred Pennyworth",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.7.4",
    deploymentDate: "2024-01-20T12:00:00Z",
    lastUpdated: "2024-02-27T15:30:00Z",
    usageMetrics: {
      monthlyUsers: 89,
      uptime: 99.6,
      performance: 180
    },
    documentation: "https://wiki.company.com/backup-butler",
    repository: "https://git.company.com/apps/backup-butler",
    dependencies: ["Backup Storage", "Scheduler Service"],
    tags: ["backup", "data-protection", "disaster-recovery"]
  },
  {
    id: 45,
    name: "PerformancePaladin",
    description: "Champions system performance with noble dedication and fights against sluggishness.",
    owner: "Barry Allen",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.9.7",
    deploymentDate: "2024-02-18T11:45:00Z",
    lastUpdated: "2024-03-03T08:15:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/performance-paladin",
    repository: "https://git.company.com/apps/performance-paladin",
    dependencies: ["Performance Monitor", "Profiling Tools"],
    tags: ["performance", "optimization", "monitoring"]
  },
  {
    id: 46,
    name: "EmailEngineer",
    description: "Constructs perfect email delivery systems with precision engineering and reliable transmission.",
    owner: "Pepper Potts",
    team: "Business Process",
    technology: [TECHNOLOGIES.DOTNET, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "2.8.3",
    deploymentDate: "2022-12-01T13:40:00Z",
    lastUpdated: "2024-01-12T10:25:00Z",
    usageMetrics: {
      monthlyUsers: 567,
      uptime: 99.7,
      performance: 160
    },
    documentation: "https://wiki.company.com/email-engineer",
    repository: "https://git.company.com/apps/email-engineer",
    dependencies: ["SMTP Server", "Template Engine"],
    tags: ["email", "communication", "notifications"]
  },
  {
    id: 47,
    name: "ReportRanger",
    description: "Ranges far and wide through data wilderness to gather intelligence and deliver comprehensive reports.",
    owner: "Carol Danvers",
    team: "Finance",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "3.5.2",
    deploymentDate: "2022-05-25T16:20:00Z",
    lastUpdated: "2023-10-18T14:10:00Z",
    usageMetrics: {
      monthlyUsers: 45,
      uptime: 96.8,
      performance: 420
    },
    documentation: "https://wiki.company.com/report-ranger",
    repository: "https://git.company.com/apps/report-ranger",
    dependencies: ["Reporting Engine", "Data Warehouse"],
    tags: ["reporting", "business-intelligence", "analytics"]
  },
  {
    id: 48,
    name: "IntegrationImp",
    description: "Playfully connects disparate systems with mischievous cleverness and surprising effectiveness.",
    owner: "Loki Laufeyson",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "1.3.8",
    deploymentDate: "2021-09-30T07:55:00Z",
    lastUpdated: "2023-07-14T13:20:00Z",
    usageMetrics: {
      monthlyUsers: 5,
      uptime: 85.4,
      performance: 720
    },
    documentation: "https://wiki.company.com/integration-imp",
    repository: "https://git.company.com/apps/integration-imp",
    dependencies: ["Message Bus", "Transformation Engine"],
    tags: ["integration", "middleware", "deprecated"]
  },
  {
    id: 49,
    name: "ValidationVanguard",
    description: "Leads the charge against invalid data with unwavering standards and protective vigilance.",
    owner: "T'Challa",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "3.2.1",
    deploymentDate: "2023-09-12T10:30:00Z",
    lastUpdated: "2024-02-22T12:50:00Z",
    usageMetrics: {
      monthlyUsers: 198,
      uptime: 98.8,
      performance: 250
    },
    documentation: "https://wiki.company.com/validation-vanguard",
    repository: "https://git.company.com/apps/validation-vanguard",
    dependencies: ["Validation Rules Engine", "Data Quality Tools"],
    tags: ["data-validation", "quality-control", "governance"]
  },
  {
    id: 50,
    name: "DeploymentDragon",
    description: "Breathes fire into deployment pipelines and guards treasured applications with fierce protection.",
    owner: "Nick Fury",
    team: "DevOps",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.5.9",
    deploymentDate: "2024-01-25T09:10:00Z",
    lastUpdated: "2024-02-29T11:35:00Z",
    usageMetrics: {
      monthlyUsers: 73,
      uptime: 98.4,
      performance: 310
    },
    documentation: "https://wiki.company.com/deployment-dragon",
    repository: "https://git.company.com/apps/deployment-dragon",
    dependencies: ["CI/CD Platform", "Container Registry"],
    tags: ["deployment", "ci-cd", "automation"]
  },
  {
    id: 51,
    name: "ScheduleSorcerer",
    description: "Weaves magical scheduling spells that make impossible meetings possible and conflicts disappear.",
    owner: "Stephen Strange",
    team: "HR",
    technology: [TECHNOLOGIES.VUE, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.7.3",
    deploymentDate: "2024-02-22T14:15:00Z",
    lastUpdated: "2024-03-04T16:40:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/schedule-sorcerer",
    repository: "https://git.company.com/apps/schedule-sorcerer",
    dependencies: ["Calendar Service", "Availability Engine"],
    tags: ["scheduling", "calendar", "resource-planning"]
  },
  {
    id: 52,
    name: "AnalyticsAlchemist",
    description: "Transforms raw data into golden insights through mysterious analytical processes and formulas.",
    owner: "Bruce Banner",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "4.7.6",
    deploymentDate: "2022-10-15T11:25:00Z",
    lastUpdated: "2024-01-28T13:15:00Z",
    usageMetrics: {
      monthlyUsers: 256,
      uptime: 99.3,
      performance: 195
    },
    documentation: "https://wiki.company.com/analytics-alchemist",
    repository: "https://git.company.com/apps/analytics-alchemist",
    dependencies: ["Analytics Platform", "Data Warehouse"],
    tags: ["analytics", "data-science", "machine-learning"]
  },
  {
    id: 53,
    name: "FormFighter",
    description: "Battles complex form requirements with heroic determination and user-friendly design.",
    owner: "Matt Murdock",
    team: "Customer Experience",
    technology: [TECHNOLOGIES.REACT, TECHNOLOGIES.DOTNET],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "2.6.4",
    deploymentDate: "2022-07-20T15:50:00Z",
    lastUpdated: "2023-11-25T09:40:00Z",
    usageMetrics: {
      monthlyUsers: 67,
      uptime: 95.2,
      performance: 460
    },
    documentation: "https://wiki.company.com/form-fighter",
    repository: "https://git.company.com/apps/form-fighter",
    dependencies: ["Form Builder", "Validation Service"],
    tags: ["forms", "user-interface", "data-collection"]
  },
  {
    id: 54,
    name: "CacheCommander",
    description: "Commands caching strategies with tactical brilliance and delivers lightning-fast response times.",
    owner: "Sam Wilson",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "1.9.2",
    deploymentDate: "2021-12-08T12:35:00Z",
    lastUpdated: "2023-09-12T14:55:00Z",
    usageMetrics: {
      monthlyUsers: 18,
      uptime: 91.7,
      performance: 580
    },
    documentation: "https://wiki.company.com/cache-commander",
    repository: "https://git.company.com/apps/cache-commander",
    dependencies: ["Redis Cluster", "Cache Manager"],
    tags: ["caching", "performance", "deprecated"]
  },
  {
    id: 55,
    name: "NotificationNomad",
    description: "Roams across communication channels to deliver messages wherever users journey in their digital travels.",
    owner: "Jessica Jones",
    team: "Business Process",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "2.3.7",
    deploymentDate: "2023-04-18T08:45:00Z",
    lastUpdated: "2024-02-16T10:20:00Z",
    usageMetrics: {
      monthlyUsers: 423,
      uptime: 99.2,
      performance: 185
    },
    documentation: "https://wiki.company.com/notification-nomad",
    repository: "https://git.company.com/apps/notification-nomad",
    dependencies: ["Push Service", "SMS Gateway"],
    tags: ["notifications", "messaging", "multi-channel"]
  },
  {
    id: 56,
    name: "ErrorExorcist",
    description: "Banishes bugs and errors from applications with ritualistic debugging and supernatural precision.",
    owner: "Constantine",
    team: "Quality Assurance",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.1.8",
    deploymentDate: "2024-01-30T16:25:00Z",
    lastUpdated: "2024-02-28T12:10:00Z",
    usageMetrics: {
      monthlyUsers: 41,
      uptime: 97.9,
      performance: 350
    },
    documentation: "https://wiki.company.com/error-exorcist",
    repository: "https://git.company.com/apps/error-exorcist",
    dependencies: ["Error Tracking", "Debug Tools"],
    tags: ["debugging", "error-handling", "troubleshooting"]
  },
  {
    id: 57,
    name: "AuthenticationArcher",
    description: "Never misses the target when shooting down unauthorized access attempts with pinpoint accuracy.",
    owner: "Kate Bishop",
    team: "Security",
    technology: [TECHNOLOGIES.DOTNET, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.5.4",
    deploymentDate: "2024-02-25T13:50:00Z",
    lastUpdated: "2024-03-04T15:25:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/authentication-archer",
    repository: "https://git.company.com/apps/authentication-archer",
    dependencies: ["OAuth Provider", "Identity Service"],
    tags: ["authentication", "security", "identity-management"]
  },
  {
    id: 58,
    name: "MetricsMiner",
    description: "Digs deep into data mines to extract valuable performance gems and statistical treasures.",
    owner: "Luke Cage",
    team: "DevOps",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "3.4.5",
    deploymentDate: "2023-02-14T10:15:00Z",
    lastUpdated: "2024-01-20T14:30:00Z",
    usageMetrics: {
      monthlyUsers: 167,
      uptime: 98.6,
      performance: 275
    },
    documentation: "https://wiki.company.com/metrics-miner",
    repository: "https://git.company.com/apps/metrics-miner",
    dependencies: ["Metrics Collector", "Time Series DB"],
    tags: ["metrics", "monitoring", "performance-analysis"]
  },
  {
    id: 59,
    name: "WorkflowWarden",
    description: "Guards business processes with steadfast dedication and ensures workflows never stray from their path.",
    owner: "Danny Rand",
    team: "Business Process",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "2.7.1",
    deploymentDate: "2022-06-28T09:20:00Z",
    lastUpdated: "2023-12-15T11:45:00Z",
    usageMetrics: {
      monthlyUsers: 56,
      uptime: 94.8,
      performance: 490
    },
    documentation: "https://wiki.company.com/workflow-warden",
    repository: "https://git.company.com/apps/workflow-warden",
    dependencies: ["Workflow Engine", "Process Monitor"],
    tags: ["workflow", "business-process", "governance"]
  },
  {
    id: 60,
    name: "DataDruidess",
    description: "Nurtures data ecosystems with natural wisdom and helps information grow into valuable insights.",
    owner: "Poison Ivy",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "1.6.7",
    deploymentDate: "2021-08-12T14:40:00Z",
    lastUpdated: "2023-06-20T16:15:00Z",
    usageMetrics: {
      monthlyUsers: 9,
      uptime: 88.3,
      performance: 680
    },
    documentation: "https://wiki.company.com/data-druidess",
    repository: "https://git.company.com/apps/data-druidess",
    dependencies: ["Data Pipeline", "ETL Tools"],
    tags: ["data-processing", "etl", "deprecated"]
  },
  {
    id: 61,
    name: "ConfigurationCrusader",
    description: "Crusades against configuration chaos with righteous determination and systematic organization.",
    owner: "Hal Jordan",
    team: "DevOps",
    technology: [TECHNOLOGIES.VUE, TECHNOLOGIES.PYTHON],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "3.8.9",
    deploymentDate: "2023-08-05T12:10:00Z",
    lastUpdated: "2024-02-24T09:35:00Z",
    usageMetrics: {
      monthlyUsers: 198,
      uptime: 99.0,
      performance: 230
    },
    documentation: "https://wiki.company.com/configuration-crusader",
    repository: "https://git.company.com/apps/configuration-crusader",
    dependencies: ["Config Store", "Version Control"],
    tags: ["configuration", "environment-management", "deployment"]
  },
  {
    id: 62,
    name: "HealthcheckHero",
    description: "Monitors application vitals with heroic vigilance and rushes to the rescue when systems fall ill.",
    owner: "Jean Grey",
    team: "SRE",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.3.2",
    deploymentDate: "2024-02-01T11:55:00Z",
    lastUpdated: "2024-03-01T13:40:00Z",
    usageMetrics: {
      monthlyUsers: 85,
      uptime: 98.7,
      performance: 290
    },
    documentation: "https://wiki.company.com/healthcheck-hero",
    repository: "https://git.company.com/apps/healthcheck-hero",
    dependencies: ["Health Monitor", "Alert System"],
    tags: ["health-monitoring", "system-status", "alerting"]
  },
  {
    id: 63,
    name: "DocumentDynamo",
    description: "Powers through document processing with explosive energy and electrifying efficiency.",
    owner: "Ororo Munroe",
    team: "Finance",
    technology: [TECHNOLOGIES.DOTNET, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.4.6",
    deploymentDate: "2024-03-01T08:30:00Z",
    lastUpdated: "2024-03-05T10:15:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/document-dynamo",
    repository: "https://git.company.com/apps/document-dynamo",
    dependencies: ["Document Parser", "OCR Service"],
    tags: ["document-processing", "automation", "ocr"]
  },
  {
    id: 64,
    name: "SecuritySamurai",
    description: "Defends applications with ancient warrior wisdom and modern cybersecurity techniques.",
    owner: "Elektra Natchios",
    team: "Security",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "2.9.8",
    deploymentDate: "2023-01-08T15:20:00Z",
    lastUpdated: "2024-01-25T11:50:00Z",
    usageMetrics: {
      monthlyUsers: 134,
      uptime: 99.5,
      performance: 205
    },
    documentation: "https://wiki.company.com/security-samurai",
    repository: "https://git.company.com/apps/security-samurai",
    dependencies: ["Security Scanner", "Threat Database"],
    tags: ["security", "vulnerability-scanning", "threat-detection"]
  },
  {
    id: 65,
    name: "LoadBalancerLord",
    description: "Rules over traffic distribution with sovereign authority and ensures perfect balance across realms.",
    owner: "Reed Richards",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "4.2.3",
    deploymentDate: "2022-03-15T10:45:00Z",
    lastUpdated: "2023-10-30T14:25:00Z",
    usageMetrics: {
      monthlyUsers: 89,
      uptime: 96.4,
      performance: 380
    },
    documentation: "https://wiki.company.com/load-balancer-lord",
    repository: "https://git.company.com/apps/load-balancer-lord",
    dependencies: ["Load Balancer", "Health Checks"],
    tags: ["load-balancing", "traffic-management", "high-availability"]
  },
  {
    id: 66,
    name: "BackendBard",
    description: "Composes beautiful API symphonies and tells epic tales of data transformation through elegant code.",
    owner: "Kurt Wagner",
    team: "Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "1.5.4",
    deploymentDate: "2021-10-25T12:15:00Z",
    lastUpdated: "2023-08-18T09:20:00Z",
    usageMetrics: {
      monthlyUsers: 14,
      uptime: 90.1,
      performance: 620
    },
    documentation: "https://wiki.company.com/backend-bard",
    repository: "https://git.company.com/apps/backend-bard",
    dependencies: ["API Framework", "Database Layer"],
    tags: ["api", "backend", "deprecated"]
  },
  {
    id: 67,
    name: "FrontendPhoenix",
    description: "Rises from the ashes of outdated interfaces to create blazing new user experiences.",
    owner: "Rogue",
    team: "Customer Experience",
    technology: [TECHNOLOGIES.VUE, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "3.6.1",
    deploymentDate: "2023-06-12T14:30:00Z",
    lastUpdated: "2024-02-19T12:40:00Z",
    usageMetrics: {
      monthlyUsers: 567,
      uptime: 99.3,
      performance: 175
    },
    documentation: "https://wiki.company.com/frontend-phoenix",
    repository: "https://git.company.com/apps/frontend-phoenix",
    dependencies: ["UI Framework", "Asset Pipeline"],
    tags: ["frontend", "user-interface", "modern-web"]
  },
  {
    id: 68,
    name: "QueueQueen",
    description: "Reigns over message queues with royal efficiency and never lets a task wait longer than necessary.",
    owner: "Emma Frost",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.8.7",
    deploymentDate: "2024-01-18T16:10:00Z",
    lastUpdated: "2024-02-26T14:50:00Z",
    usageMetrics: {
      monthlyUsers: 76,
      uptime: 98.9,
      performance: 265
    },
    documentation: "https://wiki.company.com/queue-queen",
    repository: "https://git.company.com/apps/queue-queen",
    dependencies: ["Message Queue", "Task Processor"],
    tags: ["queuing", "task-management", "async-processing"]
  },
  {
    id: 69,
    name: "DatabaseDragon",
    description: "Hoards precious data in secure lairs and breathes performance fire when queries dare to be slow.",
    owner: "Bobby Drake",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.3.9",
    deploymentDate: "2024-02-28T09:45:00Z",
    lastUpdated: "2024-03-05T11:20:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/database-dragon",
    repository: "https://git.company.com/apps/database-dragon",
    dependencies: ["Database Engine", "Query Optimizer"],
    tags: ["database", "performance", "optimization"]
  },
  {
    id: 70,
    name: "SyncSorcerer",
    description: "Weaves synchronization spells across distributed systems and makes data consistency appear magical.",
    owner: "John Constantine",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.DOTNET, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "2.1.5",
    deploymentDate: "2023-03-20T13:25:00Z",
    lastUpdated: "2024-01-15T15:35:00Z",
    usageMetrics: {
      monthlyUsers: 123,
      uptime: 98.4,
      performance: 320
    },
    documentation: "https://wiki.company.com/sync-sorcerer",
    repository: "https://git.company.com/apps/sync-sorcerer",
    dependencies: ["Sync Protocol", "Conflict Resolution"],
    tags: ["synchronization", "distributed-systems", "data-consistency"]
  },
  {
    id: 71,
    name: "AlertAssassin",
    description: "Silently eliminates false alarms and strikes only when genuine threats emerge from the shadows.",
    owner: "Natasha Romanoff",
    team: "SRE",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "3.7.2",
    deploymentDate: "2022-09-08T11:30:00Z",
    lastUpdated: "2023-12-12T10:15:00Z",
    usageMetrics: {
      monthlyUsers: 67,
      uptime: 95.7,
      performance: 440
    },
    documentation: "https://wiki.company.com/alert-assassin",
    repository: "https://git.company.com/apps/alert-assassin",
    dependencies: ["Alert Manager", "Noise Filter"],
    tags: ["alerting", "noise-reduction", "monitoring"]
  },
  {
    id: 72,
    name: "ComplianceChampion",
    description: "Fights for regulatory righteousness and ensures all systems meet the highest standards of compliance.",
    owner: "Jennifer Walters",
    team: "Accounting",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "1.4.8",
    deploymentDate: "2021-07-14T08:50:00Z",
    lastUpdated: "2023-09-25T12:40:00Z",
    usageMetrics: {
      monthlyUsers: 23,
      uptime: 89.6,
      performance: 590
    },
    documentation: "https://wiki.company.com/compliance-champion",
    repository: "https://git.company.com/apps/compliance-champion",
    dependencies: ["Compliance Engine", "Audit Trail"],
    tags: ["compliance", "auditing", "regulatory"]
  },
  {
    id: 73,
    name: "ProcessPioneer",
    description: "Blazes new trails through business process wilderness and establishes efficient workflow settlements.",
    owner: "Logan",
    team: "Business Process",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "4.3.6",
    deploymentDate: "2023-05-18T15:40:00Z",
    lastUpdated: "2024-02-17T11:25:00Z",
    usageMetrics: {
      monthlyUsers: 289,
      uptime: 99.1,
      performance: 195
    },
    documentation: "https://wiki.company.com/process-pioneer",
    repository: "https://git.company.com/apps/process-pioneer",
    dependencies: ["Process Engine", "Workflow Designer"],
    tags: ["business-process", "workflow", "optimization"]
  },
  {
    id: 74,
    name: "MiddlewareMage",
    description: "Conjures powerful integration spells and connects disparate systems with arcane middleware magic.",
    owner: "Zatanna Zatara",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.6.3",
    deploymentDate: "2024-02-05T10:20:00Z",
    lastUpdated: "2024-02-27T16:45:00Z",
    usageMetrics: {
      monthlyUsers: 54,
      uptime: 97.8,
      performance: 355
    },
    documentation: "https://wiki.company.com/middleware-mage",
    repository: "https://git.company.com/apps/middleware-mage",
    dependencies: ["ESB", "Message Broker"],
    tags: ["middleware", "integration", "messaging"]
  },
  {
    id: 75,
    name: "EventEmperor",
    description: "Rules over event-driven architecture with imperial command and orchestrates perfect event choreography.",
    owner: "Victor Von Doom",
    team: "Engineering",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.8.2",
    deploymentDate: "2024-02-15T12:35:00Z",
    lastUpdated: "2024-03-03T14:10:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/event-emperor",
    repository: "https://git.company.com/apps/event-emperor",
    dependencies: ["Event Bus", "Event Store"],
    tags: ["event-driven", "architecture", "messaging"]
  },
  {
    id: 76,
    name: "CryptoCrusader",
    description: "Wages holy war against insecure data and protects sensitive information with encryption righteousness.",
    owner: "Frank Castle",
    team: "Security",
    technology: [TECHNOLOGIES.DOTNET, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "5.1.4",
    deploymentDate: "2022-11-30T09:15:00Z",
    lastUpdated: "2024-01-18T13:50:00Z",
    usageMetrics: {
      monthlyUsers: 445,
      uptime: 99.8,
      performance: 145
    },
    documentation: "https://wiki.company.com/crypto-crusader",
    repository: "https://git.company.com/apps/crypto-crusader",
    dependencies: ["Encryption Library", "Key Management"],
    tags: ["encryption", "security", "data-protection"]
  },
  {
    id: 77,
    name: "ServiceSentinel",
    description: "Stands guard over microservices with unwavering watchfulness and protects service boundaries.",
    owner: "Marc Spector",
    team: "SRE",
    technology: [TECHNOLOGIES.VUE, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "2.5.7",
    deploymentDate: "2022-08-22T14:05:00Z",
    lastUpdated: "2023-11-28T10:30:00Z",
    usageMetrics: {
      monthlyUsers: 78,
      uptime: 94.9,
      performance: 475
    },
    documentation: "https://wiki.company.com/service-sentinel",
    repository: "https://git.company.com/apps/service-sentinel",
    dependencies: ["Service Mesh", "Circuit Breaker"],
    tags: ["microservices", "service-mesh", "resilience"]
  },
  {
    id: 78,
    name: "TransformationTitan",
    description: "Reshapes data with titanic strength and molds information into perfect formats for any destination.",
    owner: "Kitty Pryde",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.JAVA],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "1.7.9",
    deploymentDate: "2021-05-20T16:25:00Z",
    lastUpdated: "2023-07-08T14:20:00Z",
    usageMetrics: {
      monthlyUsers: 16,
      uptime: 86.8,
      performance: 640
    },
    documentation: "https://wiki.company.com/transformation-titan",
    repository: "https://git.company.com/apps/transformation-titan",
    dependencies: ["ETL Framework", "Data Mapper"],
    tags: ["data-transformation", "etl", "deprecated"]
  },
  {
    id: 79,
    name: "BatchBarbarian",
    description: "Conquers massive batch jobs with savage efficiency and never retreats from processing challenges.",
    owner: "Conan",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.PYTHON],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "3.9.1",
    deploymentDate: "2023-10-02T11:45:00Z",
    lastUpdated: "2024-02-21T15:20:00Z",
    usageMetrics: {
      monthlyUsers: 167,
      uptime: 98.7,
      performance: 285
    },
    documentation: "https://wiki.company.com/batch-barbarian",
    repository: "https://git.company.com/apps/batch-barbarian",
    dependencies: ["Batch Processor", "Job Scheduler"],
    tags: ["batch-processing", "job-scheduling", "data-processing"]
  },
  {
    id: 80,
    name: "ArchiveArchangel",
    description: "Descends from digital heavens to preserve and protect historical data for eternal safekeeping.",
    owner: "Warren Worthington III",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.2.6",
    deploymentDate: "2024-01-28T13:15:00Z",
    lastUpdated: "2024-02-29T10:40:00Z",
    usageMetrics: {
      monthlyUsers: 45,
      uptime: 98.3,
      performance: 395
    },
    documentation: "https://wiki.company.com/archive-archangel",
    repository: "https://git.company.com/apps/archive-archangel",
    dependencies: ["Archive Storage", "Compression Engine"],
    tags: ["archival", "data-retention", "storage"]
  },
  {
    id: 81,
    name: "StreamSage",
    description: "Possesses ancient wisdom of real-time data streams and guides information flows with enlightened precision.",
    owner: "Yoda",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.6.4",
    deploymentDate: "2024-02-20T15:30:00Z",
    lastUpdated: "2024-03-04T12:55:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/stream-sage",
    repository: "https://git.company.com/apps/stream-sage",
    dependencies: ["Stream Processor", "Event Hub"],
    tags: ["stream-processing", "real-time", "event-streaming"]
  },
  {
    id: 82,
    name: "MockMaster",
    description: "Masters the art of service mocking and creates perfect test doubles for development environments.",
    owner: "Peter Quill",
    team: "Quality Assurance",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "2.4.3",
    deploymentDate: "2023-04-05T10:25:00Z",
    lastUpdated: "2024-01-22T16:10:00Z",
    usageMetrics: {
      monthlyUsers: 98,
      uptime: 98.5,
      performance: 310
    },
    documentation: "https://wiki.company.com/mock-master",
    repository: "https://git.company.com/apps/mock-master",
    dependencies: ["Mock Framework", "Test Data"],
    tags: ["testing", "mocking", "test-automation"]
  },
  {
    id: 83,
    name: "PerformanceProbe",
    description: "Investigates system performance with scientific precision and discovers bottlenecks hiding in dark code corners.",
    owner: "Reed Richards",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "4.1.8",
    deploymentDate: "2022-04-12T12:40:00Z",
    lastUpdated: "2023-10-25T09:15:00Z",
    usageMetrics: {
      monthlyUsers: 89,
      uptime: 96.2,
      performance: 410
    },
    documentation: "https://wiki.company.com/performance-probe",
    repository: "https://git.company.com/apps/performance-probe",
    dependencies: ["Profiler", "Performance Monitor"],
    tags: ["performance", "profiling", "bottleneck-analysis"]
  },
  {
    id: 84,
    name: "APIAristocrat",
    description: "Governs API design with noble elegance and ensures all interfaces maintain the highest standards of etiquette.",
    owner: "Gamora",
    team: "Engineering",
    technology: [TECHNOLOGIES.DOTNET, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "1.8.6",
    deploymentDate: "2021-09-15T11:20:00Z",
    lastUpdated: "2023-08-30T13:45:00Z",
    usageMetrics: {
      monthlyUsers: 21,
      uptime: 90.7,
      performance: 560
    },
    documentation: "https://wiki.company.com/api-aristocrat",
    repository: "https://git.company.com/apps/api-aristocrat",
    dependencies: ["API Gateway", "Schema Validator"],
    tags: ["api", "design", "deprecated"]
  },
  {
    id: 85,
    name: "CloudConqueror",
    description: "Conquers cloud territories with strategic brilliance and establishes dominion over distributed resources.",
    owner: "Drax",
    team: "Cloud Operations",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "2.7.4",
    deploymentDate: "2023-07-25T14:50:00Z",
    lastUpdated: "2024-02-23T11:30:00Z",
    usageMetrics: {
      monthlyUsers: 234,
      uptime: 99.2,
      performance: 225
    },
    documentation: "https://wiki.company.com/cloud-conqueror",
    repository: "https://git.company.com/apps/cloud-conqueror",
    dependencies: ["Cloud SDK", "Resource Manager"],
    tags: ["cloud", "infrastructure", "resource-management"]
  },
  {
    id: 86,
    name: "LogicLancer",
    description: "Charges into complex business logic battles with sharp reasoning and pierces through confusion.",
    owner: "Rocket Raccoon",
    team: "Engineering",
    technology: [TECHNOLOGIES.VUE, TECHNOLOGIES.PYTHON],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.5.2",
    deploymentDate: "2024-02-08T16:35:00Z",
    lastUpdated: "2024-02-28T14:20:00Z",
    usageMetrics: {
      monthlyUsers: 62,
      uptime: 98.1,
      performance: 370
    },
    documentation: "https://wiki.company.com/logic-lancer",
    repository: "https://git.company.com/apps/logic-lancer",
    dependencies: ["Rules Engine", "Logic Processor"],
    tags: ["business-logic", "rules-engine", "decision-making"]
  },
  {
    id: 87,
    name: "DataDemocrat",
    description: "Promotes data equality and ensures fair access to information for all citizens of the digital republic.",
    owner: "Groot",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.5.7",
    deploymentDate: "2024-02-25T09:50:00Z",
    lastUpdated: "2024-03-04T16:25:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/data-democrat",
    repository: "https://git.company.com/apps/data-democrat",
    dependencies: ["Data Catalog", "Access Control"],
    tags: ["data-governance", "data-catalog", "access-management"]
  },
  {
    id: 88,
    name: "SecuritySherpa",
    description: "Guides teams safely through treacherous security terrain and helps navigate compliance mountain peaks.",
    owner: "Mantis",
    team: "Security",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "3.6.5",
    deploymentDate: "2023-01-25T12:15:00Z",
    lastUpdated: "2024-01-28T10:45:00Z",
    usageMetrics: {
      monthlyUsers: 156,
      uptime: 99.4,
      performance: 240
    },
    documentation: "https://wiki.company.com/security-sherpa",
    repository: "https://git.company.com/apps/security-sherpa",
    dependencies: ["Security Framework", "Compliance Engine"],
    tags: ["security", "compliance", "guidance"]
  },
  {
    id: 89,
    name: "InterfaceInquisitor",
    description: "Interrogates user interfaces with relentless questioning and extracts confessions of poor usability.",
    owner: "Nebula",
    team: "Customer Experience",
    technology: [TECHNOLOGIES.REACT, TECHNOLOGIES.DOTNET],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "2.8.9",
    deploymentDate: "2022-06-05T15:25:00Z",
    lastUpdated: "2023-12-08T12:55:00Z",
    usageMetrics: {
      monthlyUsers: 43,
      uptime: 95.3,
      performance: 450
    },
    documentation: "https://wiki.company.com/interface-inquisitor",
    repository: "https://git.company.com/apps/interface-inquisitor",
    dependencies: ["UI Testing Framework", "Accessibility Tools"],
    tags: ["ui-testing", "usability", "accessibility"]
  },
  {
    id: 90,
    name: "ResponseRanger",
    description: "Patrols API response territories and ensures all data travelers receive safe passage to their destinations.",
    owner: "Yondu",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "1.9.7",
    deploymentDate: "2021-12-10T08:40:00Z",
    lastUpdated: "2023-09-05T14:30:00Z",
    usageMetrics: {
      monthlyUsers: 27,
      uptime: 88.9,
      performance: 610
    },
    documentation: "https://wiki.company.com/response-ranger",
    repository: "https://git.company.com/apps/response-ranger",
    dependencies: ["Response Cache", "API Monitor"],
    tags: ["api", "response-management", "deprecated"]
  },
  {
    id: 91,
    name: "WorkflowWeaver",
    description: "Weaves intricate process tapestries from business requirements and creates beautiful automation patterns.",
    owner: "Scarlet Witch",
    team: "Business Process",
    technology: [TECHNOLOGIES.NODEJS, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "3.4.2",
    deploymentDate: "2023-09-18T10:30:00Z",
    lastUpdated: "2024-02-20T15:45:00Z",
    usageMetrics: {
      monthlyUsers: 278,
      uptime: 99.0,
      performance: 215
    },
    documentation: "https://wiki.company.com/workflow-weaver",
    repository: "https://git.company.com/apps/workflow-weaver",
    dependencies: ["Workflow Engine", "Process Designer"],
    tags: ["workflow", "business-process", "automation"]
  },
  {
    id: 92,
    name: "ThrottleThane",
    description: "Rules over rate limiting with noble authority and prevents system overload through graceful governance.",
    owner: "Vision",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.REACT],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.7.1",
    deploymentDate: "2024-02-12T11:25:00Z",
    lastUpdated: "2024-03-01T09:50:00Z",
    usageMetrics: {
      monthlyUsers: 58,
      uptime: 98.6,
      performance: 335
    },
    documentation: "https://wiki.company.com/throttle-thane",
    repository: "https://git.company.com/apps/throttle-thane",
    dependencies: ["Rate Limiter", "Traffic Control"],
    tags: ["rate-limiting", "traffic-control", "performance"]
  },
  {
    id: 93,
    name: "BackupBishop",
    description: "Blesses data with divine protection and ensures resurrection is always possible after digital disasters.",
    owner: "Doctor Strange",
    team: "Data Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.7.8",
    deploymentDate: "2024-02-22T13:40:00Z",
    lastUpdated: "2024-03-05T14:15:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/backup-bishop",
    repository: "https://git.company.com/apps/backup-bishop",
    dependencies: ["Backup Service", "Recovery Tools"],
    tags: ["backup", "disaster-recovery", "data-protection"]
  },
  {
    id: 94,
    name: "SessionSorcerer",
    description: "Conjures session management magic and keeps user states perfectly preserved across digital realms.",
    owner: "Adam Warlock",
    team: "Security",
    technology: [TECHNOLOGIES.DOTNET, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "4.5.3",
    deploymentDate: "2022-12-18T14:20:00Z",
    lastUpdated: "2024-01-30T11:35:00Z",
    usageMetrics: {
      monthlyUsers: 389,
      uptime: 99.6,
      performance: 165
    },
    documentation: "https://wiki.company.com/session-sorcerer",
    repository: "https://git.company.com/apps/session-sorcerer",
    dependencies: ["Session Store", "Token Manager"],
    tags: ["session-management", "authentication", "security"]
  },
  {
    id: 95,
    name: "CacheCavalier",
    description: "Rides valiantly across memory landscapes and rescues performance from the clutches of slow data access.",
    owner: "Quicksilver",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.VUE, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.RETIRING,
    version: "3.2.6",
    deploymentDate: "2022-10-08T16:15:00Z",
    lastUpdated: "2023-11-20T13:25:00Z",
    usageMetrics: {
      monthlyUsers: 91,
      uptime: 95.8,
      performance: 425
    },
    documentation: "https://wiki.company.com/cache-cavalier",
    repository: "https://git.company.com/apps/cache-cavalier",
    dependencies: ["Cache Layer", "Memory Store"],
    tags: ["caching", "performance", "memory-management"]
  },
  {
    id: 96,
    name: "CompilerCommander",
    description: "Commands build processes with strategic precision and leads deployment armies to victory.",
    owner: "Cyclops",
    team: "DevOps",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.JAVA],
    lifecycle: LIFECYCLE_STAGES.DEPRECATED,
    version: "2.6.4",
    deploymentDate: "2021-08-25T09:30:00Z",
    lastUpdated: "2023-06-12T15:50:00Z",
    usageMetrics: {
      monthlyUsers: 19,
      uptime: 89.4,
      performance: 580
    },
    documentation: "https://wiki.company.com/compiler-commander",
    repository: "https://git.company.com/apps/compiler-commander",
    dependencies: ["Build Tools", "Deployment Pipeline"],
    tags: ["build", "compilation", "deprecated"]
  },
  {
    id: 97,
    name: "StateSentinel",
    description: "Guards application state with unwavering vigilance and protects data integrity across all transitions.",
    owner: "Wolverine",
    team: "Engineering",
    technology: [TECHNOLOGIES.REACT, TECHNOLOGIES.NODEJS],
    lifecycle: LIFECYCLE_STAGES.ACTIVE,
    version: "2.9.5",
    deploymentDate: "2023-11-12T12:05:00Z",
    lastUpdated: "2024-02-26T10:40:00Z",
    usageMetrics: {
      monthlyUsers: 345,
      uptime: 99.4,
      performance: 190
    },
    documentation: "https://wiki.company.com/state-sentinel",
    repository: "https://git.company.com/apps/state-sentinel",
    dependencies: ["State Manager", "Redux Store"],
    tags: ["state-management", "frontend", "data-integrity"]
  },
  {
    id: 98,
    name: "ProtocolPaladin",
    description: "Defends communication protocols with chivalrous honor and ensures all messages reach their noble destinations.",
    owner: "Jean Grey",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.JAVA, TECHNOLOGIES.ANGULAR],
    lifecycle: LIFECYCLE_STAGES.PILOT,
    version: "1.4.9",
    deploymentDate: "2024-02-14T15:10:00Z",
    lastUpdated: "2024-02-29T12:30:00Z",
    usageMetrics: {
      monthlyUsers: 71,
      uptime: 98.2,
      performance: 345
    },
    documentation: "https://wiki.company.com/protocol-paladin",
    repository: "https://git.company.com/apps/protocol-paladin",
    dependencies: ["Protocol Handler", "Message Router"],
    tags: ["protocols", "communication", "messaging"]
  },
  {
    id: 99,
    name: "ResourceRoyalty",
    description: "Rules over system resources with regal authority and ensures fair distribution across all digital subjects.",
    owner: "Storm",
    team: "SRE",
    technology: [TECHNOLOGIES.PYTHON, TECHNOLOGIES.VUE],
    lifecycle: LIFECYCLE_STAGES.IN_DEV,
    version: "0.4.3",
    deploymentDate: "2024-03-01T10:15:00Z",
    lastUpdated: "2024-03-05T13:20:00Z",
    usageMetrics: {
      monthlyUsers: 0,
      uptime: 0,
      performance: 0
    },
    documentation: "https://wiki.company.com/resource-royalty",
    repository: "https://git.company.com/apps/resource-royalty",
    dependencies: ["Resource Monitor", "Allocation Manager"],
    tags: ["resource-management", "system-resources", "optimization"]
  },
  {
    id: 100,
    name: "LegacyLion",
    description: "Roars with the wisdom of ancient systems and bridges the gap between old and new with majestic strength.",
    owner: "Professor Xavier",
    team: "Platform Engineering",
    technology: [TECHNOLOGIES.DOTNET, TECHNOLOGIES.JAVA],
    lifecycle: LIFECYCLE_STAGES.MAINTENANCE,
    version: "6.8.4",
    deploymentDate: "2020-01-15T08:00:00Z",
    lastUpdated: "2024-01-10T14:45:00Z",
    usageMetrics: {
      monthlyUsers: 678,
      uptime: 99.9,
      performance: 125
    },
    documentation: "https://wiki.company.com/legacy-lion",
    repository: "https://git.company.com/apps/legacy-lion",
    dependencies: ["Legacy Adapter", "Migration Tools"],
    tags: ["legacy", "migration", "integration"]
  }
];

const feedback = [
  // Existing feedback
  {
    id: 1,
    applicationId: 1,
    userId: 4,
    ratings: {
      usability: 4,
      stability: 5,
      performance: 4,
      documentation: 3
    },
    comment: "Great portal overall! The interface is intuitive, though documentation could be improved.",
    isAnonymous: false,
    createdAt: "2024-02-28T14:30:00Z",
    helpful: 8
  },
  {
    id: 2,
    applicationId: 1,
    userId: 2,
    ratings: {
      usability: 5,
      stability: 4,
      performance: 3,
      documentation: 4
    },
    comment: "Love the new features, but loading times can be slow during peak hours.",
    isAnonymous: false,
    createdAt: "2024-03-01T09:15:00Z",
    helpful: 12
  },
  {
    id: 3,
    applicationId: 2,
    userId: null, // Anonymous
    ratings: {
      usability: 2,
      stability: 3,
      performance: 4,
      documentation: 2
    },
    comment: "The system works but the UI feels outdated. Training new users is challenging.",
    isAnonymous: true,
    createdAt: "2024-02-25T11:45:00Z",
    helpful: 5
  },

  // Additional feedback for more apps (leaving apps 4, 13, 22, 31, 40, 49, 58, 67, 76, 85 with no ratings)
  {
    id: 4,
    applicationId: 3,
    userId: 3,
    ratings: { usability: 4, stability: 4, performance: 3, documentation: 4 },
    comment: "Solid ticketing system, easy to use.",
    isAnonymous: false,
    createdAt: "2024-03-02T10:20:00Z",
    helpful: 6
  },
  {
    id: 5,
    applicationId: 5,
    userId: 2,
    ratings: { usability: 3, stability: 2, performance: 2, documentation: 1 },
    comment: "Configuration is confusing and performance is poor.",
    isAnonymous: false,
    createdAt: "2024-02-20T15:30:00Z",
    helpful: 4
  },
  {
    id: 6,
    applicationId: 6,
    userId: 4,
    ratings: { usability: 5, stability: 5, performance: 4, documentation: 5 },
    comment: "LogGoblin is excellent for log analysis. Great documentation!",
    isAnonymous: false,
    createdAt: "2024-03-01T14:15:00Z",
    helpful: 15
  },
  {
    id: 7,
    applicationId: 7,
    userId: 1,
    ratings: { usability: 3, stability: 4, performance: 3, documentation: 2 },
    comment: "Onboarding tool works but needs better docs.",
    isAnonymous: false,
    createdAt: "2024-02-15T11:00:00Z",
    helpful: 3
  },
  {
    id: 8,
    applicationId: 8,
    userId: 5,
    ratings: { usability: 4, stability: 3, performance: 4, documentation: 3 },
    comment: "Documentation system is helpful but search could be better.",
    isAnonymous: false,
    createdAt: "2024-02-28T09:45:00Z",
    helpful: 7
  },
  {
    id: 9,
    applicationId: 9,
    userId: 2,
    ratings: { usability: 5, stability: 4, performance: 5, documentation: 4 },
    comment: "IncidentBingo makes incident tracking fun and effective!",
    isAnonymous: false,
    createdAt: "2024-03-03T16:30:00Z",
    helpful: 12
  },
  {
    id: 10,
    applicationId: 10,
    userId: 3,
    ratings: { usability: 4, stability: 3, performance: 4, documentation: 3 },
    comment: "Patching tool works well most of the time.",
    isAnonymous: false,
    createdAt: "2024-02-25T13:20:00Z",
    helpful: 8
  },
  {
    id: 11,
    applicationId: 11,
    userId: 4,
    ratings: { usability: 2, stability: 2, performance: 1, documentation: 2 },
    comment: "Very slow and unreliable. Needs major improvements.",
    isAnonymous: false,
    createdAt: "2024-02-18T12:15:00Z",
    helpful: 9
  },
  {
    id: 12,
    applicationId: 12,
    userId: 1,
    ratings: { usability: 5, stability: 5, performance: 5, documentation: 4 },
    comment: "CacheWhisperer is amazing! Fast and reliable caching.",
    isAnonymous: false,
    createdAt: "2024-03-04T10:30:00Z",
    helpful: 18
  },
  {
    id: 13,
    applicationId: 14,
    userId: 2,
    ratings: { usability: 3, stability: 4, performance: 3, documentation: 3 },
    comment: "Database tool is functional but interface needs work.",
    isAnonymous: false,
    createdAt: "2024-02-22T14:45:00Z",
    helpful: 5
  },
  {
    id: 14,
    applicationId: 15,
    userId: 5,
    ratings: { usability: 4, stability: 5, performance: 4, documentation: 5 },
    comment: "DataDragon handles data processing excellently. Great docs!",
    isAnonymous: false,
    createdAt: "2024-02-29T11:20:00Z",
    helpful: 13
  },
  {
    id: 15,
    applicationId: 16,
    userId: 3,
    ratings: { usability: 3, stability: 3, performance: 2, documentation: 2 },
    comment: "SecretSafe could use performance improvements.",
    isAnonymous: false,
    createdAt: "2024-02-16T15:30:00Z",
    helpful: 4
  },
  {
    id: 16,
    applicationId: 17,
    userId: 4,
    ratings: { usability: 5, stability: 4, performance: 5, documentation: 4 },
    comment: "MetricMagnet provides excellent analytics and insights!",
    isAnonymous: false,
    createdAt: "2024-03-02T13:15:00Z",
    helpful: 16
  },
  {
    id: 17,
    applicationId: 18,
    userId: 2,
    ratings: { usability: 4, stability: 4, performance: 3, documentation: 4 },
    comment: "Good integration platform, reliable and well-documented.",
    isAnonymous: false,
    createdAt: "2024-02-20T10:45:00Z",
    helpful: 8
  },
  {
    id: 18,
    applicationId: 19,
    userId: 1,
    ratings: { usability: 2, stability: 3, performance: 2, documentation: 1 },
    comment: "Legacy system showing its age. Difficult to use.",
    isAnonymous: false,
    createdAt: "2024-02-12T16:00:00Z",
    helpful: 6
  },
  {
    id: 19,
    applicationId: 20,
    userId: 5,
    ratings: { usability: 4, stability: 5, performance: 4, documentation: 3 },
    comment: "API Gateway works well, could use better documentation.",
    isAnonymous: false,
    createdAt: "2024-02-27T09:30:00Z",
    helpful: 10
  },
  {
    id: 20,
    applicationId: 21,
    userId: 3,
    ratings: { usability: 5, stability: 4, performance: 5, documentation: 5 },
    comment: "AuthGuardian is fantastic! Secure and easy to integrate.",
    isAnonymous: false,
    createdAt: "2024-03-01T12:45:00Z",
    helpful: 20
  },
  {
    id: 21,
    applicationId: 23,
    userId: 4,
    ratings: { usability: 3, stability: 4, performance: 3, documentation: 2 },
    comment: "Workflow system is okay but documentation needs improvement.",
    isAnonymous: false,
    createdAt: "2024-02-19T14:20:00Z",
    helpful: 5
  },
  {
    id: 22,
    applicationId: 24,
    userId: 2,
    ratings: { usability: 4, stability: 3, performance: 4, documentation: 4 },
    comment: "Message broker handles traffic well, occasional hiccups.",
    isAnonymous: false,
    createdAt: "2024-02-24T11:15:00Z",
    helpful: 7
  },
  {
    id: 23,
    applicationId: 25,
    userId: 1,
    ratings: { usability: 5, stability: 5, performance: 4, documentation: 4 },
    comment: "CloudConductor makes cloud management a breeze!",
    isAnonymous: false,
    createdAt: "2024-03-03T15:20:00Z",
    helpful: 14
  },
  {
    id: 24,
    applicationId: 26,
    userId: 5,
    ratings: { usability: 3, stability: 2, performance: 2, documentation: 3 },
    comment: "Monitoring tool needs stability improvements.",
    isAnonymous: false,
    createdAt: "2024-02-17T13:40:00Z",
    helpful: 6
  },
  {
    id: 25,
    applicationId: 27,
    userId: 3,
    ratings: { usability: 4, stability: 5, performance: 4, documentation: 4 },
    comment: "PasswordPal is reliable and secure for credential management.",
    isAnonymous: false,
    createdAt: "2024-02-26T10:25:00Z",
    helpful: 11
  },
  {
    id: 26,
    applicationId: 28,
    userId: 4,
    ratings: { usability: 5, stability: 4, performance: 5, documentation: 3 },
    comment: "Load balancer performs excellently under high traffic.",
    isAnonymous: false,
    createdAt: "2024-02-21T16:10:00Z",
    helpful: 9
  },
  {
    id: 27,
    applicationId: 29,
    userId: 2,
    ratings: { usability: 3, stability: 3, performance: 4, documentation: 2 },
    comment: "Backup system works but interface could be more intuitive.",
    isAnonymous: false,
    createdAt: "2024-02-14T12:30:00Z",
    helpful: 4
  },
  {
    id: 28,
    applicationId: 30,
    userId: 1,
    ratings: { usability: 4, stability: 4, performance: 3, documentation: 4 },
    comment: "Security scanner is thorough and provides good reports.",
    isAnonymous: false,
    createdAt: "2024-02-23T14:50:00Z",
    helpful: 12
  },
  {
    id: 29,
    applicationId: 32,
    userId: 5,
    ratings: { usability: 2, stability: 3, performance: 2, documentation: 1 },
    comment: "Old system that's hard to navigate. Needs modernization.",
    isAnonymous: false,
    createdAt: "2024-02-11T15:15:00Z",
    helpful: 8
  },
  {
    id: 30,
    applicationId: 33,
    userId: 3,
    ratings: { usability: 4, stability: 5, performance: 4, documentation: 3 },
    comment: "Container orchestrator is solid and handles scaling well.",
    isAnonymous: false,
    createdAt: "2024-02-28T11:40:00Z",
    helpful: 10
  },
  {
    id: 31,
    applicationId: 34,
    userId: 4,
    ratings: { usability: 5, stability: 4, performance: 5, documentation: 5 },
    comment: "TestMaster makes testing so much easier! Love the automation.",
    isAnonymous: false,
    createdAt: "2024-03-04T13:25:00Z",
    helpful: 17
  },
  {
    id: 32,
    applicationId: 35,
    userId: 2,
    ratings: { usability: 3, stability: 4, performance: 3, documentation: 3 },
    comment: "Build pipeline works consistently, average user experience.",
    isAnonymous: false,
    createdAt: "2024-02-18T10:55:00Z",
    helpful: 6
  },
  {
    id: 33,
    applicationId: 36,
    userId: 1,
    ratings: { usability: 4, stability: 3, performance: 4, documentation: 2 },
    comment: "Package manager is useful but documentation is lacking.",
    isAnonymous: false,
    createdAt: "2024-02-25T16:20:00Z",
    helpful: 7
  },
  {
    id: 34,
    applicationId: 37,
    userId: 5,
    ratings: { usability: 5, stability: 5, performance: 4, documentation: 4 },
    comment: "FeatureFalcon delivers features quickly and reliably!",
    isAnonymous: false,
    createdAt: "2024-03-02T09:10:00Z",
    helpful: 15
  },
  {
    id: 35,
    applicationId: 38,
    userId: 3,
    ratings: { usability: 3, stability: 2, performance: 3, documentation: 2 },
    comment: "Resource allocator needs stability improvements.",
    isAnonymous: false,
    createdAt: "2024-02-16T14:35:00Z",
    helpful: 5
  },
  {
    id: 36,
    applicationId: 39,
    userId: 4,
    ratings: { usability: 4, stability: 4, performance: 4, documentation: 3 },
    comment: "Network monitor provides good insights, solid performance.",
    isAnonymous: false,
    createdAt: "2024-02-22T12:15:00Z",
    helpful: 8
  },
  {
    id: 37,
    applicationId: 41,
    userId: 2,
    ratings: { usability: 5, stability: 4, performance: 5, documentation: 4 },
    comment: "Config manager is intuitive and handles complex setups well.",
    isAnonymous: false,
    createdAt: "2024-02-27T15:45:00Z",
    helpful: 13
  },
  {
    id: 38,
    applicationId: 42,
    userId: 1,
    ratings: { usability: 3, stability: 3, performance: 2, documentation: 3 },
    comment: "Deployment tool works but could be faster.",
    isAnonymous: false,
    createdAt: "2024-02-19T11:30:00Z",
    helpful: 4
  },
  {
    id: 39,
    applicationId: 43,
    userId: 5,
    ratings: { usability: 4, stability: 5, performance: 4, documentation: 5 },
    comment: "Service mesh provides excellent traffic management and documentation!",
    isAnonymous: false,
    createdAt: "2024-03-01T10:20:00Z",
    helpful: 16
  },
  {
    id: 40,
    applicationId: 44,
    userId: 3,
    ratings: { usability: 4, stability: 4, performance: 3, documentation: 3 },
    comment: "Queue manager handles messages reliably.",
    isAnonymous: false,
    createdAt: "2024-02-24T13:50:00Z",
    helpful: 9
  },
  {
    id: 41,
    applicationId: 45,
    userId: 4,
    ratings: { usability: 2, stability: 3, performance: 2, documentation: 1 },
    comment: "Legacy connector is difficult to work with and poorly documented.",
    isAnonymous: false,
    createdAt: "2024-02-13T16:25:00Z",
    helpful: 7
  },
  {
    id: 42,
    applicationId: 46,
    userId: 2,
    ratings: { usability: 5, stability: 5, performance: 5, documentation: 4 },
    comment: "EventMaster handles events flawlessly! Excellent system.",
    isAnonymous: false,
    createdAt: "2024-03-03T14:10:00Z",
    helpful: 19
  },
  {
    id: 43,
    applicationId: 47,
    userId: 1,
    ratings: { usability: 3, stability: 4, performance: 3, documentation: 2 },
    comment: "Data validator works well but needs better documentation.",
    isAnonymous: false,
    createdAt: "2024-02-20T15:40:00Z",
    helpful: 6
  },
  {
    id: 44,
    applicationId: 48,
    userId: 5,
    ratings: { usability: 4, stability: 3, performance: 4, documentation: 3 },
    comment: "Scheduler manages tasks efficiently, occasional hiccups.",
    isAnonymous: false,
    createdAt: "2024-02-26T12:05:00Z",
    helpful: 8
  },
  {
    id: 45,
    applicationId: 50,
    userId: 3,
    ratings: { usability: 4, stability: 5, performance: 4, documentation: 4 },
    comment: "AI assistant is helpful and provides good automation features.",
    isAnonymous: false,
    createdAt: "2024-02-29T16:30:00Z",
    helpful: 14
  },
  {
    id: 46,
    applicationId: 51,
    userId: 4,
    ratings: { usability: 5, stability: 4, performance: 5, documentation: 3 },
    comment: "Search engine delivers fast and relevant results!",
    isAnonymous: false,
    createdAt: "2024-03-04T11:15:00Z",
    helpful: 12
  },
  {
    id: 47,
    applicationId: 52,
    userId: 2,
    ratings: { usability: 3, stability: 2, performance: 3, documentation: 2 },
    comment: "Performance profiler needs stability improvements.",
    isAnonymous: false,
    createdAt: "2024-02-15T13:20:00Z",
    helpful: 5
  },
  {
    id: 48,
    applicationId: 53,
    userId: 1,
    ratings: { usability: 4, stability: 4, performance: 4, documentation: 4 },
    comment: "Widget factory is consistent and reliable for UI components.",
    isAnonymous: false,
    createdAt: "2024-02-23T10:45:00Z",
    helpful: 10
  },
  {
    id: 49,
    applicationId: 54,
    userId: 5,
    ratings: { usability: 3, stability: 3, performance: 2, documentation: 3 },
    comment: "Code reviewer works but could be faster with large codebases.",
    isAnonymous: false,
    createdAt: "2024-02-17T14:55:00Z",
    helpful: 6
  },
  {
    id: 50,
    applicationId: 55,
    userId: 3,
    ratings: { usability: 5, stability: 4, performance: 5, documentation: 4 },
    comment: "NotificationNomad delivers messages reliably across all channels!",
    isAnonymous: false,
    createdAt: "2024-03-02T15:25:00Z",
    helpful: 15
  },
  {
    id: 51,
    applicationId: 56,
    userId: 4,
    ratings: { usability: 4, stability: 3, performance: 3, documentation: 3 },
    comment: "Thread pool manager handles concurrency well.",
    isAnonymous: false,
    createdAt: "2024-02-21T11:40:00Z",
    helpful: 7
  },
  {
    id: 52,
    applicationId: 57,
    userId: 2,
    ratings: { usability: 2, stability: 2, performance: 1, documentation: 2 },
    comment: "Legacy system needs major overhaul. Very slow and outdated.",
    isAnonymous: false,
    createdAt: "2024-02-10T16:50:00Z",
    helpful: 9
  },
  {
    id: 53,
    applicationId: 59,
    userId: 1,
    ratings: { usability: 4, stability: 5, performance: 4, documentation: 3 },
    comment: "Content manager handles documents well, could use better docs.",
    isAnonymous: false,
    createdAt: "2024-02-25T09:35:00Z",
    helpful: 8
  },
  {
    id: 54,
    applicationId: 60,
    userId: 5,
    ratings: { usability: 5, stability: 5, performance: 5, documentation: 5 },
    comment: "TaskTitan is absolutely amazing! Perfect for project management.",
    isAnonymous: false,
    createdAt: "2024-03-04T12:20:00Z",
    helpful: 22
  },
  {
    id: 55,
    applicationId: 61,
    userId: 3,
    ratings: { usability: 3, stability: 4, performance: 3, documentation: 2 },
    comment: "Email processor works fine but interface needs improvement.",
    isAnonymous: false,
    createdAt: "2024-02-18T15:10:00Z",
    helpful: 5
  },
  {
    id: 56,
    applicationId: 62,
    userId: 4,
    ratings: { usability: 4, stability: 4, performance: 4, documentation: 4 },
    comment: "File synchronizer is reliable and handles large files well.",
    isAnonymous: false,
    createdAt: "2024-02-22T13:45:00Z",
    helpful: 11
  },
  {
    id: 57,
    applicationId: 63,
    userId: 2,
    ratings: { usability: 5, stability: 4, performance: 5, documentation: 3 },
    comment: "Session manager provides excellent user experience!",
    isAnonymous: false,
    createdAt: "2024-02-28T16:15:00Z",
    helpful: 13
  },
  {
    id: 58,
    applicationId: 64,
    userId: 1,
    ratings: { usability: 3, stability: 3, performance: 2, documentation: 3 },
    comment: "Template engine works but performance could be better.",
    isAnonymous: false,
    createdAt: "2024-02-16T10:30:00Z",
    helpful: 4
  },
  {
    id: 59,
    applicationId: 65,
    userId: 5,
    ratings: { usability: 4, stability: 5, performance: 4, documentation: 4 },
    comment: "Access controller provides solid security and reliable access management.",
    isAnonymous: false,
    createdAt: "2024-02-27T14:20:00Z",
    helpful: 12
  },
  {
    id: 60,
    applicationId: 66,
    userId: 3,
    ratings: { usability: 2, stability: 2, performance: 1, documentation: 1 },
    comment: "Sync service is unreliable and poorly documented. Needs complete rework.",
    isAnonymous: false,
    createdAt: "2024-02-12T12:45:00Z",
    helpful: 8
  },
  {
    id: 61,
    applicationId: 68,
    userId: 4,
    ratings: { usability: 4, stability: 4, performance: 4, documentation: 3 },
    comment: "Plugin system is flexible and handles extensions well.",
    isAnonymous: false,
    createdAt: "2024-02-24T11:55:00Z",
    helpful: 9
  },
  {
    id: 62,
    applicationId: 69,
    userId: 2,
    ratings: { usability: 5, stability: 5, performance: 4, documentation: 5 },
    comment: "GraphQL gateway is fantastic! Excellent performance and documentation.",
    isAnonymous: false,
    createdAt: "2024-03-01T13:40:00Z",
    helpful: 18
  },
  {
    id: 63,
    applicationId: 70,
    userId: 1,
    ratings: { usability: 3, stability: 3, performance: 3, documentation: 2 },
    comment: "Image processor works adequately but documentation needs work.",
    isAnonymous: false,
    createdAt: "2024-02-19T16:25:00Z",
    helpful: 6
  },
  {
    id: 64,
    applicationId: 71,
    userId: 5,
    ratings: { usability: 4, stability: 3, performance: 4, documentation: 3 },
    comment: "Stream handler manages data flows well, occasional stability issues.",
    isAnonymous: false,
    createdAt: "2024-02-26T10:15:00Z",
    helpful: 7
  },
  {
    id: 65,
    applicationId: 72,
    userId: 3,
    ratings: { usability: 5, stability: 4, performance: 5, documentation: 4 },
    comment: "CommandCatalyst makes command-line operations so much easier!",
    isAnonymous: false,
    createdAt: "2024-03-03T12:30:00Z",
    helpful: 16
  },
  {
    id: 66,
    applicationId: 73,
    userId: 4,
    ratings: { usability: 3, stability: 4, performance: 3, documentation: 3 },
    comment: "Route optimizer works well for basic routing needs.",
    isAnonymous: false,
    createdAt: "2024-02-20T14:10:00Z",
    helpful: 8
  },
  {
    id: 67,
    applicationId: 74,
    userId: 2,
    ratings: { usability: 4, stability: 5, performance: 4, documentation: 4 },
    comment: "Socket manager handles real-time connections excellently.",
    isAnonymous: false,
    createdAt: "2024-02-23T15:50:00Z",
    helpful: 11
  },
  {
    id: 68,
    applicationId: 75,
    userId: 1,
    ratings: { usability: 2, stability: 3, performance: 2, documentation: 2 },
    comment: "Cache handler needs performance improvements and better documentation.",
    isAnonymous: false,
    createdAt: "2024-02-14T13:25:00Z",
    helpful: 5
  },
  {
    id: 69,
    applicationId: 77,
    userId: 5,
    ratings: { usability: 4, stability: 4, performance: 4, documentation: 3 },
    comment: "Memory manager is efficient and handles allocation well.",
    isAnonymous: false,
    createdAt: "2024-02-28T12:45:00Z",
    helpful: 10
  },
  {
    id: 70,
    applicationId: 78,
    userId: 3,
    ratings: { usability: 5, stability: 4, performance: 5, documentation: 4 },
    comment: "Pipeline orchestrator makes complex workflows simple and efficient!",
    isAnonymous: false,
    createdAt: "2024-03-02T11:20:00Z",
    helpful: 17
  },
  {
    id: 71,
    applicationId: 79,
    userId: 4,
    ratings: { usability: 3, stability: 3, performance: 3, documentation: 2 },
    comment: "Error tracker works fine but could use better reporting features.",
    isAnonymous: false,
    createdAt: "2024-02-17T16:35:00Z",
    helpful: 6
  },
  {
    id: 72,
    applicationId: 80,
    userId: 2,
    ratings: { usability: 4, stability: 5, performance: 4, documentation: 5 },
    comment: "Config validator is thorough and provides excellent error reporting!",
    isAnonymous: false,
    createdAt: "2024-02-25T14:15:00Z",
    helpful: 14
  },
  {
    id: 73,
    applicationId: 81,
    userId: 1,
    ratings: { usability: 3, stability: 2, performance: 2, documentation: 3 },
    comment: "Service monitor needs stability and performance improvements.",
    isAnonymous: false,
    createdAt: "2024-02-13T11:50:00Z",
    helpful: 7
  },
  {
    id: 74,
    applicationId: 82,
    userId: 5,
    ratings: { usability: 5, stability: 5, performance: 4, documentation: 4 },
    comment: "MetricsMaestro provides beautiful dashboards and insights!",
    isAnonymous: false,
    createdAt: "2024-03-04T15:25:00Z",
    helpful: 19
  },
  {
    id: 75,
    applicationId: 83,
    userId: 3,
    ratings: { usability: 4, stability: 4, performance: 3, documentation: 3 },
    comment: "Thread manager handles concurrency well, decent performance.",
    isAnonymous: false,
    createdAt: "2024-02-21T13:40:00Z",
    helpful: 8
  },
  {
    id: 76,
    applicationId: 84,
    userId: 4,
    ratings: { usability: 3, stability: 3, performance: 4, documentation: 2 },
    comment: "Process scheduler works but documentation could be clearer.",
    isAnonymous: false,
    createdAt: "2024-02-18T14:20:00Z",
    helpful: 5
  },
  {
    id: 77,
    applicationId: 86,
    userId: 2,
    ratings: { usability: 4, stability: 4, performance: 4, documentation: 4 },
    comment: "Event processor handles high volume events reliably.",
    isAnonymous: false,
    createdAt: "2024-02-26T16:10:00Z",
    helpful: 12
  },
  {
    id: 78,
    applicationId: 87,
    userId: 1,
    ratings: { usability: 5, stability: 5, performance: 5, documentation: 3 },
    comment: "Request router is lightning fast and incredibly reliable!",
    isAnonymous: false,
    createdAt: "2024-03-01T14:55:00Z",
    helpful: 15
  },
  {
    id: 79,
    applicationId: 88,
    userId: 5,
    ratings: { usability: 3, stability: 4, performance: 3, documentation: 3 },
    comment: "Data transformer works consistently for most use cases.",
    isAnonymous: false,
    createdAt: "2024-02-22T10:30:00Z",
    helpful: 7
  },
  {
    id: 80,
    applicationId: 89,
    userId: 3,
    ratings: { usability: 4, stability: 3, performance: 4, documentation: 3 },
    comment: "Signal processor handles real-time signals well.",
    isAnonymous: false,
    createdAt: "2024-02-24T15:45:00Z",
    helpful: 9
  },
  {
    id: 81,
    applicationId: 90,
    userId: 4,
    ratings: { usability: 2, stability: 2, performance: 1, documentation: 1 },
    comment: "Legacy system that desperately needs modernization. Very difficult to use.",
    isAnonymous: false,
    createdAt: "2024-02-11T14:20:00Z",
    helpful: 11
  },
  {
    id: 82,
    applicationId: 91,
    userId: 2,
    ratings: { usability: 4, stability: 5, performance: 4, documentation: 4 },
    comment: "Connection manager provides stable and reliable connections.",
    isAnonymous: false,
    createdAt: "2024-02-27T11:25:00Z",
    helpful: 13
  },
  {
    id: 83,
    applicationId: 92,
    userId: 1,
    ratings: { usability: 5, stability: 4, performance: 5, documentation: 4 },
    comment: "LoadLeveler distributes traffic perfectly! Great performance.",
    isAnonymous: false,
    createdAt: "2024-03-03T10:15:00Z",
    helpful: 16
  },
  {
    id: 84,
    applicationId: 93,
    userId: 5,
    ratings: { usability: 3, stability: 3, performance: 2, documentation: 2 },
    comment: "Backup manager works but could be more efficient.",
    isAnonymous: false,
    createdAt: "2024-02-16T12:40:00Z",
    helpful: 6
  },
  {
    id: 85,
    applicationId: 94,
    userId: 3,
    ratings: { usability: 4, stability: 4, performance: 4, documentation: 3 },
    comment: "Security scanner provides comprehensive vulnerability detection.",
    isAnonymous: false,
    createdAt: "2024-02-23T16:30:00Z",
    helpful: 10
  },
  {
    id: 86,
    applicationId: 95,
    userId: 4,
    ratings: { usability: 3, stability: 2, performance: 3, documentation: 2 },
    comment: "Compiler commander needs stability improvements.",
    isAnonymous: false,
    createdAt: "2024-02-15T15:15:00Z",
    helpful: 4
  },
  {
    id: 87,
    applicationId: 96,
    userId: 2,
    ratings: { usability: 5, stability: 5, performance: 4, documentation: 5 },
    comment: "StateSentinel is excellent for state management! Outstanding documentation.",
    isAnonymous: false,
    createdAt: "2024-03-04T09:45:00Z",
    helpful: 20
  },
  {
    id: 88,
    applicationId: 97,
    userId: 1,
    ratings: { usability: 4, stability: 4, performance: 4, documentation: 3 },
    comment: "Protocol paladin handles communication protocols well.",
    isAnonymous: false,
    createdAt: "2024-02-20T13:20:00Z",
    helpful: 8
  },
  {
    id: 89,
    applicationId: 99,
    userId: 5,
    ratings: { usability: 3, stability: 4, performance: 3, documentation: 3 },
    comment: "Resource royalty manages system resources adequately.",
    isAnonymous: false,
    createdAt: "2024-02-26T14:35:00Z",
    helpful: 7
  },
  {
    id: 90,
    applicationId: 100,
    userId: 3,
    ratings: { usability: 4, stability: 5, performance: 3, documentation: 4 },
    comment: "LegacyLion bridges old and new systems reliably.",
    isAnonymous: false,
    createdAt: "2024-02-29T10:50:00Z",
    helpful: 12
  }
];

const reuseRequests = [
  {
    id: 1,
    applicationId: 1,
    requesterId: 3,
    purpose: "Want to reuse the authentication module for new project",
    businessJustification: "Our new project needs similar login functionality",
    timeline: "Q2 2024",
    status: "approved",
    adminNotes: "Auth module is well-documented and reusable",
    requestedAt: "2024-02-20T10:00:00Z",
    reviewedAt: "2024-02-22T14:30:00Z",
    reviewedBy: 1
  },
  {
    id: 2,
    applicationId: 2,
    requesterId: 4,
    purpose: "Adapt inventory tracking for office supplies management",
    businessJustification: "HR needs similar tracking capabilities for office inventory",
    timeline: "Q3 2024",
    status: "pending",
    adminNotes: null,
    requestedAt: "2024-03-01T15:20:00Z",
    reviewedAt: null,
    reviewedBy: null
  },
  {
    id: 3,
    applicationId: 1,
    requesterId: 2,
    purpose: "Reuse user management system for partner portal",
    businessJustification: "Need similar user authentication for external partners",
    timeline: "Q2 2024",
    status: "approved",
    adminNotes: "Great fit for partner portal needs",
    requestedAt: "2024-02-25T09:15:00Z",
    reviewedAt: "2024-02-26T11:45:00Z",
    reviewedBy: 1
  },
  {
    id: 4,
    applicationId: 6,
    requesterId: 3,
    purpose: "Implement log analysis for security monitoring",
    businessJustification: "Security team needs log analysis capabilities",
    timeline: "Q2 2024", 
    status: "approved",
    adminNotes: "LogGoblin is perfect for security log analysis",
    requestedAt: "2024-02-15T14:20:00Z",
    reviewedAt: "2024-02-16T16:00:00Z",
    reviewedBy: 1
  },
  {
    id: 5,
    applicationId: 6,
    requesterId: 4,
    purpose: "Use log search for troubleshooting customer issues",
    businessJustification: "Customer support needs better log search tools",
    timeline: "Q3 2024",
    status: "approved", 
    adminNotes: "Approved with training support included",
    requestedAt: "2024-02-28T10:30:00Z",
    reviewedAt: "2024-03-01T13:15:00Z",
    reviewedBy: 1
  },
  {
    id: 6,
    applicationId: 9,
    requesterId: 2,
    purpose: "Adapt incident tracking for project management",
    businessJustification: "Project team wants to track project issues like incidents",
    timeline: "Q3 2024",
    status: "approved",
    adminNotes: "Good use case, will provide implementation guidance",
    requestedAt: "2024-02-20T11:45:00Z",
    reviewedAt: "2024-02-21T15:30:00Z", 
    reviewedBy: 1
  },
  {
    id: 7,
    applicationId: 9,
    requesterId: 3,
    purpose: "Use incident workflow for change management",
    businessJustification: "Change management process needs similar workflow capabilities",
    timeline: "Q4 2024",
    status: "rejected",
    adminNotes: "Not suitable for change management workflow",
    requestedAt: "2024-03-01T16:20:00Z",
    reviewedAt: "2024-03-02T14:10:00Z",
    reviewedBy: 1
  },
  {
    id: 8,
    applicationId: 11,
    requesterId: 2,
    purpose: "Implement caching for mobile app backend",
    businessJustification: "Mobile app needs faster response times",
    timeline: "Q2 2024",
    status: "approved",
    adminNotes: "CacheWhisperer will significantly improve mobile performance",
    requestedAt: "2024-02-22T09:00:00Z",
    reviewedAt: "2024-02-23T10:30:00Z",
    reviewedBy: 1
  },
  {
    id: 9,
    applicationId: 13,
    requesterId: 4,
    purpose: "Secure data storage for compliance project",
    businessJustification: "Compliance project needs secure data handling",
    timeline: "Q2 2024",
    status: "approved",
    adminNotes: "DataDragon provides excellent security for compliance needs",
    requestedAt: "2024-02-18T13:45:00Z",
    reviewedAt: "2024-02-19T16:20:00Z",
    reviewedBy: 1
  },
  {
    id: 10,
    applicationId: 13,
    requesterId: 3,
    purpose: "Data protection for customer analytics",
    businessJustification: "Analytics team needs secure customer data handling",
    timeline: "Q3 2024",
    status: "pending",
    adminNotes: null,
    requestedAt: "2024-03-02T14:15:00Z",
    reviewedAt: null,
    reviewedBy: null
  },
  {
    id: 11,
    applicationId: 17,
    requesterId: 2,
    purpose: "Secret management for CI/CD pipeline",
    businessJustification: "DevOps needs secure secret storage for automated deployments",
    timeline: "Q2 2024",
    status: "approved",
    adminNotes: "SecretSafe is ideal for CI/CD secret management",
    requestedAt: "2024-02-24T11:10:00Z",
    reviewedAt: "2024-02-25T14:45:00Z",
    reviewedBy: 1
  },
  {
    id: 12,
    applicationId: 19,
    requesterId: 4,
    purpose: "Dashboard for executive reporting",
    businessJustification: "Executive team needs consolidated metrics dashboard",
    timeline: "Q3 2024",
    status: "approved",
    adminNotes: "MetricMagnet can be customized for executive reporting",
    requestedAt: "2024-02-26T15:30:00Z",
    reviewedAt: "2024-02-27T17:00:00Z",
    reviewedBy: 1
  },
  {
    id: 13,
    applicationId: 67,
    requesterId: 5,
    purpose: "Need modern UI components for marketing campaigns",
    businessJustification: "Marketing team requires updated interface design for new campaign tools",
    timeline: "Q2 2024",
    status: "pending",
    adminNotes: null,
    requestedAt: "2024-03-03T14:30:00Z",
    reviewedAt: null,
    reviewedBy: null
  },
  {
    id: 14,
    applicationId: 55,
    requesterId: 5,
    purpose: "Reuse notification system for marketing alerts",
    businessJustification: "Campaign notifications need multi-channel delivery capabilities",
    timeline: "Q2 2024",
    status: "pending",
    adminNotes: null,
    requestedAt: "2024-03-04T10:15:00Z",
    reviewedAt: null,
    reviewedBy: null
  },
  {
    id: 15,
    applicationId: 27,
    requesterId: 5,
    purpose: "Integrate password management for campaign tools",
    businessJustification: "Marketing team needs secure credential management for external tools",
    timeline: "Q3 2024",
    status: "approved",
    adminNotes: "PasswordPal integration approved for marketing tools",
    requestedAt: "2024-02-28T16:20:00Z",
    reviewedAt: "2024-03-01T11:40:00Z",
    reviewedBy: 1
  }
];

const approvals = [
  {
    id: 1,
    applicationId: 3,
    changeType: "lifecycle_promotion",
    fromStage: LIFECYCLE_STAGES.TESTING,
    toStage: LIFECYCLE_STAGES.PRODUCTION,
    requesterId: 1,
    reason: "All tests passed, ready for production deployment",
    status: "pending",
    requestedAt: "2024-03-02T16:45:00Z",
    reviewedAt: null,
    reviewedBy: null
  },
  {
    id: 2,
    applicationId: 4,
    changeType: "technology_update",
    details: "Upgrade React version from 16 to 18",
    requesterId: 4,
    reason: "Security updates and performance improvements",
    status: "approved",
    requestedAt: "2024-02-28T10:15:00Z",
    reviewedAt: "2024-03-01T09:30:00Z",
    reviewedBy: 1
  }
];

module.exports = {
  users,
  applications,
  feedback,
  reuseRequests,
  approvals,
  LIFECYCLE_STAGES,
  TECHNOLOGIES
};
