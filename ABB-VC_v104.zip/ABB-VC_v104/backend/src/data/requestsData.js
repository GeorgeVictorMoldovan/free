// Comprehensive Requests Mock Data for Internal Application Lifecycle Portal
// Contains all types of requests associated with applications and users

// Request types
const REQUEST_TYPES = {
  ACCESS: 'access',
  REUSE: 'reuse', 
  SUPPORT: 'support',
  LIFECYCLE_PROMOTION: 'lifecycle_promotion',
  TECHNOLOGY_UPDATE: 'technology_update',
  FEEDBACK: 'feedback',
  BUG_REPORT: 'bug_report',
  FEATURE_REQUEST: 'feature_request'
};

// Request statuses
const REQUEST_STATUS = {
  SUBMITTED: 'submitted',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  DELETED: 'deleted'
};

// Request priorities
const REQUEST_PRIORITY = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high',
  URGENT: 'urgent'
};

const allRequests = [
  // ACCESS REQUESTS
  {
    id: 1,
    type: REQUEST_TYPES.ACCESS,
    applicationId: 1,
    requesterId: 2, // Bob Smith
    title: "Access to Opendaw Customer Portal",
    description: "Need access to the customer portal for our new onboarding project",
    businessJustification: "Required to help onboard new customers and provide support",
    priority: REQUEST_PRIORITY.MEDIUM,
    status: REQUEST_STATUS.APPROVED,
    requestedAccess: ["read", "write"],
    timeline: "Immediate",
    approvedBy: 1, // Alice Johnson
    reviewedAt: "2026-03-04T10:30:00Z",
    requestedAt: "2026-03-04T14:20:00Z",
    adminNotes: "Standard access granted, user trained on system",
    estimatedCost: null,
    department: "Engineering"
  },
  {
    id: 2,
    type: REQUEST_TYPES.ACCESS,
    applicationId: 6, // LogGoblin
    requesterId: 4, // David Wilson
    title: "LogGoblin Access for Finance Team",
    description: "Finance team needs access to log monitoring for compliance auditing",
    businessJustification: "Required for financial compliance and audit trail monitoring",
    priority: REQUEST_PRIORITY.HIGH,
    status: REQUEST_STATUS.REJECTED,
    requestedAccess: ["read"],
    timeline: "End of Q1 2026",
    approvedBy: 1, // Alice Johnson
    reviewedAt: "2026-03-04T14:20:00Z",
    requestedAt: "2026-03-04T16:45:00Z",
    adminNotes: "Access denied due to security restrictions for external audit requirements",
    estimatedCost: 500,
    department: "Finance"
  },

  // REUSE REQUESTS
  {
    id: 3,
    type: REQUEST_TYPES.REUSE,
    applicationId: 1, // Opendaw
    requesterId: 3, // Carol Davis
    title: "Reuse Authentication Module",
    description: "Want to reuse the authentication module for new supply chain project",
    businessJustification: "Our new project needs similar login functionality, estimated 3 weeks development time saved",
    priority: REQUEST_PRIORITY.MEDIUM,
    status: REQUEST_STATUS.APPROVED,
    requestedComponents: ["authentication", "user-management", "session-handling"],
    timeline: "Q2 2026",
    approvedBy: 1, // Alice Johnson
    reviewedAt: "2026-03-02T14:30:00Z",
    requestedAt: "2026-03-02T10:00:00Z",
    adminNotes: "Auth module is well-documented and reusable. Provided integration guide.",
    estimatedCost: 2000,
    department: "Supply Chain"
  },
  {
    id: 4,
    type: REQUEST_TYPES.REUSE,
    applicationId: 2, // MergeWarden
    requesterId: 4, // David Wilson
    title: "Inventory Tracking for Office Supplies",
    description: "Adapt inventory tracking system for office supplies management",
    businessJustification: "HR needs similar tracking capabilities, can save 6 weeks development",
    priority: REQUEST_PRIORITY.LOW,
    status: REQUEST_STATUS.SUBMITTED,
    requestedComponents: ["inventory-tracking", "barcode-scanner", "reporting"],
    timeline: "Q3 2026",
    approvedBy: 1,
    reviewedAt: "2026-03-01T11:20:00Z",
    requestedAt: "2026-03-01T15:20:00Z",
    adminNotes: "Approved with modifications. Will need customization for office supplies.",
    estimatedCost: 8000,
    department: "Human Resources"
  },

  // SUPPORT REQUESTS
  {
    id: 5,
    type: REQUEST_TYPES.SUPPORT,
    applicationId: 2, // MergeWarden
    requesterId: 2, // Bob Smith
    title: "Performance Issues During Peak Hours",
    description: "System becomes very slow during morning peak hours (8-10 AM)",
    businessJustification: "Affecting warehouse operations and morning shift productivity",
    priority: REQUEST_PRIORITY.HIGH,
    status: REQUEST_STATUS.SUBMITTED,
    issueType: "performance",
    timeline: "ASAP",
    assignedTo: 1, // Alice Johnson
    reviewedAt: "2026-03-05T08:45:00Z",
    requestedAt: "2026-03-05T09:15:00Z",
    adminNotes: "Investigating database query optimization",
    estimatedResolutionTime: "1-2 weeks",
    department: "Supply Chain"
  },
  {
    id: 6,
    type: REQUEST_TYPES.SUPPORT,
    applicationId: 8, // DocuDuctTape
    requesterId: 3, // Carol Davis
    title: "Training Request for New Team Members",
    description: "Need training session for 5 new team members on documentation system",
    businessJustification: "New hires need to contribute to documentation immediately",
    priority: REQUEST_PRIORITY.MEDIUM,
    status: REQUEST_STATUS.APPROVED,
    issueType: "training",
    timeline: "Next 2 weeks",
    assignedTo: 1,
    reviewedAt: "2026-03-02T14:10:00Z",
    requestedAt: "2026-03-02T10:30:00Z",
    adminNotes: "Training session scheduled for March 8th, 2PM",
    estimatedResolutionTime: "1 day",
    department: "Supply Chain"
  },

  // LIFECYCLE PROMOTION REQUESTS
  {
    id: 7,
    type: REQUEST_TYPES.LIFECYCLE_PROMOTION,
    applicationId: 3, // TicketTamer
    requesterId: 1, // Alice Johnson
    title: "Promote TicketTamer to Production",
    description: "Request to move TicketTamer from Testing to Production stage",
    businessJustification: "All tests passed, security review completed, ready for production deployment",
    priority: REQUEST_PRIORITY.HIGH,
    status: REQUEST_STATUS.SUBMITTED,
    fromStage: "Testing",
    toStage: "Production",
    timeline: "End of week",
    approvedBy: null,
    reviewedAt: null,
    requestedAt: "2026-03-02T16:45:00Z",
    adminNotes: null,
    requiredApprovals: ["security", "operations"],
    department: "Human Resources"
  },
  {
    id: 8,
    type: REQUEST_TYPES.LIFECYCLE_PROMOTION,
    applicationId: 4, // Deploy-O-Tron 5000
    requesterId: 4, // David Wilson
    title: "Move to Testing Phase",
    description: "Request to promote Deploy-O-Tron from Development to Testing",
    businessJustification: "Core features completed, ready for user acceptance testing",
    priority: REQUEST_PRIORITY.MEDIUM,
    status: REQUEST_STATUS.APPROVED,
    fromStage: "Development",
    toStage: "Testing",
    timeline: "This week",
    approvedBy: 1,
    reviewedAt: "2026-03-01T13:20:00Z",
    requestedAt: "2026-02-29T11:15:00Z",
    adminNotes: "Approved. QA team has been notified.",
    requiredApprovals: ["qa", "product"],
    department: "Finance"
  },

  // TECHNOLOGY UPDATE REQUESTS
  {
    id: 9,
    type: REQUEST_TYPES.TECHNOLOGY_UPDATE,
    applicationId: 1, // Opendaw
    requesterId: 2, // Bob Smith
    title: "Upgrade React to Version 18",
    description: "Upgrade React from version 16 to 18 for better performance and new features",
    businessJustification: "Security updates, performance improvements, and access to new React features",
    priority: REQUEST_PRIORITY.MEDIUM,
    status: REQUEST_STATUS.APPROVED,
    currentTechnology: "React 16.14.0",
    proposedTechnology: "React 18.2.0",
    timeline: "Q2 2026",
    approvedBy: 1,
    reviewedAt: "2026-03-01T09:30:00Z",
    requestedAt: "2026-02-28T10:15:00Z",
    adminNotes: "Approved. Migration plan reviewed and accepted.",
    estimatedEffort: "2-3 weeks",
    department: "Customer Experience"
  },
  {
    id: 10,
    type: REQUEST_TYPES.TECHNOLOGY_UPDATE,
    applicationId: 6, // LogGoblin
    requesterId: 3, // Carol Davis
    title: "Database Migration to PostgreSQL",
    description: "Migrate from MySQL to PostgreSQL for better performance and features",
    businessJustification: "Better JSON support, improved performance for log queries, cost savings",
    priority: REQUEST_PRIORITY.LOW,
    status: REQUEST_STATUS.SUBMITTED,
    currentTechnology: "MySQL 8.0",
    proposedTechnology: "PostgreSQL 15",
    timeline: "Q4 2026",
    approvedBy: null,
    reviewedAt: null,
    requestedAt: "2026-03-02T15:45:00Z",
    adminNotes: null,
    estimatedEffort: "4-6 weeks",
    department: "DevOps"
  },

  // BUG REPORTS
  {
    id: 11,
    type: REQUEST_TYPES.BUG_REPORT,
    applicationId: 9, // IncidentBingo
    requesterId: 4, // David Wilson
    title: "Email Notifications Not Working",
    description: "Email notifications for new incidents are not being sent to the on-call team",
    businessJustification: "Critical for incident response, team missing important alerts",
    priority: REQUEST_PRIORITY.URGENT,
    status: REQUEST_STATUS.SUBMITTED,
    bugSeverity: "critical",
    reproducible: true,
    timeline: "Immediate fix needed",
    assignedTo: 1,
    reviewedAt: "2026-03-02T09:30:00Z",
    requestedAt: "2026-03-02T14:45:00Z",
    adminNotes: "Investigating SMTP configuration issues",
    estimatedResolutionTime: "24 hours",
    department: "SRE"
  },
  {
    id: 12,
    type: REQUEST_TYPES.BUG_REPORT,
    applicationId: 8, // DocuDuctTape
    requesterId: 2, // Bob Smith
    title: "Search Function Returns Incorrect Results",
    description: "Document search is returning unrelated results and missing relevant documents",
    businessJustification: "Users can't find critical documentation, impacting productivity",
    priority: REQUEST_PRIORITY.HIGH,
    status: REQUEST_STATUS.SUBMITTED,
    bugSeverity: "major",
    reproducible: true,
    timeline: "Within 1 week",
    assignedTo: null,
    reviewedAt: null,
    requestedAt: "2026-03-02T12:15:00Z",
    adminNotes: null,
    estimatedResolutionTime: "3-5 days",
    department: "Engineering"
  },

  // FEATURE REQUESTS
  {
    id: 13,
    type: REQUEST_TYPES.FEATURE_REQUEST,
    applicationId: 1, // Opendaw
    requesterId: 3, // Carol Davis
    title: "Dark Mode Support",
    description: "Add dark mode theme option for better user experience",
    businessJustification: "Requested by multiple users, improves accessibility and reduces eye strain",
    priority: REQUEST_PRIORITY.LOW,
    status: REQUEST_STATUS.APPROVED,
    requestedFeatures: ["dark-theme", "theme-switcher", "user-preferences"],
    timeline: "Q3 2026",
    approvedBy: 1,
    reviewedAt: "2026-03-01T16:20:00Z",
    requestedAt: "2026-03-05T11:30:00Z",
    adminNotes: "Added to product roadmap. Low priority but valuable UX improvement.",
    estimatedEffort: "1-2 weeks",
    department: "Supply Chain"
  },
  {
    id: 14,
    type: REQUEST_TYPES.FEATURE_REQUEST,
    applicationId: 10, // PatchyMcPatchface
    requesterId: 4, // David Wilson
    title: "Automated Rollback Feature",
    description: "Add automatic rollback capability when patches fail",
    businessJustification: "Reduce downtime and manual intervention during patch failures",
    priority: REQUEST_PRIORITY.MEDIUM,
    status: REQUEST_STATUS.SUBMITTED,
    requestedFeatures: ["auto-rollback", "failure-detection", "notification-system"],
    timeline: "Q2 2026",
    approvedBy: 1,
    reviewedAt: "2026-03-01T10:45:00Z",
    requestedAt: "2026-02-29T14:20:00Z",
    adminNotes: "High value feature. Development started.",
    estimatedEffort: "3-4 weeks",
    department: "Finance"
  },

  // FEEDBACK REQUESTS (for collecting structured feedback)
  {
    id: 15,
    type: REQUEST_TYPES.FEEDBACK,
    applicationId: 7, // Onboard-O-Matic
    requesterId: 1, // Alice Johnson
    title: "User Experience Feedback Collection",
    description: "Collect feedback from HR team before retiring the application",
    businessJustification: "Ensure replacement system addresses all current use cases",
    priority: REQUEST_PRIORITY.MEDIUM,
    status: REQUEST_STATUS.APPROVED,
    feedbackType: "user-experience",
    timeline: "Completed",
    approvedBy: null,
    reviewedAt: "2026-02-15T14:30:00Z",
    requestedAt: "2026-02-10T09:00:00Z",
    adminNotes: "Feedback collected from 12 users. Summary report generated.",
    responseCount: 12,
    department: "HR"
  },

  // Additional requests for Application ID 1 (Opendaw) to demonstrate multiple requests per app
  {
    id: 16,
    type: REQUEST_TYPES.ACCESS,
    applicationId: 1, // Opendaw
    requesterId: 4, // David Wilson
    title: "Opendaw Access for Finance Dashboard Integration",
    description: "Need access to Opendaw customer data for our new finance dashboard. We're building reports that need customer metrics and want to integrate with the existing customer portal APIs.",
    businessJustification: "Finance team needs customer data for executive reporting and budget planning",
    priority: REQUEST_PRIORITY.MEDIUM,
    status: REQUEST_STATUS.SUBMITTED,
    requestedAccess: ["read"],
    timeline: "Next week",
    approvedBy: null,
    reviewedAt: null,
    requestedAt: "2026-03-04T09:30:00Z",
    adminNotes: null,
    estimatedCost: null,
    department: "Finance"
  },
  {
    id: 17,
    type: REQUEST_TYPES.SUPPORT,
    applicationId: 1, // Opendaw  
    requesterId: 3, // Carol Davis
    title: "Performance Issue During Peak Hours",
    description: "The Opendaw system is experiencing significant slowdowns during peak hours (8-10 AM). Users are reporting timeout errors and slow page loads. This is affecting our customer onboarding process.",
    businessJustification: "Critical for customer experience and onboarding success rates",
    priority: REQUEST_PRIORITY.HIGH,
    status: REQUEST_STATUS.SUBMITTED,
    issueType: "performance",
    timeline: "ASAP",
    assignedTo: null,
    reviewedAt: null,
    requestedAt: "2026-03-04T07:15:00Z", 
    adminNotes: null,
    estimatedResolutionTime: "1-2 weeks",
    department: "Supply Chain"
  },

  // Bob's original Opendaw reuse request (was missing from allRequests)
  {
    id: 18,
    type: REQUEST_TYPES.REUSE,
    applicationId: 1, // Opendaw
    requesterId: 2, // Bob Smith
    title: "Reuse User Management System for Partner Portal",
    description: "Need similar user authentication for external partners",
    businessJustification: "Partner portal needs user management functionality similar to Opendaw",
    priority: REQUEST_PRIORITY.MEDIUM,
    status: REQUEST_STATUS.APPROVED,
    requestedComponents: ["authentication", "user-management"],
    timeline: "Q2 2026",
    approvedBy: 1,
    reviewedAt: "2026-02-26T11:45:00Z",
    requestedAt: "2026-02-25T09:15:00Z",
    adminNotes: "Great fit for partner portal needs",
    estimatedCost: 3000,
    department: "Engineering"
  },

  // Emma's requests (new user from Marketing)
  {
    id: 19,
    type: REQUEST_TYPES.REUSE,
    applicationId: 67, // FrontendPhoenix
    requesterId: 5, // Emma Rodriguez
    title: "Modern UI Components for Marketing Campaigns",
    description: "Need modern UI components for marketing campaigns",
    businessJustification: "Marketing team requires updated interface design for new campaign tools",
    priority: REQUEST_PRIORITY.MEDIUM,
    status: REQUEST_STATUS.SUBMITTED,
    requestedComponents: ["ui-components", "theme-system"],
    timeline: "Q2 2026",
    approvedBy: null,
    reviewedAt: null,
    requestedAt: "2026-03-03T14:30:00Z",
    adminNotes: null,
    estimatedCost: 2500,
    department: "Marketing"
  },
  {
    id: 20,
    type: REQUEST_TYPES.REUSE,
    applicationId: 55, // NotificationNomad
    requesterId: 5, // Emma Rodriguez
    title: "Notification System for Marketing Alerts",
    description: "Reuse notification system for marketing alerts",
    businessJustification: "Campaign notifications need multi-channel delivery capabilities",
    priority: REQUEST_PRIORITY.MEDIUM,
    status: REQUEST_STATUS.SUBMITTED,
    requestedComponents: ["notification-engine", "multi-channel"],
    timeline: "Q2 2026",
    approvedBy: null,
    reviewedAt: null,
    requestedAt: "2026-03-04T10:15:00Z",
    adminNotes: null,
    estimatedCost: 1500,
    department: "Marketing"
  },
  {
    id: 21,
    type: REQUEST_TYPES.ACCESS,
    applicationId: 27, // PasswordPal
    requesterId: 5, // Emma Rodriguez
    title: "Password Management for Campaign Tools",
    description: "Integrate password management for campaign tools",
    businessJustification: "Marketing team needs secure credential management for external tools",
    priority: REQUEST_PRIORITY.LOW,
    status: REQUEST_STATUS.APPROVED,
    requestedAccess: ["read", "write"],
    timeline: "Q3 2026",
    approvedBy: 1,
    reviewedAt: "2026-03-01T11:40:00Z",
    requestedAt: "2026-03-02T16:20:00Z",
    adminNotes: "PasswordPal integration approved for marketing tools",
    estimatedCost: null,
    department: "Marketing"
  },

  // REJECTED REQUESTS
  {
    id: 24,
    type: REQUEST_TYPES.REUSE,
    applicationId: 2, // LogGoblin
    requesterId: 2, // Bob Smith
    title: "Reuse LogGoblin for External Customer Analytics",
    description: "Want to adapt LogGoblin for analyzing external customer behavior logs",
    businessJustification: "Would help us better understand customer patterns outside our main platform",
    priority: REQUEST_PRIORITY.MEDIUM,
    status: REQUEST_STATUS.REJECTED,
    requestedAccess: ["read", "modify"],
    timeline: "Q2 2026",
    approvedBy: 1, // Alice Johnson
    reviewedAt: "2026-03-02T09:15:00Z",
    requestedAt: "2026-02-29T11:30:00Z",
    adminNotes: "LogGoblin contains proprietary algorithms not suitable for external customer data processing. Consider using third-party analytics tools instead.",
    estimatedCost: null,
    department: "Marketing"
  },

  {
    id: 25,
    type: REQUEST_TYPES.ACCESS,
    applicationId: 5, // DataDragon
    requesterId: 3, // Emma Rodriguez
    title: "Admin Access to DataDragon",
    description: "Requesting admin level access to DataDragon for data migration project",
    businessJustification: "Need to migrate legacy data structures and require admin privileges",
    priority: REQUEST_PRIORITY.HIGH,
    status: REQUEST_STATUS.REJECTED,
    requestedAccess: ["admin", "delete", "modify_schema"],
    timeline: "Immediate",
    approvedBy: 1, // Alice Johnson  
    reviewedAt: "2026-03-01T16:45:00Z",
    requestedAt: "2026-03-04T13:20:00Z",
    adminNotes: "Admin access too broad for this use case. Standard data migration can be handled with existing tools. Please work with IT team for proper data migration procedures.",
    estimatedCost: null,
    department: "IT"
  },

  // DELETED REQUESTS
  {
    id: 22,
    type: REQUEST_TYPES.FEATURE_REQUEST,
    applicationId: 3, // IncidentBingo
    requesterId: 2, // Bob Smith
    title: "Add SMS Notifications to IncidentBingo",
    description: "Request to add SMS notification feature for critical incidents",
    businessJustification: "Would improve response times for critical incidents when team members are away from email",
    priority: REQUEST_PRIORITY.LOW,
    status: REQUEST_STATUS.DELETED,
    requestedAccess: null,
    timeline: "Future enhancement",
    approvedBy: null,
    reviewedAt: null,
    requestedAt: "2024-02-25T10:15:00Z",
    adminNotes: "Request withdrawn by user - found alternative notification system",
    estimatedCost: 15000,
    department: "IT"
  },

  {
    id: 23,
    type: REQUEST_TYPES.SUPPORT,
    applicationId: 7, // MetricMagnet
    requesterId: 3, // Emma Rodriguez
    title: "Training Session for MetricMagnet Advanced Features",
    description: "Requesting training session for advanced reporting and dashboard creation in MetricMagnet",
    businessJustification: "Marketing team needs to create custom performance dashboards",
    priority: REQUEST_PRIORITY.LOW,
    status: REQUEST_STATUS.DELETED,
    requestedAccess: null,
    timeline: "Within 2 weeks",
    approvedBy: null,
    reviewedAt: null,
    requestedAt: "2024-02-20T14:45:00Z",
    adminNotes: "User found online training resources sufficient, request no longer needed",
    estimatedCost: null,
    department: "Marketing"
  }
];

// Helper functions to query requests
const getRequestsByType = (type) => {
  return allRequests.filter(request => request.type === type);
};

const getRequestsByApplication = (applicationId) => {
  return allRequests.filter(request => request.applicationId === parseInt(applicationId));
};

const getRequestsByUser = (userId) => {
  return allRequests.filter(request => request.requesterId === parseInt(userId));
};

const getRequestsByStatus = (status) => {
  return allRequests.filter(request => request.status === status);
};

const getRequestsByPriority = (priority) => {
  return allRequests.filter(request => request.priority === priority);
};

const getRequestsByDepartment = (department) => {
  return allRequests.filter(request => request.department === department);
};

// Statistics helpers
const getRequestStats = () => {
  const stats = {
    total: allRequests.length,
    byType: {},
    byStatus: {},
    byPriority: {},
    byDepartment: {}
  };

  // Count by type
  Object.values(REQUEST_TYPES).forEach(type => {
    stats.byType[type] = getRequestsByType(type).length;
  });

  // Count by status
  Object.values(REQUEST_STATUS).forEach(status => {
    stats.byStatus[status] = getRequestsByStatus(status).length;
  });

  // Count by priority
  Object.values(REQUEST_PRIORITY).forEach(priority => {
    stats.byPriority[priority] = getRequestsByPriority(priority).length;
  });

  // Count by department
  const departments = [...new Set(allRequests.map(r => r.department))];
  departments.forEach(dept => {
    stats.byDepartment[dept] = getRequestsByDepartment(dept).length;
  });

  return stats;
};

module.exports = {
  allRequests,
  REQUEST_TYPES,
  REQUEST_STATUS,
  REQUEST_PRIORITY,
  getRequestsByType,
  getRequestsByApplication,
  getRequestsByUser,
  getRequestsByStatus,
  getRequestsByPriority,
  getRequestsByDepartment,
  getRequestStats
};
