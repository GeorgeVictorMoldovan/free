const express = require('express');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const { users } = require('../data/mockData');
const { generateToken, authenticateToken, getCurrentUser } = require('../middleware/auth');

const router = express.Router();

// Track failed login attempts per IP
const failedAttempts = new Map();

// Rate limiting for failed login attempts only
const failedLoginLimiter = (req, res, next) => {
  const clientIP = req.ip || req.connection.remoteAddress;
  const now = Date.now();
  const windowMs = 15 * 60 * 1000; // 15 minutes
  const maxAttempts = 5;

  // Clean up old attempts
  const attempts = failedAttempts.get(clientIP) || [];
  const validAttempts = attempts.filter(timestamp => now - timestamp < windowMs);
  
  if (validAttempts.length >= maxAttempts) {
    return res.status(429).json({
      success: false,
      error: 'Too many login attempts, please try again in 15 minutes'
    });
  }
  
  // Store the limiter function for use after password check
  req.recordFailedAttempt = () => {
    validAttempts.push(now);
    failedAttempts.set(clientIP, validAttempts);
  };
  
  req.clearFailedAttempts = () => {
    failedAttempts.delete(clientIP);
  };
  
  next();
};

// POST /auth/login - User login
router.post('/login', failedLoginLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validation
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Email and password are required'
      });
    }

    // Find user by email
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    
    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Invalid credentials'
      });
    }

    // Check if user is active
    if (user.status !== 'active') {
      return res.status(401).json({
        success: false,
        error: 'Account is not active'
      });
    }

    // Verify password (demo: using plain text comparison)
    // In production, use: const isValidPassword = await bcrypt.compare(password, user.password);
    const isValidPassword = password === user.password;
    
    if (!isValidPassword) {
      // Record failed attempt only when password is incorrect
      req.recordFailedAttempt();
      
      return res.status(401).json({
        success: false,
        error: 'Invalid credentials'
      });
    }

    // Clear failed attempts on successful login
    req.clearFailedAttempts();

    // Update last login
    user.lastLogin = new Date().toISOString();

    // Generate token
    const token = generateToken(user);

    // Return user data (without password) and token
    const { password: _, ...userWithoutPassword } = user;
    
    res.json({
      success: true,
      message: 'Login successful',
      data: {
        user: userWithoutPassword,
        token,
        expiresIn: '24h'
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// POST /auth/logout - User logout (optional - mainly for logging)
router.post('/logout', authenticateToken, (req, res) => {
  try {
    // In a real app, you might want to blacklist the token
    res.json({
      success: true,
      message: 'Logout successful'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// GET /auth/me - Get current user info
router.get('/me', authenticateToken, (req, res) => {
  try {
    const user = getCurrentUser(req);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.json({
      success: true,
      data: user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// POST /auth/refresh - Refresh token (optional)
router.post('/refresh', authenticateToken, (req, res) => {
  try {
    const user = getCurrentUser(req);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Generate new token
    const token = generateToken(user);

    res.json({
      success: true,
      data: {
        token,
        expiresIn: '24h'
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

// GET /auth/demo-credentials - Get demo login credentials (remove in production)
router.get('/demo-credentials', (req, res) => {
  res.json({
    success: true,
    message: 'Demo credentials for testing',
    data: {
      admin: {
        email: 'alice.johnson@company.com',
        password: 'password123',
        role: 'admin',
        description: 'Catalog Admin - Can approve requests and manage applications'
      },
      requester: {
        email: 'bob.smith@company.com',
        password: 'password123',
        role: 'requester',
        description: 'Regular User - Can discover, request reuse, and provide feedback'
      }
    }
  });
});

module.exports = router;
