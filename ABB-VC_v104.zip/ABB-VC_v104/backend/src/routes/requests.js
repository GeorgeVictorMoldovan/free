const express = require('express');
const router = express.Router();
const { authenticateToken, requirePermission } = require('../middleware/auth');
const { users, applications } = require('../data/mockData');
const { 
  allRequests, 
  REQUEST_TYPES, 
  REQUEST_STATUS, 
  REQUEST_PRIORITY,
  getRequestsByType,
  getRequestsByApplication,
  getRequestsByUser,
  getRequestsByStatus,
  getRequestsByPriority,
  getRequestsByDepartment,
  getRequestStats
} = require('../data/requestsData');

// Helper function to find items by ID
const findById = (array, id) => array.find(item => item.id === parseInt(id));

// Helper function to enrich request data with user and application info
const enrichRequestData = (request) => {
  const requester = findById(users, request.requesterId);
  const approver = request.approvedBy ? findById(users, request.approvedBy) : null;
  const assignee = request.assignedTo ? findById(users, request.assignedTo) : null;
  const application = findById(applications, request.applicationId);

  return {
    ...request,
    requester: requester ? { 
      id: requester.id, 
      name: requester.name, 
      email: requester.email,
      department: requester.department 
    } : null,
    approver: approver ? { 
      id: approver.id, 
      name: approver.name, 
      email: approver.email 
    } : null,
    assignee: assignee ? { 
      id: assignee.id, 
      name: assignee.name, 
      email: assignee.email 
    } : null,
    application: application ? { 
      id: application.id, 
      name: application.name,
      owner: application.owner,
      lifecycle: application.lifecycle
    } : null
  };
};

// GET /api/requests - Get all requests with filtering (requires authentication)
router.get('/', authenticateToken, (req, res) => {
  try {
    const { 
      type, 
      applicationId, 
      userId, 
      status, 
      priority, 
      department,
      limit = 50,
      offset = 0
    } = req.query;

    let filteredRequests = [...allRequests];

    // PERMISSION CONTROL: Non-admin users can only see their own requests
    const currentUser = req.user;
    if (!currentUser.permissions.includes('admin')) {
      filteredRequests = filteredRequests.filter(r => 
        r.requesterId === currentUser.id
      );
    }

    // Apply filters
    if (type) {
      filteredRequests = filteredRequests.filter(r => r.type === type);
    }
    
    if (applicationId) {
      filteredRequests = filteredRequests.filter(r => 
        r.applicationId === parseInt(applicationId)
      );
    }
    
    if (userId && currentUser.permissions.includes('admin')) {
      // Only admins can filter by specific user ID
      filteredRequests = filteredRequests.filter(r => 
        r.requesterId === parseInt(userId)
      );
    }
    
    if (status) {
      filteredRequests = filteredRequests.filter(r => r.status === status);
    }
    
    if (priority) {
      filteredRequests = filteredRequests.filter(r => r.priority === priority);
    }
    
    if (department && currentUser.permissions.includes('admin')) {
      // Only admins can filter by department
      filteredRequests = filteredRequests.filter(r => 
        r.department.toLowerCase() === department.toLowerCase()
      );
    }

    // Sort by most recent first
    filteredRequests.sort((a, b) => new Date(b.requestedAt) - new Date(a.requestedAt));

    // Apply pagination
    const startIndex = parseInt(offset);
    const endIndex = startIndex + parseInt(limit);
    const paginatedRequests = filteredRequests.slice(startIndex, endIndex);

    // Enrich with user and application data
    const enrichedRequests = paginatedRequests.map(enrichRequestData);

    res.json({
      success: true,
      data: enrichedRequests,
      pagination: {
        total: filteredRequests.length,
        offset: startIndex,
        limit: parseInt(limit),
        hasMore: endIndex < filteredRequests.length
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/requests/unread - Get unread requests count (admin only)
router.get('/unread', authenticateToken, requirePermission('admin'), (req, res) => {
  try {
    // Count submitted requests that haven't been read by any admin
    const unreadRequests = allRequests.filter(request => 
      request.status === REQUEST_STATUS.SUBMITTED && !request.readBy
    );
    
    res.json({
      success: true,
      data: {
        count: unreadRequests.length,
        requests: unreadRequests.map(enrichRequestData)
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/requests/status-changes - Get count of requests with unseen status changes (for regular users)
router.get('/status-changes', authenticateToken, (req, res) => {
  try {
    const userId = req.user.id;
    
    // Get user's requests that have status changes they haven't seen
    const requestsWithStatusChanges = allRequests.filter(request => {
      if (request.requesterId !== userId) return false;
      
      // Only count requests that have been reviewed (have reviewedAt timestamp)
      if (!request.reviewedAt) return false;
      
      // Compare reviewedAt with lastViewedByUser
      const reviewedAt = new Date(request.reviewedAt);
      const lastViewed = request.lastViewedByUser ? new Date(request.lastViewedByUser) : new Date(0);
      
      // Status change is unseen if it happened after user last viewed
      return reviewedAt > lastViewed;
    });
    
    res.json({
      success: true,
      data: {
        count: requestsWithStatusChanges.length,
        requests: requestsWithStatusChanges.map(enrichRequestData)
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/requests/stats - Get request statistics
router.get('/stats', (req, res) => {
  try {
    const stats = getRequestStats();
    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/requests/types - Get available request types
router.get('/types', (req, res) => {
  try {
    res.json({
      success: true,
      data: {
        types: REQUEST_TYPES,
        statuses: REQUEST_STATUS,
        priorities: REQUEST_PRIORITY
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/requests/:id - Get specific request (requires authentication)
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const requestId = parseInt(req.params.id);
    const request = findById(allRequests, requestId);
    
    if (!request) {
      return res.status(404).json({ 
        success: false, 
        error: 'Request not found' 
      });
    }

    // PERMISSION CONTROL: Non-admin users can only see their own requests
    const currentUser = req.user;
    if (!currentUser.permissions.includes('admin') && request.requesterId !== currentUser.id) {
      return res.status(403).json({
        success: false,
        error: 'Access denied. You can only view your own requests.'
      });
    }

    const enrichedRequest = enrichRequestData(request);
    
    res.json({
      success: true,
      data: enrichedRequest
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/requests/app/:applicationId - Get requests for specific application
router.get('/app/:applicationId', (req, res) => {
  try {
    const applicationId = parseInt(req.params.applicationId);
    const requests = getRequestsByApplication(applicationId);
    
    // Sort by most recent first
    requests.sort((a, b) => new Date(b.requestedAt) - new Date(a.requestedAt));
    
    const enrichedRequests = requests.map(enrichRequestData);
    
    res.json({
      success: true,
      data: enrichedRequests,
      count: enrichedRequests.length
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/requests/user/:userId - Get requests by specific user (requires authentication)
router.get('/user/:userId', authenticateToken, (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const currentUser = req.user;
    
    // PERMISSION CONTROL: Users can only see their own requests, admins can see any user's requests
    if (!currentUser.permissions.includes('admin') && userId !== currentUser.id) {
      return res.status(403).json({
        success: false,
        error: 'Access denied. You can only view your own requests.'
      });
    }
    
    const requests = getRequestsByUser(userId);
    
    // Sort by most recent first
    requests.sort((a, b) => new Date(b.requestedAt) - new Date(a.requestedAt));
    
    const enrichedRequests = requests.map(enrichRequestData);
    
    res.json({
      success: true,
      data: enrichedRequests,
      count: enrichedRequests.length
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST /api/requests - Create new request (authenticated users)
router.post('/', authenticateToken, requirePermission('request'), (req, res) => {
  try {
    const { 
      type,
      applicationId, 
      title,
      description,
      businessJustification,
      priority = REQUEST_PRIORITY.MEDIUM,
      timeline,
      requestedAccess,
      requestedComponents,
      issueType,
      bugSeverity,
      currentTechnology,
      proposedTechnology,
      requestedFeatures,
      feedbackType,
      fromStage,
      toStage,
      requiredApprovals
    } = req.body;

    // Validate required fields
    if (!type || !applicationId || !title || !description) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: type, applicationId, title, description'
      });
    }

    // Validate request type
    if (!Object.values(REQUEST_TYPES).includes(type)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid request type'
      });
    }

    // Get user info from token
    const userId = req.user.id;
    const user = findById(users, userId);

    // Prevent admins from creating requests - they can only review requests
    if (req.user.permissions.includes('admin')) {
      return res.status(403).json({
        success: false,
        error: 'Admins cannot submit requests. Admins can only review and approve/reject requests from other users.'
      });
    }

    // Check if user already has a submitted or approved request for this application
    // Users can submit new requests if their previous request was rejected or deleted
    const existingRequest = allRequests.find(request => 
      request.requesterId === userId && 
      request.applicationId === parseInt(applicationId) && 
      (request.status === REQUEST_STATUS.SUBMITTED || request.status === REQUEST_STATUS.APPROVED)
    );

    if (existingRequest) {
      return res.status(400).json({
        success: false,
        error: `You already have a ${existingRequest.status} request for this application. Please wait for admin review.`
      });
    }

    // Clean up old rejected/deleted requests for this user and application
    // Remove any existing rejected or deleted requests to keep data clean
    const initialLength = allRequests.length;
    for (let i = allRequests.length - 1; i >= 0; i--) {
      const request = allRequests[i];
      if (request.requesterId === userId && 
          request.applicationId === parseInt(applicationId) &&
          (request.status === REQUEST_STATUS.REJECTED || request.status === REQUEST_STATUS.DELETED)) {
        allRequests.splice(i, 1);
      }
    }

    // Create new request
    const newRequest = {
      id: allRequests.length > 0 ? Math.max(...allRequests.map(r => r.id)) + 1 : 1,
      type,
      applicationId: parseInt(applicationId),
      requesterId: userId,
      title,
      description,
      businessJustification,
      priority,
      status: REQUEST_STATUS.SUBMITTED,
      timeline,
      approvedBy: null,
      assignedTo: null,
      reviewedAt: null,
      requestedAt: new Date().toISOString(),
      adminNotes: null,
      department: user?.department || 'Unknown'
    };

    // Add type-specific fields
    if (type === REQUEST_TYPES.ACCESS && requestedAccess) {
      newRequest.requestedAccess = requestedAccess;
    }
    
    if (type === REQUEST_TYPES.REUSE && requestedComponents) {
      newRequest.requestedComponents = requestedComponents;
    }
    
    if (type === REQUEST_TYPES.SUPPORT && issueType) {
      newRequest.issueType = issueType;
    }
    
    if (type === REQUEST_TYPES.BUG_REPORT && bugSeverity) {
      newRequest.bugSeverity = bugSeverity;
      newRequest.reproducible = true;
    }
    
    if (type === REQUEST_TYPES.TECHNOLOGY_UPDATE) {
      newRequest.currentTechnology = currentTechnology;
      newRequest.proposedTechnology = proposedTechnology;
    }
    
    if (type === REQUEST_TYPES.FEATURE_REQUEST && requestedFeatures) {
      newRequest.requestedFeatures = requestedFeatures;
    }
    
    if (type === REQUEST_TYPES.FEEDBACK && feedbackType) {
      newRequest.feedbackType = feedbackType;
    }
    
    if (type === REQUEST_TYPES.LIFECYCLE_PROMOTION) {
      newRequest.fromStage = fromStage;
      newRequest.toStage = toStage;
      newRequest.requiredApprovals = requiredApprovals || [];
    }

    // Add to requests array (in real app, this would save to database)
    allRequests.push(newRequest);

    // Return enriched request data
    const enrichedRequest = enrichRequestData(newRequest);

    res.status(201).json({
      success: true,
      message: 'Request created successfully',
      data: enrichedRequest
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// PUT /api/requests/:id/status - Update request status to ACCEPTED or REJECTED (admin only)
router.put('/:id/status', authenticateToken, requirePermission('admin'), (req, res) => {
  try {
    const requestId = parseInt(req.params.id);
    const { status, adminNotes, assignedTo } = req.body;
    
    const requestIndex = allRequests.findIndex(r => r.id === requestId);
    
    if (requestIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Request not found'
      });
    }

    const request = allRequests[requestIndex];

    // Check if request can still be modified 
    // Allow admins to change between submitted, approved, and rejected states
    const modifiableStatuses = [REQUEST_STATUS.SUBMITTED, REQUEST_STATUS.APPROVED, REQUEST_STATUS.REJECTED];
    if (!modifiableStatuses.includes(request.status)) {
      return res.status(400).json({
        success: false,
        error: `Cannot modify request with status "${request.status}". Only submitted, approved, and rejected requests can be modified.`
      });
    }

    // Validate status - only APPROVED and REJECTED allowed for admin actions
    if (![REQUEST_STATUS.APPROVED, REQUEST_STATUS.REJECTED].includes(status)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid status. Only "approved" and "rejected" are allowed.'
      });
    }

    // Update request
    const previousStatus = allRequests[requestIndex].status;
    const isStatusChange = previousStatus !== status;
    
    allRequests[requestIndex] = {
      ...allRequests[requestIndex],
      status,
      adminNotes: adminNotes || (isStatusChange ? 
        `Status changed from ${previousStatus} to ${status} by admin` : 
        allRequests[requestIndex].adminNotes),
      assignedTo: assignedTo || allRequests[requestIndex].assignedTo,
      reviewedAt: new Date().toISOString(),
      approvedBy: req.user.id
    };

    const enrichedRequest = enrichRequestData(allRequests[requestIndex]);

    res.json({
      success: true,
      message: `Request ${status} successfully`,
      data: enrichedRequest
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// PUT /api/requests/:id/delete - Mark request as deleted by user (user can only delete their own)
router.put('/:id/delete', authenticateToken, (req, res) => {
  try {
    const requestId = parseInt(req.params.id);
    const requestIndex = allRequests.findIndex(r => r.id === requestId);
    
    if (requestIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Request not found'
      });
    }

    const request = allRequests[requestIndex];
    
    // Check if user owns this request
    if (request.requesterId !== req.user.id) {
      return res.status(403).json({
        success: false,
        error: 'You can only delete your own requests'
      });
    }

    // Check if request can still be deleted (only submitted requests)
    if (request.status !== REQUEST_STATUS.SUBMITTED) {
      return res.status(400).json({
        success: false,
        error: 'Only submitted requests can be deleted'
      });
    }

    // Mark as deleted instead of actually deleting
    allRequests[requestIndex] = {
      ...allRequests[requestIndex],
      status: REQUEST_STATUS.DELETED,
      reviewedAt: new Date().toISOString(),
      adminNotes: 'Deleted by requestor'
    };

    const enrichedRequest = enrichRequestData(allRequests[requestIndex]);

    res.json({
      success: true,
      message: 'Request deleted successfully',
      data: enrichedRequest
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// PUT /api/requests/mark-viewed - Mark user's requests as viewed (for regular users)
router.put('/mark-viewed', authenticateToken, (req, res) => {
  try {
    const userId = req.user.id;
    
    // Update all user's requests to mark them as viewed
    allRequests.forEach((request, index) => {
      if (request.requesterId === userId) {
        allRequests[index] = {
          ...request,
          lastViewedByUser: new Date().toISOString()
        };
      }
    });

    res.json({
      success: true,
      message: 'Requests marked as viewed'
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// PUT /api/requests/:id/read - Mark request as read by admin (admin only)
router.put('/:id/read', authenticateToken, requirePermission('admin'), (req, res) => {
  try {
    const requestId = parseInt(req.params.id);
    const requestIndex = allRequests.findIndex(r => r.id === requestId);
    
    if (requestIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Request not found'
      });
    }

    // Mark as read by current admin
    allRequests[requestIndex] = {
      ...allRequests[requestIndex],
      readBy: req.user.id,
      readAt: new Date().toISOString()
    };

    const enrichedRequest = enrichRequestData(allRequests[requestIndex]);

    res.json({
      success: true,
      message: 'Request marked as read',
      data: enrichedRequest
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// DELETE /api/requests/:id - Delete request (admin only)
router.delete('/:id', authenticateToken, requirePermission('admin'), (req, res) => {
  try {
    const requestId = parseInt(req.params.id);
    const requestIndex = allRequests.findIndex(r => r.id === requestId);
    
    if (requestIndex === -1) {
      return res.status(404).json({
        success: false,
        error: 'Request not found'
      });
    }

    allRequests.splice(requestIndex, 1);

    res.json({
      success: true,
      message: 'Request deleted successfully'
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
