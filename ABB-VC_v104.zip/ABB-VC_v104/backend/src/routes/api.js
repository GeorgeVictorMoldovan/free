const express = require('express');
const router = express.Router();
const { 
  users, 
  applications, 
  feedback, 
  reuseRequests, 
  approvals, 
  LIFECYCLE_STAGES, 
  TECHNOLOGIES 
} = require('../data/mockData');
const { 
  authenticateToken, 
  requirePermission, 
  requireRole, 
  getCurrentUser 
} = require('../middleware/auth');

// Helper function to find item by ID
const findById = (array, id) => array.find(item => item.id === parseInt(id));

// Helper function to generate new ID
const generateId = (array) => Math.max(...array.map(item => item.id)) + 1;

// Helper function to calculate average rating (excluding zero-star ratings)
const calculateAverageRating = (feedbackList, applicationId) => {
  const appFeedback = feedbackList.filter(f => f.applicationId === applicationId);
  if (appFeedback.length === 0) return null;
  
  const categories = ['usability', 'stability', 'performance', 'documentation'];
  const averages = {};
  
  categories.forEach(category => {
    // Filter out zero-star ratings for this category
    const nonZeroRatings = appFeedback
      .map(feedback => feedback.ratings[category])
      .filter(rating => rating > 0);
    
    if (nonZeroRatings.length === 0) {
      averages[category] = 0; // No valid ratings for this category
    } else {
      const sum = nonZeroRatings.reduce((acc, rating) => acc + rating, 0);
      averages[category] = (sum / nonZeroRatings.length).toFixed(1);
    }
  });
  
  return averages;
};

// ============ USERS ENDPOINTS ============

// GET /api/users - Get all users (authenticated users can see basic info, admins see full details)
router.get('/users', authenticateToken, (req, res) => {
  try {
    let userData;
    
    if (req.user.permissions.includes('admin')) {
      // Admins get full user data
      userData = users;
    } else {
      // Regular users get only basic info (for rating display purposes)
      userData = users.map(user => ({
        id: user.id,
        name: user.name,
        department: user.department
      }));
    }
    
    res.json({
      success: true,
      data: userData,
      count: userData.length
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/users/:id - Get user by ID
router.get('/users/:id', (req, res) => {
  try {
    const user = findById(users, req.params.id);
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }
    res.json({ success: true, data: user });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============ APPLICATIONS ENDPOINTS ============

// GET /api/applications - Get all applications with filtering (authenticated users)
router.get('/applications', authenticateToken, (req, res) => {
  try {
    const { lifecycle, technology, team, search } = req.query;
    let filteredApps = [...applications];
    
    // Filter by lifecycle stage
    if (lifecycle && lifecycle !== 'all') {
      filteredApps = filteredApps.filter(app => 
        app.lifecycle.toLowerCase() === lifecycle.toLowerCase()
      );
    }
    
    // Filter by technology
    if (technology && technology !== 'all') {
      filteredApps = filteredApps.filter(app => 
        app.technology.some(tech => tech.toLowerCase().includes(technology.toLowerCase()))
      );
    }
    
    // Filter by team
    if (team && team !== 'all') {
      filteredApps = filteredApps.filter(app => 
        app.team.toLowerCase().includes(team.toLowerCase())
      );
    }
    
    // Search by name, description, or tags
    if (search) {
      const searchLower = search.toLowerCase();
      filteredApps = filteredApps.filter(app => 
        app.name.toLowerCase().includes(searchLower) ||
        app.description.toLowerCase().includes(searchLower) ||
        app.tags.some(tag => tag.toLowerCase().includes(searchLower))
      );
    }
    
    // Add average ratings to each app
    const appsWithRatings = filteredApps.map(app => ({
      ...app,
      averageRatings: calculateAverageRating(feedback, app.id),
      feedbackCount: feedback.filter(f => f.applicationId === app.id).length
    }));
    
    res.json({
      success: true,
      data: appsWithRatings,
      count: appsWithRatings.length
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/applications/:id - Get application by ID
router.get('/applications/:id', (req, res) => {
  try {
    const app = findById(applications, req.params.id);
    if (!app) {
      return res.status(404).json({ success: false, error: 'Application not found' });
    }
    
    const appFeedback = feedback.filter(f => f.applicationId === app.id);
    const appRequests = reuseRequests.filter(r => r.applicationId === app.id);
    
    const enrichedApp = {
      ...app,
      averageRatings: calculateAverageRating(feedback, app.id),
      feedback: appFeedback,
      reuseRequests: appRequests
    };
    
    res.json({ success: true, data: enrichedApp });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST /api/applications - Register new application (authenticated users)
router.post('/applications', authenticateToken, requirePermission('write'), (req, res) => {
  try {
    const { 
      name, 
      description, 
      owner, 
      team, 
      technology = [], 
      lifecycle = LIFECYCLE_STAGES.PLANNING 
    } = req.body;
    
    if (!name || !description || !owner || !team) {
      return res.status(400).json({ 
        success: false, 
        error: 'Name, description, owner, and team are required' 
      });
    }

    const newApp = {
      id: generateId(applications),
      name,
      description,
      owner,
      team,
      technology: Array.isArray(technology) ? technology : [technology],
      lifecycle,
      version: '0.1.0',
      deploymentDate: null,
      lastUpdated: new Date().toISOString(),
      usageMetrics: {
        monthlyUsers: 0,
        uptime: 0,
        performance: 0
      },
      documentation: '',
      repository: '',
      dependencies: [],
      tags: []
    };

    applications.push(newApp);
    res.status(201).json({ success: true, data: newApp });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// PUT /api/applications/:id - Update application (admin only)
router.put('/applications/:id', authenticateToken, requirePermission('admin'), (req, res) => {
  try {
    const app = findById(applications, req.params.id);
    if (!app) {
      return res.status(404).json({ success: false, error: 'Application not found' });
    }
    
    // Update fields
    Object.keys(req.body).forEach(key => {
      if (req.body[key] !== undefined) {
        app[key] = req.body[key];
      }
    });
    
    app.lastUpdated = new Date().toISOString();
    
    res.json({ success: true, data: app });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Lifecycle change log storage (in production, this would be a database table)
const lifecycleChangeLogs = [];

// PUT /api/applications/:id/lifecycle - Update application lifecycle (admin only)
router.put('/applications/:id/lifecycle', authenticateToken, requirePermission('admin'), (req, res) => {
  try {
    const { lifecycle, reason } = req.body;
    
    if (!lifecycle) {
      return res.status(400).json({ 
        success: false, 
        error: 'Lifecycle is required' 
      });
    }

    if (!reason || !reason.trim()) {
      return res.status(400).json({ 
        success: false, 
        error: 'Reason for lifecycle change is required' 
      });
    }

    // Validate lifecycle stage
    const validLifecycles = Object.values(LIFECYCLE_STAGES);
    if (!validLifecycles.includes(lifecycle)) {
      return res.status(400).json({ 
        success: false, 
        error: `Invalid lifecycle. Must be one of: ${validLifecycles.join(', ')}` 
      });
    }

    const app = findById(applications, req.params.id);
    if (!app) {
      return res.status(404).json({ success: false, error: 'Application not found' });
    }

    // Create lifecycle change log entry
    const changeLogEntry = {
      id: lifecycleChangeLogs.length + 1,
      applicationId: app.id,
      applicationName: app.name,
      previousLifecycle: app.lifecycle,
      newLifecycle: lifecycle,
      reason: reason.trim(),
      changedBy: req.user.id,
      changedByName: req.user.email, // In production, get full name
      timestamp: new Date().toISOString()
    };
    
    lifecycleChangeLogs.push(changeLogEntry);
    
    // Update application
    app.lifecycle = lifecycle;
    app.lastUpdated = new Date().toISOString();
    
    // Log lifecycle change for audit purposes
    
    res.json({ 
      success: true, 
      message: `Application lifecycle updated to ${lifecycle}`,
      data: app,
      changeLog: changeLogEntry
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/applications/:id/lifecycle-logs - Get lifecycle change logs for an application (admin only)
router.get('/applications/:id/lifecycle-logs', authenticateToken, requirePermission('admin'), (req, res) => {
  try {
    const appId = parseInt(req.params.id);
    const logs = lifecycleChangeLogs.filter(log => log.applicationId === appId);
    
    res.json({ 
      success: true, 
      data: logs 
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============ FEEDBACK ENDPOINTS ============

// GET /api/feedback - Get feedback with optional filters
router.get('/feedback', (req, res) => {
  try {
    const { applicationId } = req.query;
    let filteredFeedback = [...feedback];
    
    if (applicationId) {
      filteredFeedback = filteredFeedback.filter(f => 
        f.applicationId === parseInt(applicationId)
      );
    }
    
    // Enrich with user and application data
    const enrichedFeedback = filteredFeedback.map(f => {
      const user = f.userId ? findById(users, f.userId) : null;
      const app = findById(applications, f.applicationId);
      
      return {
        ...f,
        // Only include user name for admins, maintain privacy for regular users
        user: user && req.user?.permissions?.includes('admin') ? 
          { id: user.id, name: user.name, department: user.department } : 
          user ? { id: user.id } : null,
        application: app ? { id: app.id, name: app.name } : null
      };
    });
    
    res.json({
      success: true,
      data: enrichedFeedback,
      count: enrichedFeedback.length
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST /api/feedback - Submit feedback (authenticated users)
router.post('/feedback', authenticateToken, requirePermission('feedback'), (req, res) => {
  try {
    const { 
      applicationId, 
      userId, 
      ratings, 
      comment, 
      isAnonymous = false 
    } = req.body;
    
    if (!applicationId || !ratings) {
      return res.status(400).json({ 
        success: false, 
        error: 'Application ID and ratings are required' 
      });
    }
    
    const app = findById(applications, applicationId);
    if (!app) {
      return res.status(404).json({ success: false, error: 'Application not found' });
    }

    const newFeedback = {
      id: generateId(feedback),
      applicationId: parseInt(applicationId),
      userId: isAnonymous ? null : parseInt(userId),
      ratings,
      comment: comment || '',
      isAnonymous,
      createdAt: new Date().toISOString(),
      helpful: 0
    };

    feedback.push(newFeedback);
    res.status(201).json({ success: true, data: newFeedback });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============ REUSE REQUESTS ENDPOINTS ============

// GET /api/requests - Get reuse requests
router.get('/requests', (req, res) => {
  try {
    const { status, applicationId } = req.query;
    let filteredRequests = [...reuseRequests];
    
    if (status) {
      filteredRequests = filteredRequests.filter(r => r.status === status);
    }
    
    if (applicationId) {
      filteredRequests = filteredRequests.filter(r => 
        r.applicationId === parseInt(applicationId)
      );
    }
    
    // Enrich with user and application data
    const enrichedRequests = filteredRequests.map(request => {
      const requester = findById(users, request.requesterId);
      const reviewer = request.reviewedBy ? findById(users, request.reviewedBy) : null;
      const app = findById(applications, request.applicationId);
      
      return {
        ...request,
        requester: requester ? { id: requester.id, name: requester.name } : null,
        reviewer: reviewer ? { id: reviewer.id, name: reviewer.name } : null,
        application: app ? { id: app.id, name: app.name } : null
      };
    });
    
    res.json({
      success: true,
      data: enrichedRequests,
      count: enrichedRequests.length
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST /api/requests - Submit reuse request (authenticated users)
router.post('/requests', authenticateToken, requirePermission('request'), (req, res) => {
  try {
    const { 
      applicationId, 
      requesterId, 
      purpose, 
      businessJustification, 
      timeline 
    } = req.body;
    
    if (!applicationId || !requesterId || !purpose) {
      return res.status(400).json({ 
        success: false, 
        error: 'Application ID, requester ID, and purpose are required' 
      });
    }

    const newRequest = {
      id: generateId(reuseRequests),
      applicationId: parseInt(applicationId),
      requesterId: parseInt(requesterId),
      purpose,
      businessJustification: businessJustification || '',
      timeline: timeline || '',
      status: 'submitted',
      adminNotes: null,
      requestedAt: new Date().toISOString(),
      reviewedAt: null,
      reviewedBy: null
    };

    reuseRequests.push(newRequest);
    res.status(201).json({ success: true, data: newRequest });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============ ADMIN ENDPOINTS ============

// GET /api/admin/approvals - Get pending approvals (admin only)
router.get('/admin/approvals', authenticateToken, requirePermission('approve'), (req, res) => {
  try {
    const { status = 'submitted' } = req.query;
    
    let filteredApprovals = [...approvals];
    
    if (status !== 'all') {
      filteredApprovals = filteredApprovals.filter(a => a.status === status);
    }
    
    // Enrich with user and application data
    const enrichedApprovals = filteredApprovals.map(approval => {
      const requester = findById(users, approval.requesterId);
      const reviewer = approval.reviewedBy ? findById(users, approval.reviewedBy) : null;
      const app = findById(applications, approval.applicationId);
      
      return {
        ...approval,
        requester: requester ? { id: requester.id, name: requester.name } : null,
        reviewer: reviewer ? { id: reviewer.id, name: reviewer.name } : null,
        application: app ? { id: app.id, name: app.name } : null
      };
    });
    
    res.json({
      success: true,
      data: enrichedApprovals,
      count: enrichedApprovals.length
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST /api/admin/approve - Process approval (admin only)
router.post('/admin/approve', authenticateToken, requirePermission('approve'), (req, res) => {
  try {
    const { approvalId, decision, reviewerId, notes } = req.body;
    
    if (!approvalId || !decision || !reviewerId) {
      return res.status(400).json({ 
        success: false, 
        error: 'Approval ID, decision, and reviewer ID are required' 
      });
    }
    
    const approval = findById(approvals, approvalId);
    if (!approval) {
      return res.status(404).json({ success: false, error: 'Approval not found' });
    }
    
    approval.status = decision; // 'approved' or 'rejected'
    approval.reviewedAt = new Date().toISOString();
    approval.reviewedBy = parseInt(reviewerId);
    approval.adminNotes = notes || '';
    
    // If approved and it's a lifecycle change, update the application
    if (decision === 'approved' && approval.changeType === 'lifecycle_promotion') {
      const app = findById(applications, approval.applicationId);
      if (app) {
        app.lifecycle = approval.toStage;
        app.lastUpdated = new Date().toISOString();
      }
    }
    
    res.json({ success: true, data: approval });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============ DASHBOARD STATS ============

// GET /api/stats - Get dashboard statistics
router.get('/stats', (req, res) => {
  try {
    const lifecycleStats = {};
    Object.values(LIFECYCLE_STAGES).forEach(stage => {
      lifecycleStats[stage.toLowerCase()] = applications.filter(app => app.lifecycle === stage).length;
    });
    
    const stats = {
      totalApplications: applications.length,
      lifecycleStats,
      totalUsers: users.length,
      totalFeedback: feedback.length,
      pendingRequests: reuseRequests.filter(r => r.status === 'submitted').length,
      pendingApprovals: approvals.filter(a => a.status === 'pending').length,
      averageRating: {
        usability: (() => {
          const nonZeroRatings = feedback.map(f => f.ratings.usability).filter(r => r > 0);
          return nonZeroRatings.length > 0 ? (nonZeroRatings.reduce((sum, r) => sum + r, 0) / nonZeroRatings.length).toFixed(1) : '0.0';
        })(),
        stability: (() => {
          const nonZeroRatings = feedback.map(f => f.ratings.stability).filter(r => r > 0);
          return nonZeroRatings.length > 0 ? (nonZeroRatings.reduce((sum, r) => sum + r, 0) / nonZeroRatings.length).toFixed(1) : '0.0';
        })(),
        performance: (() => {
          const nonZeroRatings = feedback.map(f => f.ratings.performance).filter(r => r > 0);
          return nonZeroRatings.length > 0 ? (nonZeroRatings.reduce((sum, r) => sum + r, 0) / nonZeroRatings.length).toFixed(1) : '0.0';
        })(),
        documentation: (() => {
          const nonZeroRatings = feedback.map(f => f.ratings.documentation).filter(r => r > 0);
          return nonZeroRatings.length > 0 ? (nonZeroRatings.reduce((sum, r) => sum + r, 0) / nonZeroRatings.length).toFixed(1) : '0.0';
        })()
      }
    };

    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============ METADATA ENDPOINTS ============

// GET /api/metadata - Get lifecycle stages and technologies
router.get('/metadata', (req, res) => {
  try {
    res.json({
      success: true,
      data: {
        lifecycleStages: Object.values(LIFECYCLE_STAGES),
        technologies: Object.values(TECHNOLOGIES),
        teams: [...new Set(applications.map(app => app.team))]
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
