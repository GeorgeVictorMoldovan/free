# Admin Multi-Request View Documentation

## Overview
Admins can view and manage multiple requests per application since different users can submit various types of requests for the same application.

## Multi-Request Scenarios

### **Why Multiple Requests Per Application?**
- **Different Users**: Bob, Carol, David can all request access to the same app
- **Different Types**: One user might request access, another might request reuse
- **Different Times**: Requests come in at different periods
- **Different Purposes**: Each user has unique business needs for the same app

### **Example: Opendaw Application Requests**
```
Application: Opendaw (ID: 1)
├── Request #1: Bob Smith - Access Request (ACCEPTED)
├── Request #3: Carol Davis - Reuse Authentication Module (ACCEPTED)  
├── Request #9: Bob Smith - React Version Upgrade (ACCEPTED)
├── Request #13: Carol Davis - Dark Mode Feature (ACCEPTED)
├── Request #16: David Wilson - Finance Dashboard Access (PENDING)
└── Request #17: Carol Davis - Performance Issue Support (PENDING)
```

## Admin Interface Design

### **"Make a request" Tab for Admins**
When an admin views an application's "Make a request" tab, they see:

#### **Request List Format:**
```
┌─────────────────────────────────────────────────────────┐
│ 👤 Requester Name • 2 minutes ago                      │
│                                                         │
│ If you are going to use a passage of Lorem Ipsum,      │
│ you need to be sure there isn't anything embarrassing  │
│ hidden in the middle of text...                        │
│                                                         │
│ STATUS: Submitted                    [Reject] [Approve] │
└─────────────────────────────────────────────────────────┘
```

#### **Multiple Request Display:**
- **Chronological Order**: Most recent requests first
- **Individual Cards**: Each request in separate Paper component
- **Requester Attribution**: Shows who submitted each request
- **Time Context**: Shows when each request was submitted
- **Action Buttons**: Reject/Approve for pending requests only
- **Status History**: Shows processed requests with admin name and date

## Request Status Progression

### **For Each Individual Request:**
1. **User Submits** → Status: "Submitted" (pending)
2. **Admin Reviews** → Can see request in admin interface
3. **Admin Decides** → Reject or Approve
4. **Status Updates** → Shows admin name and date

### **Multiple Users, Same App:**
- User A submits access request → Admin sees it
- User B submits reuse request → Admin sees both requests
- User C submits support request → Admin sees all three requests
- Admin can approve/reject each request independently

## Admin Actions

### **Approve Button** (Green)
- Style: Outlined green button matching delete button design
- Action: Sets status to "accepted" 
- Result: "STATUS: Approved by [Admin Name] • [Date]"
- Hover: Darker green with light green background

### **Reject Button** (Red)  
- Style: Outlined red button matching delete button design
- Action: Sets status to "rejected"
- Result: "STATUS: Rejected by [Admin Name] • [Date]"
- Hover: Darker red with light red background

## Frontend Implementation

### **ApplicationDetail.jsx Admin View:**
```javascript
// For admins: fetch ALL requests for this application
const fetchAllAppRequests = async (applicationId) => {
  const response = await apiService.getRequestsByApp(applicationId)
  // Shows ALL requests from ALL users for this app
}

// Display each request with approve/reject buttons
allAppRequests.map((request) => (
  <Paper key={request.id}>
    <RequesterName /> • <TimeAgo />
    <RequestText />
    <StatusDisplay />
    {request.status === 'pending' && <ApproveRejectButtons />}
  </Paper>
))
```

### **API Integration:**
- `GET /api/requests/app/:applicationId` - Returns ALL requests for the application
- `PUT /api/requests/:id/status` - Admin approves/rejects individual requests
- Real-time updates after admin actions

## Business Logic

### **Request Independence:**
- Each request is processed independently
- Multiple users can have different request types for same app
- Admin approves/rejects based on individual merit
- No conflict between different users' requests

### **Use Cases:**
1. **Popular Application**: Many users want access → Multiple access requests
2. **Versatile System**: Users want different capabilities → Mixed request types
3. **Ongoing Issues**: Multiple support requests for different problems
4. **Evolution Requests**: Multiple enhancement requests from different teams

### **Admin Benefits:**
- **Complete Visibility**: See all user interest in each application
- **Bulk Management**: Process multiple requests for same app efficiently  
- **Usage Insights**: Understand which apps are in high demand
- **Request Patterns**: See common request types per application

## Testing Data

Application ID 1 (Opendaw) now has **6 requests from 3 different users**:
- **2 pending requests** (for testing admin actions)
- **4 processed requests** (demonstrating status history)
- **Mixed types**: access, reuse, support, feature, technology update requests
- **Different users**: Bob Smith, Carol Davis, David Wilson

This provides a comprehensive test environment for the admin multi-request management interface.
