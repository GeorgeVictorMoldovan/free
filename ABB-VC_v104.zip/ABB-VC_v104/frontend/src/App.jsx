import { Routes, Route, useLocation } from 'react-router-dom'
import { Box } from '@mui/material'
import { AuthProvider } from './contexts/AuthContext'
import { RequestsProvider } from './contexts/RequestsContext'
import Navbar from './components/Navbar'
import Sidebar from './components/Sidebar'
import ProtectedRoute from './components/ProtectedRoute'
import Dashboard from './pages/Dashboard'
import FindApp from './pages/FindApp'
import Applications from './pages/Applications'
import ApplicationDetail from './pages/ApplicationDetail'
import Feedback from './pages/Feedback'
import Requests from './pages/Requests'
import RequestsInbox from './pages/RequestsInbox'
import Admin from './pages/Admin'
import Login from './pages/Login'
import Unauthorized from './pages/Unauthorized'
import MostReused from './pages/MostReused'
import MostNeedsFilled from './pages/MostNeedsFilled'
import MostImproved from './pages/MostImproved'
import MostVerified from './pages/MostVerified'
import Settings from './pages/Settings'

function AppContent() {
  const location = useLocation()
  const isLoginPage = location.pathname === '/login' || location.pathname === '/unauthorized'
  
  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      {/* Removed Navbar */}
      {/* <Sidebar /> */}
      <Box 
        component="main" 
        sx={{ 
          flexGrow: 1,
          paddingTop: 0, // Remove padding since navbar is removed
          paddingLeft: 0, // Remove left padding since sidebar is hidden
        }}
      >
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/unauthorized" element={<Unauthorized />} />
              <Route path="/" element={
                <ProtectedRoute>
                  <FindApp />
                </ProtectedRoute>
              } />
              <Route path="/most-reused" element={
                <ProtectedRoute>
                  <MostReused />
                </ProtectedRoute>
              } />
              <Route path="/most-needs-filled" element={
                <ProtectedRoute>
                  <MostNeedsFilled />
                </ProtectedRoute>
              } />
              <Route path="/most-verified" element={
                <ProtectedRoute>
                  <MostVerified />
                </ProtectedRoute>
              } />
              <Route path="/most-improved" element={
                <ProtectedRoute>
                  <MostImproved />
                </ProtectedRoute>
              } />
              <Route path="/dashboard" element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              } />
              <Route path="/applications" element={
                <ProtectedRoute>
                  <Applications />
                </ProtectedRoute>
              } />
              <Route path="/applications/:id" element={
                <ProtectedRoute>
                  <ApplicationDetail />
                </ProtectedRoute>
              } />
              <Route path="/feedback" element={
                <ProtectedRoute>
                  <Feedback />
                </ProtectedRoute>
              } />
              <Route path="/requests" element={
                <ProtectedRoute>
                  <Requests />
                </ProtectedRoute>
              } />
              <Route path="/requests-inbox" element={
                <ProtectedRoute requiredPermission="admin">
                  <RequestsInbox />
                </ProtectedRoute>
              } />
              <Route path="/settings" element={
                <ProtectedRoute requiredPermission="admin">
                  <Settings />
                </ProtectedRoute>
              } />
              <Route path="/admin" element={
                <ProtectedRoute requiredPermission="admin">
                  <Admin />
                </ProtectedRoute>
              } />
            </Routes>
          </Box>
        </Box>
  )
}

function App() {
  return (
    <AuthProvider>
      <RequestsProvider>
        <AppContent />
      </RequestsProvider>
    </AuthProvider>
  )
}

export default App
