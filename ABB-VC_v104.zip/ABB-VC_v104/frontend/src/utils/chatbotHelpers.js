// Chatbot utility functions for better search and response logic

export const COMMON_PATTERNS = {
  incident: ['incident', 'bug', 'issue', 'problem', 'error', 'failure', 'broken', 'crash', 'wrong', 'broke', 'fixing', 'fix'],
  reporting: ['report', 'reporting', 'track', 'tracking', 'log', 'logging', 'record', 'capture', 'document', 'notes'],
  approvals: ['approval', 'approve', 'request', 'authorize', 'permission', 'sign-off', 'signoff', 'review', 'workflow'],
  vendor: ['vendor', 'supplier', 'external', 'third-party', 'contractor', 'partner', 'client', 'customer'],
  security: ['security', 'secure', 'auth', 'authentication', 'access', 'permission', 'login', 'password', 'safe', 'protect'],
  analytics: ['analytics', 'analyze', 'data', 'metrics', 'dashboard', 'chart', 'graph', 'stats', 'numbers', 'insights'],
  automation: ['automate', 'automatic', 'script', 'workflow', 'process', 'streamline', 'efficiency', 'faster', 'easier'],
  monitoring: ['monitor', 'monitoring', 'watch', 'alert', 'notification', 'notify', 'checking', 'status', 'health'],
  deployment: ['deploy', 'deployment', 'release', 'publish', 'update', 'launch', 'rollout', 'version', 'upgrade'],
  testing: ['test', 'testing', 'quality', 'qa', 'verification', 'validate', 'check', 'verify', 'trial'],
  documentation: ['document', 'documentation', 'doc', 'wiki', 'knowledge', 'guide', 'manual', 'instructions', 'help'],
  communication: ['chat', 'message', 'communicate', 'notification', 'email', 'talk', 'discuss', 'collaborate', 'team'],
  storage: ['store', 'storage', 'save', 'backup', 'archive', 'database', 'files', 'data', 'keep', 'organize'],
  integration: ['integrate', 'integration', 'connect', 'api', 'sync', 'link', 'combine', 'merge', 'join'],
  performance: ['performance', 'speed', 'fast', 'optimize', 'efficiency', 'slow', 'faster', 'better', 'improve'],
  financial: ['tax', 'taxes', 'finance', 'financial', 'accounting', 'invoice', 'billing', 'payment', 'budget', 'expense', 'money', 'cost'],
  frustrated: ['frustrated', 'annoying', 'hate', 'sick', 'tired', 'nightmare', 'pain', 'difficult', 'hard', 'struggle', 'drowning', 'overwhelmed'],
  collaboration: ['collaborate', 'team', 'together', 'share', 'work with', 'group', 'meeting', 'project', 'coordinate']
}

export const generateSearchTerms = (userInput) => {
  const input = userInput.toLowerCase()
  const detectedPatterns = []
  
  // Find matching patterns
  Object.entries(COMMON_PATTERNS).forEach(([category, keywords]) => {
    if (keywords.some(keyword => input.includes(keyword))) {
      detectedPatterns.push(category)
      // Add the actual keywords found
      keywords.forEach(keyword => {
        if (input.includes(keyword)) {
          detectedPatterns.push(keyword)
        }
      })
    }
  })
  
  // Add original words from user input
  const words = input.split(' ').filter(word => 
    word.length > 2 && 
    !['the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'can', 'had', 'her', 'was', 'one', 'our', 'out', 'day', 'get', 'has', 'him', 'how', 'man', 'new', 'now', 'old', 'see', 'two', 'way', 'who', 'boy', 'did', 'its', 'let', 'put', 'say', 'she', 'too', 'use'].includes(word)
  )
  
  return [...new Set([...detectedPatterns, ...words])]
}

export const enhancedSearchApplications = (applications, userInput) => {
  const searchTerms = generateSearchTerms(userInput)
  const results = []
  const MINIMUM_RELEVANCE_SCORE = 3 // Require meaningful matches

  applications.forEach(app => {
    let score = 0
    let hasStrongMatch = false
    const searchableText = `${app.name} ${app.description} ${app.team} ${app.technology?.join(' ') || ''}`.toLowerCase()

    // Calculate relevance score with pattern matching
    searchTerms.forEach(term => {
      if (term.length < 3) return // Skip very short terms
      
      if (searchableText.includes(term)) {
        if (app.name.toLowerCase().includes(term)) {
          score += 5 // High score for name matches
          hasStrongMatch = true
        } else if (app.description.toLowerCase().includes(term)) {
          score += 3 // Medium score for description matches
          hasStrongMatch = true
        } else if (app.team?.toLowerCase().includes(term)) {
          score += 2 // Team matches
        } else if (app.technology?.some(tech => tech.toLowerCase().includes(term))) {
          score += 2 // Technology matches
        } else {
          score += 1 // Very weak matches
        }
      }
    })

    // Only include if we have meaningful relevance and at least one strong match
    if (score >= MINIMUM_RELEVANCE_SCORE && hasStrongMatch) {
      // Bonus points for lifecycle stage (only applied to already relevant results)
      if (app.lifecycle === 'Active') score += 1
      else if (app.lifecycle === 'Pilot') score += 0.5
      
      results.push({ ...app, relevanceScore: score, matchedTerms: searchTerms })
    }
  })

  // Sort by relevance and return top 5
  return results
    .sort((a, b) => b.relevanceScore - a.relevanceScore)
    .slice(0, 5)
}

export const generateBotResponse = (userInput, searchResults) => {
  // Detect emotional tone from user input
  const isfrustrated = /frustrated|annoying|hate|sick|tired|nightmare|pain|difficult|hard|struggle|drowning|overwhelmed|crazy|insane|disaster|mess|killing|hell/.test(userInput.toLowerCase())
  
  if (searchResults.length === 0) {
    if (isfrustrated) {
      const frustratedResponses = [
        "Oh wow, I totally feel your pain on this one!",
        "Ugh, that sounds absolutely maddening!", 
        "I can practically hear the frustration in your message!",
        "That sounds like a real headache!"
      ]
      return frustratedResponses[Math.floor(Math.random() * frustratedResponses.length)]
    }
    return "Hmm, I'm not seeing a perfect match right now."
  }

  // Generate contextual responses based on results and tone
  if (searchResults.length === 1) {
    if (isfrustrated) {
      return `Okay, I think I found something that might rescue you from this nightmare! Check out ${searchResults[0].name} - it could be your lifesaver!`
    }
    return `Perfect! I found exactly one app that looks promising: ${searchResults[0].name}. This might be just what you need!`
  } else {
    if (isfrustrated) {
      return `Hold on! I found ${searchResults.length} apps that might put an end to your suffering! Let's see if any of these can save the day:`
    }
    return `Excellent! I found ${searchResults.length} solid options that could solve your problem. Let's see which one clicks for you:`
  }
}

export const getCategoryFromInput = (userInput) => {
  const input = userInput.toLowerCase()
  
  for (const [category, keywords] of Object.entries(COMMON_PATTERNS)) {
    if (keywords.some(keyword => input.includes(keyword))) {
      return category
    }
  }
  
  return 'general'
}

export const getSuggestedQuestions = (category = 'general') => {
  const suggestions = {
    incident: [
      "Our bug tracking is a total mess!",
      "I'm drowning in incident reports",
      "Something keeps breaking and I can't track it",
      "We need better error monitoring"
    ],
    security: [
      "Access management is driving me crazy",
      "I need something to handle logins better",
      "Our security process is a nightmare",
      "Password management is such a pain"
    ],
    analytics: [
      "I need to make sense of all this data",
      "Creating reports manually is killing me",
      "We need better dashboards",
      "I'm tired of spreadsheet hell"
    ],
    collaboration: [
      "Our team communication is chaotic",
      "We need better project coordination",
      "File sharing is a disaster",
      "Meetings are unproductive"
    ],
    frustrated: [
      "This manual process is driving me insane",
      "I'm spending way too much time on this",
      "There has to be a better way",
      "I'm so tired of doing this by hand"
    ],
    general: [
      "I'm drowning in manual work",
      "Our vendor approval process is a nightmare",
      "I need something to make my life easier",
      "This workflow is driving me crazy",
      "We're wasting so much time on this"
    ]
  }
  
  return suggestions[category] || suggestions.general
}
