import { useState, useEffect } from 'react'
import {
  Box,
  Paper,
  Typography,
  CircularProgress,
  Alert,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Card,
  CardContent,
  Grid,
  Chip,
  Rating,
  Avatar,
  Divider,
  FormControlLabel,
  Switch,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
} from '@mui/material'
import {
  Add as AddIcon,
  ThumbUp as ThumbUpIcon,
  Person as PersonIcon,
  PersonOff as AnonymousIcon,
} from '@mui/icons-material'
import { apiService } from '../services/api'

function Feedback() {
  const [feedback, setFeedback] = useState([])
  const [applications, setApplications] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [open, setOpen] = useState(false)
  const [selectedApp, setSelectedApp] = useState('all')
  const [newFeedback, setNewFeedback] = useState({
    applicationId: '',
    userId: 1, // Default user ID
    ratings: {
      usability: 5,
      stability: 5,
      performance: 5,
      documentation: 5
    },
    comment: '',
    isAnonymous: false
  })

  useEffect(() => {
    fetchData()
  }, [])

  useEffect(() => {
    fetchFeedback()
  }, [selectedApp])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [feedbackRes, appsRes] = await Promise.all([
        apiService.getFeedback(),
        apiService.getApplications()
      ])
      // Sort feedback by newest first
      const sortedFeedback = feedbackRes.data.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      setFeedback(sortedFeedback)
      setApplications(appsRes.data)
    } catch (err) {
      setError('Failed to load feedback')
    } finally {
      setLoading(false)
    }
  }

  const fetchFeedback = async () => {
    try {
      const filters = selectedApp !== 'all' ? { applicationId: selectedApp } : {}
      const response = await apiService.getFeedback(filters)
      // Sort filtered feedback by newest first
      const sortedFeedback = response.data.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      setFeedback(sortedFeedback)
    } catch (err) {
      setError('Failed to filter feedback')
    }
  }

  const handleSubmitFeedback = async () => {
    try {
      await apiService.submitFeedback(newFeedback)
      setOpen(false)
      setNewFeedback({
        applicationId: '',
        userId: 1,
        ratings: {
          usability: 5,
          stability: 5,
          performance: 5,
          documentation: 5
        },
        comment: '',
        isAnonymous: false
      })
      fetchFeedback()
    } catch (err) {
      setError('Failed to submit feedback')
    }
  }

  const calculateOverallRating = (ratings) => {
    const values = Object.values(ratings)
    // Filter out zero-star ratings
    const nonZeroRatings = values.filter(rating => rating > 0)
    
    if (nonZeroRatings.length === 0) {
      return 0 // No valid ratings
    }
    
    return nonZeroRatings.reduce((sum, rating) => sum + rating, 0) / nonZeroRatings.length
  }

  const getRatingColor = (rating) => {
    if (rating >= 4.5) return '#4caf50'
    if (rating >= 3.5) return '#ff9800'
    if (rating >= 2.5) return '#f57c00'
    return '#f44336'
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  if (loading) {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: 400,
        }}
      >
        <CircularProgress size={60} />
      </Box>
    )
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    )
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 3,
        }}
      >
        <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
          Feedback Hub
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setOpen(true)}
          sx={{ borderRadius: 2 }}
        >
          Submit Feedback
        </Button>
      </Box>

      {/* Filter */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={4}>
            <FormControl fullWidth>
              <InputLabel>Filter by Application</InputLabel>
              <Select
                value={selectedApp}
                label="Filter by Application"
                onChange={(e) => setSelectedApp(e.target.value)}
              >
                <MenuItem value="all">All Applications</MenuItem>
                {applications.map((app) => (
                  <MenuItem key={app.id} value={app.id}>
                    {app.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={8}>
            <Typography variant="body2" color="text.secondary">
              Showing {feedback.length} feedback items
            </Typography>
          </Grid>
        </Grid>
      </Paper>

      {/* Feedback List */}
      <Grid container spacing={3}>
        {feedback.map((item) => (
          <Grid item xs={12} key={item.id}>
            <Card sx={{ mb: 2 }}>
              <CardContent sx={{ p: 3 }}>
                {/* Header */}
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    {item.isAnonymous ? (
                      <Avatar sx={{ bgcolor: '#9e9e9e' }}>
                        <AnonymousIcon />
                      </Avatar>
                    ) : (
                      <Avatar sx={{ bgcolor: '#1976d2' }}>
                        <PersonIcon />
                      </Avatar>
                    )}
                    <Box>
                      <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                        {item.application?.name || 'Unknown Application'}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        By {item.isAnonymous ? 'Anonymous' : item.user?.name || 'Unknown User'} • {formatDate(item.createdAt)}
                      </Typography>
                    </Box>
                  </Box>
                  <Chip
                    icon={<ThumbUpIcon />}
                    label={`${item.helpful} helpful`}
                    size="small"
                    variant="outlined"
                  />
                </Box>

                {/* Ratings - Only show if there are non-zero ratings */}
                {(item.ratings.usability > 0 || item.ratings.stability > 0 || item.ratings.performance > 0 || item.ratings.documentation > 0) && (
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 'bold' }}>
                      Ratings
                    </Typography>
                    <Grid container spacing={2}>
                      {/* Usability - Only show if > 0 */}
                      {item.ratings.usability > 0 && (
                        <Grid item xs={6} sm={3}>
                          <Box sx={{ textAlign: 'center' }}>
                            <Typography variant="caption" color="text.secondary">
                              Usability
                            </Typography>
                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1 }}>
                              <Rating value={item.ratings.usability} readOnly size="small" />
                              <Typography variant="body2" sx={{ color: getRatingColor(item.ratings.usability) }}>
                                {item.ratings.usability}
                              </Typography>
                            </Box>
                          </Box>
                        </Grid>
                      )}
                      {/* Stability - Only show if > 0 */}
                      {item.ratings.stability > 0 && (
                        <Grid item xs={6} sm={3}>
                          <Box sx={{ textAlign: 'center' }}>
                            <Typography variant="caption" color="text.secondary">
                              Stability
                            </Typography>
                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1 }}>
                              <Rating value={item.ratings.stability} readOnly size="small" />
                              <Typography variant="body2" sx={{ color: getRatingColor(item.ratings.stability) }}>
                                {item.ratings.stability}
                              </Typography>
                            </Box>
                          </Box>
                        </Grid>
                      )}
                      {/* Performance - Only show if > 0 */}
                      {item.ratings.performance > 0 && (
                        <Grid item xs={6} sm={3}>
                          <Box sx={{ textAlign: 'center' }}>
                            <Typography variant="caption" color="text.secondary">
                              Performance
                            </Typography>
                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1 }}>
                              <Rating value={item.ratings.performance} readOnly size="small" />
                              <Typography variant="body2" sx={{ color: getRatingColor(item.ratings.performance) }}>
                                {item.ratings.performance}
                              </Typography>
                            </Box>
                          </Box>
                        </Grid>
                      )}
                      {/* Documentation - Only show if > 0 */}
                      {item.ratings.documentation > 0 && (
                        <Grid item xs={6} sm={3}>
                          <Box sx={{ textAlign: 'center' }}>
                            <Typography variant="caption" color="text.secondary">
                              Documentation
                            </Typography>
                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1 }}>
                              <Rating value={item.ratings.documentation} readOnly size="small" />
                              <Typography variant="body2" sx={{ color: getRatingColor(item.ratings.documentation) }}>
                                {item.ratings.documentation}
                              </Typography>
                            </Box>
                          </Box>
                        </Grid>
                      )}
                    </Grid>
                  </Box>
                )}

                {/* Overall Rating - Only show if there are ratings */}
                {(item.ratings.usability > 0 || item.ratings.stability > 0 || item.ratings.performance > 0 || item.ratings.documentation > 0) && calculateOverallRating(item.ratings) > 0 && (
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
                    <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>
                      Overall:
                    </Typography>
                    <Rating value={calculateOverallRating(item.ratings)} readOnly precision={0.1} />
                    <Typography 
                      variant="h6" 
                      sx={{ 
                        color: getRatingColor(calculateOverallRating(item.ratings)),
                        fontWeight: 'bold'
                      }}
                    >
                      {calculateOverallRating(item.ratings).toFixed(1)}
                    </Typography>
                  </Box>
                )}

                {/* Comment */}
                {item.comment && (
                  <>
                    <Divider sx={{ my: 2 }} />
                    <Typography variant="body1">
                      {item.comment}
                    </Typography>
                  </>
                )}
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {feedback.length === 0 && (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <Typography variant="h6" color="text.secondary">
            No feedback found
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            Be the first to provide feedback on an application
          </Typography>
        </Paper>
      )}

      {/* Submit Feedback Dialog */}
      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Submit Application Feedback</DialogTitle>
        <DialogContent>
          <FormControl fullWidth sx={{ mb: 3, mt: 1 }}>
            <InputLabel>Application</InputLabel>
            <Select
              value={newFeedback.applicationId}
              label="Application"
              onChange={(e) =>
                setNewFeedback({ ...newFeedback, applicationId: e.target.value })
              }
            >
              {applications.map((app) => (
                <MenuItem key={app.id} value={app.id}>
                  {app.name} - {app.team}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <Typography variant="h6" sx={{ mb: 2 }}>
            Rate the Application
          </Typography>

          <Grid container spacing={3} sx={{ mb: 3 }}>
            <Grid item xs={12} sm={6}>
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  Usability
                </Typography>
                <Rating
                  value={newFeedback.ratings.usability}
                  onChange={(event, newValue) =>
                    setNewFeedback({
                      ...newFeedback,
                      ratings: { ...newFeedback.ratings, usability: newValue }
                    })
                  }
                  size="large"
                />
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  Stability
                </Typography>
                <Rating
                  value={newFeedback.ratings.stability}
                  onChange={(event, newValue) =>
                    setNewFeedback({
                      ...newFeedback,
                      ratings: { ...newFeedback.ratings, stability: newValue }
                    })
                  }
                  size="large"
                />
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  Performance
                </Typography>
                <Rating
                  value={newFeedback.ratings.performance}
                  onChange={(event, newValue) =>
                    setNewFeedback({
                      ...newFeedback,
                      ratings: { ...newFeedback.ratings, performance: newValue }
                    })
                  }
                  size="large"
                />
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box sx={{ textAlign: 'center' }}>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  Documentation
                </Typography>
                <Rating
                  value={newFeedback.ratings.documentation}
                  onChange={(event, newValue) =>
                    setNewFeedback({
                      ...newFeedback,
                      ratings: { ...newFeedback.ratings, documentation: newValue }
                    })
                  }
                  size="large"
                />
              </Box>
            </Grid>
          </Grid>

          <TextField
            label="Comments (optional)"
            multiline
            rows={4}
            fullWidth
            variant="outlined"
            value={newFeedback.comment}
            onChange={(e) =>
              setNewFeedback({ ...newFeedback, comment: e.target.value })
            }
            sx={{ mb: 2 }}
            placeholder="Share your experience, suggestions, or any specific feedback..."
          />

          <FormControlLabel
            control={
              <Switch
                checked={newFeedback.isAnonymous}
                onChange={(e) =>
                  setNewFeedback({ ...newFeedback, isAnonymous: e.target.checked })
                }
              />
            }
            label="Submit as anonymous feedback"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button 
            onClick={handleSubmitFeedback} 
            variant="contained"
            disabled={!newFeedback.applicationId}
          >
            Submit Feedback
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default Feedback
