import { useState, useEffect } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import {
  Box,
  Paper,
  TextField,
  Button,
  Typography,
  Alert,
  Container,
  Avatar,
  InputAdornment,
  IconButton,
  Card,
  CardContent,
  Grid,
  Chip,
  Collapse,
  Tooltip,
} from '@mui/material'
import {
  LockOutlined as LockIcon,
  Visibility,
  VisibilityOff,
  Person as PersonIcon,
  AdminPanelSettings as AdminIcon,
  Apps as AppsIcon,
} from '@mui/icons-material'
import { useAuth } from '../contexts/AuthContext'
import { apiService } from '../services/api'

function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [demoCredentials, setDemoCredentials] = useState(null)
  const [showDemoAccounts, setShowDemoAccounts] = useState(false)
  
  const { login, error, isAuthenticated } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  // Redirect if already authenticated - always go to home page
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/', { replace: true })
    }
  }, [isAuthenticated, navigate])

  // Load demo credentials
  useEffect(() => {
    const loadDemoCredentials = async () => {
      try {
        const response = await apiService.getDemoCredentials()
        setDemoCredentials(response.data)
      } catch (error) {
        console.error('Failed to load demo credentials:', error)
      }
    }
    loadDemoCredentials()
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    const result = await login(email, password)
    if (result.success) {
      // Always redirect to home page after successful login
      navigate('/', { replace: true })
    }
    setLoading(false)
  }

  const handleDemoLogin = (demoUser) => {
    setEmail(demoUser.email)
    setPassword(demoUser.password)
  }

  return (
    <Container component="main" maxWidth="md">
      <Box
        sx={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          py: 4,
        }}
      >
        {/* Header */}
        <Box sx={{ textAlign: 'center', mb: 4 }}>
          <Avatar
            sx={{
              m: 'auto',
              mb: 2,
              bgcolor: 'primary.main',
              width: 56,
              height: 56,
            }}
          >
            <AppsIcon />
          </Avatar>
          <Typography component="h1" variant="h4" sx={{ fontWeight: 'bold', mb: 1 }}>
            Application Lifecycle Portal
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Sign in to manage your organization's applications
          </Typography>
        </Box>

        <Grid container spacing={4} maxWidth="lg" justifyContent="center">
          {/* Login Form */}
          <Grid item xs={12} md={6}>
            <Paper
              elevation={3}
              sx={{
                p: 4,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
              }}
            >
              <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
                <LockIcon />
              </Avatar>
              <Typography component="h2" variant="h5" sx={{ mb: 3 }}>
                Sign In
              </Typography>

              {error && (
                <Alert severity="error" sx={{ width: '100%', mb: 2 }}>
                  {error}
                </Alert>
              )}

              <Box component="form" onSubmit={handleSubmit} sx={{ mt: 1, width: '100%' }}>
                <TextField
                  margin="normal"
                  required
                  fullWidth
                  id="email"
                  label="Email Address"
                  name="email"
                  autoComplete="email"
                  autoFocus
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={loading}
                />
                <TextField
                  margin="normal"
                  required
                  fullWidth
                  name="password"
                  label="Password"
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={loading}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={() => setShowPassword(!showPassword)}
                          edge="end"
                        >
                          {showPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  sx={{ mt: 3, mb: 2, py: 1.5 }}
                  disabled={loading}
                >
                  {loading ? 'Signing In...' : 'Sign In'}
                </Button>
              </Box>
            </Paper>
          </Grid>
        </Grid>

        {/* Footer */}
        <Box sx={{ mt: 4, textAlign: 'center' }}>
          <Typography variant="body2" color="text.secondary">
            Internal Application Lifecycle Portal{' '}
            <Tooltip 
              title={showDemoAccounts ? "Hide demo accounts" : "Show demo accounts"}
              placement="top"
            >
              <Box
                component="span"
                onClick={() => setShowDemoAccounts(!showDemoAccounts)}
                sx={{
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  px: 0.5,
                  py: 0.25,
                  borderRadius: 1,
                  transition: 'all 0.2s ease',
                  '&:hover': {
                    backgroundColor: 'action.hover',
                    transform: 'scale(1.1)',
                  },
                  '&:active': {
                    transform: 'scale(0.95)',
                  }
                }}
              >
                ©
              </Box>
            </Tooltip>
            {' '}2026
          </Typography>
        </Box>

        {/* Demo Credentials - Moved below trademark */}
        <Collapse in={showDemoAccounts} timeout="auto" unmountOnExit>
          <Box sx={{ mt: 4, display: 'flex', justifyContent: 'center' }}>
            <Box sx={{ maxWidth: 'md' }}>
              <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold', textAlign: 'center' }}>
                Demo Accounts
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3, textAlign: 'center' }}>
                Use these demo accounts to test different user roles
              </Typography>

              {demoCredentials && (
                <Grid container spacing={2}>
                  {/* Admin Account */}
                  <Grid item xs={12} sm={4}>
                    <Card
                      sx={{
                        cursor: 'pointer',
                        transition: 'transform 0.2s, box-shadow 0.2s',
                        '&:hover': {
                          transform: 'translateY(-2px)',
                          boxShadow: 4,
                        },
                      }}
                      onClick={() => handleDemoLogin(demoCredentials.admin)}
                    >
                      <CardContent>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                          <Box>
                            <Typography variant="h6">Catalog Admin</Typography>
                            <Chip label="Administrator" color="error" size="small" />
                          </Box>
                        </Box>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                          <strong>Email:</strong> {demoCredentials.admin.email}
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                          <strong>Password:</strong> {demoCredentials.admin.password}
                        </Typography>
                        <Typography variant="body2">
                          {demoCredentials.admin.description}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>

                  {/* Requester Accounts */}
                  <Grid item xs={12} sm={4}>
                    <Card
                      sx={{
                        cursor: 'pointer',
                        transition: 'transform 0.2s, box-shadow 0.2s',
                        '&:hover': {
                          transform: 'translateY(-2px)',
                          boxShadow: 4,
                        },
                      }}
                      onClick={() => handleDemoLogin(demoCredentials.requester)}
                    >
                      <CardContent>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                          <Box>
                            <Typography variant="h6">Requester 1</Typography>
                            <Chip label="Engineering" color="primary" size="small" />
                          </Box>
                        </Box>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                          <strong>Email:</strong> {demoCredentials.requester.email}
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                          <strong>Password:</strong> {demoCredentials.requester.password}
                        </Typography>
                        <Typography variant="body2">
                          {demoCredentials.requester.description}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>

                  {/* Second Requester Account */}
                  <Grid item xs={12} sm={4}>
                    <Card
                      sx={{
                        cursor: 'pointer',
                        transition: 'transform 0.2s, box-shadow 0.2s',
                        '&:hover': {
                          transform: 'translateY(-2px)',
                          boxShadow: 4,
                        },
                      }}
                      onClick={() => handleDemoLogin({
                        email: 'emma.rodriguez@company.com',
                        password: 'password123'
                      })}
                    >
                      <CardContent>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                          <Box>
                            <Typography variant="h6">Requester 2</Typography>
                            <Chip label="Marketing" color="secondary" size="small" />
                          </Box>
                        </Box>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                          <strong>Email:</strong> emma.rodriguez@company.com
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                          <strong>Password:</strong> password123
                        </Typography>
                        <Typography variant="body2">
                          Marketing team member with access to app discovery and request features
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                </Grid>
              )}
            </Box>
          </Box>
        </Collapse>
      </Box>
    </Container>
  )
}

export default Login
