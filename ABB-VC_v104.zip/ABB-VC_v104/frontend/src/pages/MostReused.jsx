import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Box,
  Container,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableSortLabel,
  Paper,
  Rating,
  Link,
  CircularProgress,
  Alert,
} from '@mui/material'
import { apiService } from '../services/api'
import PageHeader from '../components/PageHeader'

function MostReused() {
  const navigate = useNavigate()
  const [applications, setApplications] = useState([])
  const [requests, setRequests] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [sortField, setSortField] = useState('reuseCount')
  const [sortDirection, setSortDirection] = useState('desc')

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [appsResponse, requestsResponse] = await Promise.all([
        apiService.getApplications(),
        apiService.getAllRequests()
      ])
      setApplications(appsResponse.data)
      setRequests(requestsResponse.data)
    } catch (err) {
      setError('Failed to load data')
    } finally {
      setLoading(false)
    }
  }

  // Calculate reuse count for each application
  const getApplicationsWithReuseCount = () => {
    return applications.map(app => {
      // Count reuse requests that are approved
      const reuseCount = requests.filter(request => 
        request.applicationId === app.id && 
        request.type === 'reuse' && 
        request.status === 'approved'
      ).length
      return { ...app, reuseCount }
    })
    .sort((a, b) => b.reuseCount - a.reuseCount)
    .slice(0, 10) // Top 10 most reused
  }

  const handleSort = (field) => {
    const isAsc = sortField === field && sortDirection === 'asc'
    setSortDirection(isAsc ? 'desc' : 'asc')
    setSortField(field)
  }

  const getRatingDisplay = (app) => {
    if (!app.averageRatings || !app.feedbackCount) {
      return 'No ratings'
    }
    
    // Calculate overall rating from averages
    const ratings = app.averageRatings
    const ratingValues = Object.values(ratings).map(r => parseFloat(r))
    const validRatings = ratingValues.filter(r => r > 0)
    
    if (validRatings.length === 0) {
      return 'No ratings'
    }
    
    const overall = validRatings.reduce((sum, rating) => sum + rating, 0) / validRatings.length
    return `${overall.toFixed(1)} (${app.feedbackCount})`
  }

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ py: 4, display: 'flex', justifyContent: 'center' }}>
        <CircularProgress />
      </Container>
    )
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    )
  }

  const allApplicationsWithReuse = getApplicationsWithReuseCount()
  
  // Apply custom sorting if different from default
  const topApplications = [...allApplicationsWithReuse].sort((a, b) => {
    let aValue = a[sortField]
    let bValue = b[sortField]
    
    if (sortField === 'name' || sortField === 'lifecycle') {
      aValue = String(aValue || '').toLowerCase()
      bValue = String(bValue || '').toLowerCase()
    }
    
    if (aValue < bValue) {
      return sortDirection === 'asc' ? -1 : 1
    }
    if (aValue > bValue) {
      return sortDirection === 'asc' ? 1 : -1
    }
    return 0
  })

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <PageHeader 
        showBreadcrumb={true}
        breadcrumbItems={[
          { label: 'Home', onClick: () => navigate('/') },
          { label: 'Most reused', active: true },
          { label: 'Most needs filled', onClick: () => navigate('/most-needs-filled') },
          { label: 'Most verified', onClick: () => navigate('/most-verified') },
          { label: 'Most improved', onClick: () => navigate('/most-improved') }
        ]}
      />

      {/* Header */}
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Typography variant="h3" sx={{ fontWeight: 'bold', color: '#333', mb: 4 }}>
          Most reused
        </Typography>
        
        <Typography variant="body1" sx={{ color: '#666', maxWidth: 800, mx: 'auto', lineHeight: 1.6 }}>
          These are the 10 apps others rely on again and again. High reuse means the app solves real problems and delivers consistent value.
          If your app is here, it's becoming a trusted tool across the organization.
        </Typography>
      </Box>

      {/* Applications Table */}
      <Paper sx={{ borderRadius: 2, overflow: 'hidden' }}>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '60px' }}>Nr.</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333' }}>
                  <TableSortLabel
                    active={sortField === 'name'}
                    direction={sortField === 'name' ? sortDirection : 'asc'}
                    onClick={() => handleSort('name')}
                  >
                    Name
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333' }}>
                  <TableSortLabel
                    active={sortField === 'lifecycle'}
                    direction={sortField === 'lifecycle' ? sortDirection : 'asc'}
                    onClick={() => handleSort('lifecycle')}
                  >
                    Stage
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '50%' }}>Purpose</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', textAlign: 'right' }}>
                  Rating
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {topApplications.map((app, index) => (
                <TableRow 
                  key={app.id}
                  hover
                  onClick={() => navigate(`/applications/${app.id}`)}
                  sx={{ 
                    backgroundColor: index % 2 === 0 ? 'white' : '#f8f9fa',
                    cursor: 'pointer',
                    '&:hover': { 
                      backgroundColor: '#e0e0e0'
                    }
                  }}
                >
                  <TableCell>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                      {index + 1}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography
                      sx={{ 
                        color: '#1976d2',
                        fontWeight: 500,
                        '&:hover': { textDecoration: 'underline' }
                      }}
                    >
                      {app.name}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ color: '#666' }}>
                      {app.lifecycle}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ lineHeight: 1.4 }}>
                      {app.description}
                    </Typography>
                  </TableCell>
                  <TableCell sx={{ textAlign: 'right' }}>
                    {app.averageRatings && app.feedbackCount > 0 ? (
                      <Typography variant="body2" sx={{ color: '#666' }}>
                        {getRatingDisplay(app)}
                      </Typography>
                    ) : (
                      <Typography variant="body2" sx={{ color: '#999' }}>
                        No ratings
                      </Typography>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
    </Container>
  )
}

export default MostReused
