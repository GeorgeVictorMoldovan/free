import { useState, useEffect } from 'react'
import {
  Box,
  Paper,
  Typography,
  CircularProgress,
  Alert,
  Chip,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Avatar,
} from '@mui/material'
import { DataGrid } from '@mui/x-data-grid'
import { Add as AddIcon } from '@mui/icons-material'
import { apiService } from '../services/api'

function Orders() {
  const [orders, setOrders] = useState([])
  const [users, setUsers] = useState([])
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [open, setOpen] = useState(false)
  const [newOrder, setNewOrder] = useState({
    userId: '',
    productId: '',
    quantity: 1,
  })

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [ordersRes, usersRes, productsRes] = await Promise.all([
        apiService.getOrders(),
        apiService.getUsers(),
        apiService.getProducts(),
      ])
      setOrders(ordersRes.data)
      setUsers(usersRes.data)
      setProducts(productsRes.data)
    } catch (err) {
      setError('Failed to load data')
      console.error('Error fetching data:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleAddOrder = async () => {
    try {
      await apiService.createOrder(newOrder)
      setOpen(false)
      setNewOrder({ userId: '', productId: '', quantity: 1 })
      fetchData() // Refresh the data
    } catch (err) {
      setError('Failed to create order')
      console.error('Error creating order:', err)
    }
  }

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'completed':
        return 'success'
      case 'pending':
        return 'warning'
      case 'shipped':
        return 'info'
      case 'cancelled':
        return 'error'
      default:
        return 'default'
    }
  }

  const columns = [
    { field: 'id', headerName: 'Order ID', width: 100 },
    {
      field: 'user',
      headerName: 'Customer',
      width: 200,
      renderCell: (params) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Avatar sx={{ width: 32, height: 32 }}>
            {params.value?.name?.charAt(0)}
          </Avatar>
          <Box>
            <Typography variant="body2">{params.value?.name}</Typography>
            <Typography variant="caption" color="text.secondary">
              {params.value?.email}
            </Typography>
          </Box>
        </Box>
      ),
    },
    {
      field: 'product',
      headerName: 'Product',
      width: 200,
      renderCell: (params) => (
        <Box>
          <Typography variant="body2">{params.value?.name}</Typography>
          <Typography variant="caption" color="text.secondary">
            ${params.value?.price}
          </Typography>
        </Box>
      ),
    },
    { field: 'quantity', headerName: 'Qty', width: 80 },
    {
      field: 'totalPrice',
      headerName: 'Total',
      width: 120,
      renderCell: (params) => (
        <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
          ${params.value?.toFixed(2)}
        </Typography>
      ),
    },
    {
      field: 'status',
      headerName: 'Status',
      width: 120,
      renderCell: (params) => (
        <Chip
          label={params.value}
          color={getStatusColor(params.value)}
          size="small"
        />
      ),
    },
    {
      field: 'orderDate',
      headerName: 'Order Date',
      width: 150,
      renderCell: (params) => new Date(params.value).toLocaleDateString(),
    },
  ]

  if (loading) {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: 400,
        }}
      >
        <CircularProgress size={60} />
      </Box>
    )
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    )
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 3,
        }}
      >
        <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
          Orders Management
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setOpen(true)}
          sx={{ borderRadius: 2 }}
        >
          Create Order
        </Button>
      </Box>

      <Paper sx={{ height: 600, width: '100%' }}>
        <DataGrid
          rows={orders}
          columns={columns}
          pageSize={10}
          rowsPerPageOptions={[10]}
          disableSelectionOnClick
          sx={{
            border: 'none',
            '& .MuiDataGrid-cell:focus': {
              outline: 'none',
            },
          }}
        />
      </Paper>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Create New Order</DialogTitle>
        <DialogContent>
          <TextField
            select
            autoFocus
            margin="dense"
            label="Customer"
            fullWidth
            variant="outlined"
            value={newOrder.userId}
            onChange={(e) =>
              setNewOrder({ ...newOrder, userId: e.target.value })
            }
            sx={{ mb: 2 }}
          >
            {users.map((user) => (
              <MenuItem key={user.id} value={user.id}>
                {user.name} - {user.email}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            select
            margin="dense"
            label="Product"
            fullWidth
            variant="outlined"
            value={newOrder.productId}
            onChange={(e) =>
              setNewOrder({ ...newOrder, productId: e.target.value })
            }
            sx={{ mb: 2 }}
          >
            {products.map((product) => (
              <MenuItem key={product.id} value={product.id}>
                {product.name} - ${product.price}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            margin="dense"
            label="Quantity"
            type="number"
            fullWidth
            variant="outlined"
            value={newOrder.quantity}
            onChange={(e) =>
              setNewOrder({ ...newOrder, quantity: parseInt(e.target.value) })
            }
            inputProps={{ min: 1 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={handleAddOrder} variant="contained">
            Create Order
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default Orders
