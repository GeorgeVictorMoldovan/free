import { Box, Paper, Typography, Button } from '@mui/material'
import { Block as BlockIcon } from '@mui/icons-material'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'

function Unauthorized() {
  const navigate = useNavigate()
  const { user, isAdmin } = useAuth()

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#f5f5f5',
        p: 3,
      }}
    >
      <Paper
        sx={{
          p: 6,
          textAlign: 'center',
          maxWidth: 500,
        }}
      >
        <BlockIcon
          sx={{
            fontSize: 80,
            color: 'error.main',
            mb: 2,
          }}
        />
        
        <Typography variant="h4" sx={{ fontWeight: 'bold', mb: 2 }}>
          Access Denied
        </Typography>
        
        <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
          You don't have permission to access this page. Your current role is{' '}
          <strong>{user?.role === 'admin' ? 'Catalog Admin' : 'Requester'}</strong>.
        </Typography>

        <Box sx={{ mb: 3 }}>
          <Typography variant="body2" color="text.secondary">
            {user?.role === 'admin' ? (
              <>
                As a <strong>Catalog Admin</strong>, you have access to:
                <br />
                • Application inventory and management
                <br />
                • Feedback and rating systems
                <br />
                • Reuse request approvals
                <br />
                • Admin panel and user management
              </>
            ) : (
              <>
                As a <strong>Requester</strong>, you have access to:
                <br />
                • Application discovery and search
                <br />
                • Submitting reuse requests
                <br />
                • Providing feedback and ratings
                <br />
                • Viewing application details
              </>
            )}
          </Typography>
        </Box>

        <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center' }}>
          <Button
            variant="contained"
            onClick={() => navigate('/')}
          >
            Go to Dashboard
          </Button>
          <Button
            variant="outlined"
            onClick={() => navigate(-1)}
          >
            Go Back
          </Button>
        </Box>
      </Paper>
    </Box>
  )
}

export default Unauthorized
