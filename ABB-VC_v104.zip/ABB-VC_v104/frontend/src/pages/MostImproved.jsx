import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Box,
  Container,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Rating,
  Chip,
  CircularProgress,
  Alert,
} from '@mui/material'
import { apiService } from '../services/api'
import PageHeader from '../components/PageHeader'

function MostImproved() {
  const navigate = useNavigate()
  const [applications, setApplications] = useState([])
  const [requests, setRequests] = useState([])
  const [feedback, setFeedback] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [appsResponse, requestsResponse, feedbackResponse] = await Promise.all([
        apiService.getApplications(),
        apiService.getAllRequests(),
        apiService.getFeedback()
      ])
      setApplications(appsResponse.data)
      setRequests(requestsResponse.data)
      setFeedback(feedbackResponse.data)
    } catch (err) {
      setError('Failed to load data')
      console.error('Error fetching data:', err)
    } finally {
      setLoading(false)
    }
  }

  // Calculate improvement metrics for each application
  const getApplicationsWithImprovementMetrics = () => {
    return applications.map(app => {
      const improvements = []
      let totalImprovementScore = 0

      // 1. Documentation Improvement (based on recent updates and version changes)
      const lastUpdated = new Date(app.lastUpdated)
      const deploymentDate = app.deploymentDate ? new Date(app.deploymentDate) : null
      const daysSinceDeployment = deploymentDate 
        ? (lastUpdated - deploymentDate) / (1000 * 60 * 60 * 24) 
        : 0
      
      // Apps with recent updates relative to deployment show documentation improvement
      if (daysSinceDeployment > 30 && app.version && app.version.includes('.')) {
        const versionParts = app.version.split('.')
        const minorVersion = parseInt(versionParts[1]) || 0
        if (minorVersion >= 2) { // Apps with version x.2+ show improvement
          improvements.push('Documentation')
          totalImprovementScore += 25
        }
      }

      // 2. Responsiveness Improvement (based on recent request approvals)
      const appRequests = requests.filter(req => req.applicationId === app.id)
      const recentRequests = appRequests.filter(req => {
        const requestDate = new Date(req.requestedAt)
        const now = new Date()
        const daysSinceRequest = (now - requestDate) / (1000 * 60 * 60 * 24)
        return daysSinceRequest <= 30 // Recent requests in last 30 days
      })
      
      const recentApprovedRequests = recentRequests.filter(req => req.status === 'approved')
      const responsivenessRate = recentRequests.length > 0 
        ? (recentApprovedRequests.length / recentRequests.length) * 100 
        : 0
      
      if (responsivenessRate >= 75 && recentRequests.length >= 1) {
        improvements.push('Responsiveness')
        totalImprovementScore += 30
      }

      // 3. Verification Improvement (based on recent high ratings)
      const appFeedback = feedback.filter(fb => fb.applicationId === app.id)
      const recentFeedback = appFeedback.filter(fb => {
        const feedbackDate = new Date(fb.createdAt)
        const now = new Date()
        const daysSinceFeedback = (now - feedbackDate) / (1000 * 60 * 60 * 24)
        return daysSinceFeedback <= 45 // Recent feedback in last 45 days
      })

      if (recentFeedback.length > 0) {
        const avgRating = recentFeedback.reduce((sum, fb) => {
          const ratings = Object.values(fb.ratings).filter(r => r > 0)
          const fbAvg = ratings.length > 0 ? ratings.reduce((s, r) => s + r, 0) / ratings.length : 0
          return sum + fbAvg
        }, 0) / recentFeedback.length

        if (avgRating >= 4.0 && recentFeedback.length >= 2) {
          improvements.push('Verification')
          totalImprovementScore += 35
        }
      }

      // 4. Reuse Improvement (based on increased reuse activity)
      const totalRequests = appRequests.length
      if (totalRequests >= 2) {
        improvements.push('Reuse')
        totalImprovementScore += 20
      }

      // 5. Overall Performance Improvement (based on uptime and performance metrics)
      if (app.usageMetrics && app.usageMetrics.uptime >= 99.0 && app.usageMetrics.monthlyUsers > 100) {
        improvements.push('Performance')
        totalImprovementScore += 15
      }

      return {
        ...app,
        improvements,
        improvementScore: totalImprovementScore,
        improvementCategories: improvements.join(', ') || 'No recent improvements'
      }
    })
    .filter(app => app.improvementScore > 0) // Only show apps with improvements
    .sort((a, b) => b.improvementScore - a.improvementScore) // Sort by improvement score
    .slice(0, 10) // Top 10 most improved
  }

  const getImprovementChipColor = (category) => {
    const colors = {
      'Documentation': '#2e7d32', // Green
      'Responsiveness': '#1976d2', // Blue
      'Verification': '#f57c00', // Orange
      'Reuse': '#7b1fa2', // Purple
      'Performance': '#d32f2f' // Red
    }
    return colors[category] || '#666'
  }

  const getRatingDisplay = (app) => {
    if (!app.averageRatings || !app.feedbackCount) {
      return 'No ratings'
    }
    
    // Calculate overall rating from averages
    const ratings = app.averageRatings
    const ratingValues = Object.values(ratings).map(r => parseFloat(r))
    const validRatings = ratingValues.filter(r => r > 0)
    
    if (validRatings.length === 0) {
      return 'No ratings'
    }
    
    const overall = validRatings.reduce((sum, rating) => sum + rating, 0) / validRatings.length
    return `${overall.toFixed(1)} (${app.feedbackCount})`
  }

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ py: 4, display: 'flex', justifyContent: 'center' }}>
        <CircularProgress />
      </Container>
    )
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    )
  }

  const topApplications = getApplicationsWithImprovementMetrics()

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <PageHeader 
        showBreadcrumb={true}
        breadcrumbItems={[
          { label: 'Home', onClick: () => navigate('/') },
          { label: 'Most reused', onClick: () => navigate('/most-reused') },
          { label: 'Most needs filled', onClick: () => navigate('/most-needs-filled') },
          { label: 'Most verified', onClick: () => navigate('/most-verified') },
          { label: 'Most improved', active: true }
        ]}
      />

      {/* Header */}
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Typography variant="h3" sx={{ fontWeight: 'bold', color: '#333', mb: 4 }}>
          Most improved
        </Typography>
        
        <Typography variant="body1" sx={{ color: '#666', maxWidth: 800, mx: 'auto', lineHeight: 1.6 }}>
          This celebrates progress. Apps on this list have made the biggest leaps in documentation,
          responsiveness, verification or reuse. It's proof that continuous improvement matters and gets
          noticed.
        </Typography>
      </Box>

      {/* Applications Table */}
      <Paper sx={{ borderRadius: 2, overflow: 'hidden' }}>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '60px' }}>Nr.</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333' }}>Name</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333' }}>Stage</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '50%' }}>Purpose</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', textAlign: 'right' }}>Rating</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {topApplications.map((app, index) => (
                <TableRow 
                  key={app.id}
                  hover
                  onClick={() => navigate(`/applications/${app.id}`)}
                  sx={{ 
                    backgroundColor: index % 2 === 0 ? 'white' : '#f8f9fa',
                    cursor: 'pointer',
                    '&:hover': { 
                      backgroundColor: '#e0e0e0'
                    }
                  }}
                >
                  <TableCell>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                      {index + 1}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography
                      sx={{ 
                        color: '#1976d2',
                        fontWeight: 500,
                        '&:hover': { textDecoration: 'underline' }
                      }}
                    >
                      {app.name}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ color: '#666' }}>
                      {app.lifecycle}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ lineHeight: 1.4 }}>
                      {app.description}
                    </Typography>
                  </TableCell>
                  <TableCell sx={{ textAlign: 'right' }}>
                    {app.averageRatings && app.feedbackCount > 0 ? (
                      <Typography variant="body2" sx={{ color: '#666' }}>
                        {getRatingDisplay(app)}
                      </Typography>
                    ) : (
                      <Typography variant="body2" sx={{ color: '#999' }}>
                        No ratings
                      </Typography>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {topApplications.length === 0 && (
        <Box sx={{ textAlign: 'center', py: 6 }}>
          <Typography variant="h6" sx={{ color: '#666', mb: 2 }}>
            No improved applications found
          </Typography>
          <Typography variant="body2" sx={{ color: '#999' }}>
            No applications have shown recent improvements in tracked metrics.
          </Typography>
        </Box>
      )}
    </Container>
  )
}

export default MostImproved
