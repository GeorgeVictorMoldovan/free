import { useState, useEffect } from 'react'
import {
  Box,
  Paper,
  Typography,
  CircularProgress,
  Alert,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Card,
  CardContent,
  Grid,
  Chip,
  MenuItem,
  InputAdornment,
  FormControl,
  InputLabel,
  Select,
  Avatar,
  Rating,
} from '@mui/material'
import {
  Add as AddIcon,
  Search as SearchIcon,
  GitHub as GitHubIcon,
  Description as DocsIcon,
  Person as PersonIcon,
  Group as TeamIcon,
} from '@mui/icons-material'
import { apiService } from '../services/api'

function Applications() {
  const [applications, setApplications] = useState([])
  const [metadata, setMetadata] = useState({ lifecycleStages: [], technologies: [], teams: [] })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [open, setOpen] = useState(false)
  const [filters, setFilters] = useState({
    search: '',
    lifecycle: 'all',
    technology: 'all',
    team: 'all'
  })
  const [newApplication, setNewApplication] = useState({
    name: '',
    description: '',
    owner: '',
    team: '',
    technology: [],
    lifecycle: 'Planning'
  })

  useEffect(() => {
    fetchData()
  }, [])

  useEffect(() => {
    fetchApplications()
  }, [filters])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [appsRes, metaRes] = await Promise.all([
        apiService.getApplications(filters),
        apiService.getMetadata()
      ])
      setApplications(appsRes.data)
      setMetadata(metaRes.data)
    } catch (err) {
      setError('Failed to load applications')
      console.error('Error fetching applications:', err)
    } finally {
      setLoading(false)
    }
  }

  const fetchApplications = async () => {
    try {
      const cleanFilters = Object.fromEntries(
        Object.entries(filters).filter(([key, value]) => value !== '' && value !== 'all')
      )
      const response = await apiService.getApplications(cleanFilters)
      setApplications(response.data)
    } catch (err) {
      setError('Failed to filter applications')
      console.error('Error filtering applications:', err)
    }
  }

  const handleAddApplication = async () => {
    try {
      await apiService.createApplication(newApplication)
      setOpen(false)
      setNewApplication({
        name: '',
        description: '',
        owner: '',
        team: '',
        technology: [],
        lifecycle: 'Planning'
      })
      fetchApplications()
    } catch (err) {
      setError('Failed to create application')
      console.error('Error creating application:', err)
    }
  }

  const getLifecycleColor = (lifecycle) => {
    switch (lifecycle?.toLowerCase()) {
      case 'planning': return 'default'
      case 'development': return 'warning'
      case 'testing': return 'info'
      case 'production': return 'success'
      case 'maintenance': return 'error'
      case 'retired': return 'default'
      default: return 'default'
    }
  }

  const getLifecycleIcon = (lifecycle) => {
    switch (lifecycle?.toLowerCase()) {
      case 'planning': return '📋'
      case 'development': return '⚡'
      case 'testing': return '🔧'
      case 'production': return '✅'
      case 'maintenance': return '🔧'
      case 'retired': return '📦'
      default: return '❓'
    }
  }

  if (loading) {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: 400,
        }}
      >
        <CircularProgress size={60} />
      </Box>
    )
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    )
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 3,
        }}
      >
        <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
          Application Inventory
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setOpen(true)}
          sx={{ borderRadius: 2 }}
        >
          Register App
        </Button>
      </Box>

      {/* Filters */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" sx={{ mb: 2 }}>
          Search & Filter
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} md={3}>
            <TextField
              fullWidth
              label="Search applications"
              variant="outlined"
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              <InputLabel>Lifecycle Stage</InputLabel>
              <Select
                value={filters.lifecycle}
                label="Lifecycle Stage"
                onChange={(e) => setFilters({ ...filters, lifecycle: e.target.value })}
              >
                <MenuItem value="all">All Stages</MenuItem>
                {metadata.lifecycleStages.map((stage) => (
                  <MenuItem key={stage} value={stage}>
                    {stage}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              <InputLabel>Technology</InputLabel>
              <Select
                value={filters.technology}
                label="Technology"
                onChange={(e) => setFilters({ ...filters, technology: e.target.value })}
              >
                <MenuItem value="all">All Technologies</MenuItem>
                {metadata.technologies.map((tech) => (
                  <MenuItem key={tech} value={tech}>
                    {tech}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              <InputLabel>Team</InputLabel>
              <Select
                value={filters.team}
                label="Team"
                onChange={(e) => setFilters({ ...filters, team: e.target.value })}
              >
                <MenuItem value="all">All Teams</MenuItem>
                {metadata.teams.map((team) => (
                  <MenuItem key={team} value={team}>
                    {team}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </Paper>

      {/* Applications Grid */}
      <Grid container spacing={3}>
        {applications.map((app) => (
          <Grid item xs={12} md={6} lg={4} key={app.id}>
            <Card
              sx={{
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                transition: 'transform 0.2s, box-shadow 0.2s',
                '&:hover': {
                  transform: 'translateY(-4px)',
                  boxShadow: '0 8px 25px rgba(0,0,0,0.15)',
                },
              }}
            >
              <CardContent sx={{ flexGrow: 1, p: 3 }}>
                {/* Header */}
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: 'bold' }}>
                    {app.name}
                  </Typography>
                  <Typography sx={{ fontSize: '1.5rem', mr: 1 }}>
                    {getLifecycleIcon(app.lifecycle)}
                  </Typography>
                  <Chip
                    label={app.lifecycle}
                    color={getLifecycleColor(app.lifecycle)}
                    size="small"
                  />
                </Box>

                {/* Description */}
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{ mb: 2, minHeight: 40 }}
                >
                  {app.description}
                </Typography>

                {/* Owner & Team */}
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, gap: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <PersonIcon fontSize="small" color="action" />
                    <Typography variant="caption" color="text.secondary">
                      {app.owner}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <TeamIcon fontSize="small" color="action" />
                    <Typography variant="caption" color="text.secondary">
                      {app.team}
                    </Typography>
                  </Box>
                </Box>

                {/* Technologies */}
                <Box sx={{ mb: 2 }}>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                    Technologies:
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {app.technology.map((tech, index) => (
                      <Chip key={index} label={tech} size="small" variant="outlined" />
                    ))}
                  </Box>
                </Box>

                {/* Ratings */}
                {app.averageRatings && (
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                      Average Rating:
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Rating
                        value={parseFloat(app.averageRatings.usability)}
                        readOnly
                        size="small"
                        precision={0.1}
                      />
                      <Typography variant="caption" color="text.secondary">
                        ({app.feedbackCount} reviews)
                      </Typography>
                    </Box>
                  </Box>
                )}

                {/* Version & Metrics */}
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    v{app.version}
                  </Typography>
                  {app.lifecycle === 'Production' && (
                    <Typography variant="body2" color="text.secondary">
                      {app.usageMetrics.monthlyUsers.toLocaleString()} users
                    </Typography>
                  )}
                </Box>

                {/* Links */}
                <Box sx={{ display: 'flex', gap: 1 }}>
                  {app.repository && (
                    <Button
                      size="small"
                      startIcon={<GitHubIcon />}
                      href={app.repository}
                      target="_blank"
                    >
                      Code
                    </Button>
                  )}
                  {app.documentation && (
                    <Button
                      size="small"
                      startIcon={<DocsIcon />}
                      href={app.documentation}
                      target="_blank"
                    >
                      Docs
                    </Button>
                  )}
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {applications.length === 0 && (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <Typography variant="h6" color="text.secondary">
            No applications found matching your criteria
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            Try adjusting your filters or register a new application
          </Typography>
        </Paper>
      )}

      {/* Add Application Dialog */}
      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Register New Application</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Application Name"
            fullWidth
            variant="outlined"
            value={newApplication.name}
            onChange={(e) =>
              setNewApplication({ ...newApplication, name: e.target.value })
            }
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            label="Description"
            fullWidth
            multiline
            rows={3}
            variant="outlined"
            value={newApplication.description}
            onChange={(e) =>
              setNewApplication({ ...newApplication, description: e.target.value })
            }
            sx={{ mb: 2 }}
          />
          <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
            <TextField
              label="Owner"
              variant="outlined"
              value={newApplication.owner}
              onChange={(e) =>
                setNewApplication({ ...newApplication, owner: e.target.value })
              }
              sx={{ flex: 1 }}
            />
            <TextField
              label="Team"
              variant="outlined"
              value={newApplication.team}
              onChange={(e) =>
                setNewApplication({ ...newApplication, team: e.target.value })
              }
              sx={{ flex: 1 }}
            />
          </Box>
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Initial Lifecycle Stage</InputLabel>
            <Select
              value={newApplication.lifecycle}
              label="Initial Lifecycle Stage"
              onChange={(e) =>
                setNewApplication({ ...newApplication, lifecycle: e.target.value })
              }
            >
              {metadata.lifecycleStages.map((stage) => (
                <MenuItem key={stage} value={stage}>
                  {stage}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={handleAddApplication} variant="contained">
            Register Application
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default Applications
