import { useState, useEffect } from 'react'
import { useParams, useNavigate, useSearchParams } from 'react-router-dom'
import {
  Box,
  Container,
  Typography,
  Breadcrumbs,
  Link,
  Grid,
  Rating,
  Tabs,
  Tab,
  TextField,
  Button,
  Chip,
  Select,
  MenuItem,
  FormControl,
  Paper,
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material'
import {
  Home as HomeIcon,
  Launch as LaunchIcon,
  Person as PersonIcon,
  Email as EmailIcon,
  Verified as VerifiedIcon,
  Lock as LockIcon,
  Info as InfoIcon,
} from '@mui/icons-material'
import { apiService } from '../services/api'
import { useAuth } from '../contexts/AuthContext'
import CommentRateModal from '../components/CommentRateModal'

function ApplicationDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const { user, hasPermission } = useAuth()
  const [application, setApplication] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [activeTab, setActiveTab] = useState(0)
  const [requestText, setRequestText] = useState('')
  const [requestType, setRequestType] = useState('access')
  const [ratings, setRatings] = useState([])
  const [submittedRequest, setSubmittedRequest] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [allAppRequests, setAllAppRequests] = useState([])
  const [processingRequestId, setProcessingRequestId] = useState(null)
  const [newRating, setNewRating] = useState({
    usability: 0,
    stability: 0,
    comment: ''
  })
  const [updatingLifecycle, setUpdatingLifecycle] = useState(false)
  const [lifecycleModalOpen, setLifecycleModalOpen] = useState(false)
  const [pendingLifecycle, setPendingLifecycle] = useState('')
  const [changeReason, setChangeReason] = useState('')
  const [commentModalOpen, setCommentModalOpen] = useState(false)
  const [isSubmittingRating, setIsSubmittingRating] = useState(false)

  useEffect(() => {
    fetchApplication()
  }, [id])

  useEffect(() => {
    // Check for tab query parameter and switch to appropriate tab
    const tabParam = searchParams.get('tab')
    if (tabParam === 'ratings') {
      setActiveTab(1)
    } else if (tabParam === 'requests') {
      setActiveTab(0)
    }
  }, [searchParams])

  const fetchApplication = async () => {
    try {
      setLoading(true)
      // For demo, we'll find the app from the applications list
      const response = await apiService.getApplications()
      const app = response.data.find(app => app.id === parseInt(id))
      console.log('Loaded application:', app) // Debug log
      setApplication(app)
      
      // Fetch ratings for this specific application
      await fetchRatingsForApp(id)
      
      // Check if user has existing request for this application OR fetch all requests for admin
      if (hasPermission('admin')) {
        await fetchAllAppRequests(id)
      } else {
        await checkExistingRequest(id)
      }
    } catch (err) {
      setError('Failed to load application')
      console.error('Error fetching application:', err)
    } finally {
      setLoading(false)
    }
  }

  const checkExistingRequest = async (applicationId) => {
    try {
      // Skip for admin users - they don't submit requests
      if (hasPermission('admin')) {
        return
      }
      
      // Check if current user has an existing request for this application
      const response = await apiService.getRequestsByApp(applicationId)
      const userRequest = response.data.find(request => 
        request.requester?.id === user?.id
      )
      
      if (userRequest) {
        const formattedRequest = {
          id: userRequest.id,
          date: new Date(userRequest.requestedAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }),
          type: userRequest.type,
          text: userRequest.description,
          status: userRequest.status === 'submitted' ? 'Submitted' : userRequest.status,
          application: userRequest.application?.name || 'Unknown',
          owner: userRequest.application?.owner || 'Unknown',
          approver: userRequest.approver,
          reviewedAt: userRequest.reviewedAt
        }
        setSubmittedRequest(formattedRequest)
      }
    } catch (err) {
      console.error('Error checking existing request:', err)
      // Don't show error to user, just continue without showing submitted request
    }
  }

  const fetchAllAppRequests = async (applicationId) => {
    try {
      const response = await apiService.getRequestsByApp(applicationId)
      const formattedRequests = response.data.map(request => ({
        id: request.id,
        requesterName: request.requester?.name || 'Unknown User',
        date: new Date(request.requestedAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }),
        timeAgo: getTimeAgo(request.requestedAt),
        type: request.type,
        text: request.description,
        status: request.status,
        approver: request.approver,
        reviewedAt: request.reviewedAt,
        adminNotes: request.adminNotes
      }))
      console.log('Formatted requests for app:', formattedRequests)
      setAllAppRequests(formattedRequests)
    } catch (err) {
      console.error('Error fetching app requests:', err)
    }
  }

  const getTimeAgo = (dateString) => {
    const now = new Date()
    const date = new Date(dateString)
    const diffInMinutes = Math.floor((now - date) / (1000 * 60))
    
    if (diffInMinutes < 60) {
      return `${diffInMinutes} minutes ago`
    } else if (diffInMinutes < 1440) {
      const hours = Math.floor(diffInMinutes / 60)
      return `${hours} hours ago`
    } else {
      const days = Math.floor(diffInMinutes / 1440)
      return `${days} days ago`
    }
  }

  const handleAdminAction = async (requestId, action) => {
    try {
      setProcessingRequestId(requestId)
      
      const statusData = {
        status: action, // 'approved' or 'rejected'
        adminNotes: `${action === 'approved' ? 'Approved' : 'Rejected'} by admin`
      }
      
      await apiService.updateRequestStatus(requestId, statusData)
      
      // Refresh the requests list
      await fetchAllAppRequests(id)
      
    } catch (error) {
      console.error(`Error ${action} request:`, error)
      setError(`Failed to ${action} request. Please try again.`)
    } finally {
      setProcessingRequestId(null)
    }
  }

  const fetchRatingsForApp = async (applicationId) => {
    try {
      // Fetch ratings from the backend API (includes user information)
      const response = await apiService.getFeedback()
      
      // Check for hidden ratings from localStorage
      const hiddenRatings = JSON.parse(localStorage.getItem('hiddenRatings') || '[]')
      const adminHiddenRatings = JSON.parse(localStorage.getItem('adminHiddenRatings') || '[]')
      
      const appRatings = response.data
        .filter(feedback => feedback.applicationId === parseInt(applicationId))
        .map(feedback => {
          const isHiddenByUser = hiddenRatings.includes(feedback.id)
          const isHiddenByAdmin = adminHiddenRatings.includes(feedback.id)
          const isHidden = isHiddenByUser || isHiddenByAdmin
          
          // Get display name based on user role and feedback data
          let displayName
          if (feedback.userId === user?.id) {
            displayName = 'You'
          } else if (hasPermission('admin') && feedback.user?.name) {
            displayName = feedback.user.name
          } else {
            displayName = `User ${feedback.userId}`
          }
          
          return {
            id: feedback.id,
            user: displayName,
            date: new Date(feedback.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }),
            usability: feedback.ratings.usability,
            stability: feedback.ratings.stability,
            comment: feedback.comment,
            recommendation: '', // Could add this field to backend data
            isHidden: isHidden,
            hiddenByAdmin: isHiddenByAdmin, // Track if hidden by admin
            hiddenByUser: isHiddenByUser, // Track if hidden by user
            canEdit: feedback.userId === user?.id // User can edit their own ratings
          }
        })
      
      setRatings(appRatings)
    } catch (err) {
      console.error('Error fetching ratings:', err)
      setRatings([]) // Set empty array if ratings fail to load
    }
  }

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue)
  }

  const handleSubmitRequest = async () => {
    if (!requestText.trim()) return
    
    try {
      setIsSubmitting(true)
      
      // Create request data
      const requestData = {
        type: requestType,
        applicationId: parseInt(id),
        title: `${requestType.charAt(0).toUpperCase() + requestType.slice(1)} request for ${application.name}`,
        description: requestText,
        businessJustification: requestText,
        timeline: 'As discussed',
        priority: 'medium'
      }
      
      // Submit the request
      const response = await apiService.submitRequest(requestData)
      
      // Create formatted request display
      const formattedRequest = {
        id: response.data.id,
        date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }),
        type: requestType,
        text: requestText,
        status: 'Submitted',
        application: application.name,
        owner: application.owner,
        approver: null,
        reviewedAt: null
      }
      
      setSubmittedRequest(formattedRequest)
      
      // Clear form
      setRequestText('')
      setRequestType('access')
      
    } catch (error) {
      console.error('Error submitting request:', error)
      setError('Failed to submit request. Please try again.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteRequest = async () => {
    if (!submittedRequest || !window.confirm('Are you sure you want to delete this request? This action cannot be undone.')) {
      return
    }

    try {
      setIsDeleting(true)
      
      await apiService.deleteOwnRequest(submittedRequest.id)
      
      // Reset the form state to allow new submission
      setSubmittedRequest(null)
      setRequestText('')
      setRequestType('access')
      
      // Show success message briefly
      setError(null)
      
    } catch (error) {
      console.error('Error deleting request:', error)
      setError('Failed to delete request. Please try again.')
    } finally {
      setIsDeleting(false)
    }
  }

  const handleRatingSubmit = async (ratingData) => {
    try {
      setIsSubmittingRating(true)
      
      // Prepare the feedback data matching the API structure
      const feedbackData = {
        applicationId: parseInt(id),
        userId: user?.id || 1, // Use current user ID
        ratings: {
          usability: ratingData.ratings.usability,
          stability: ratingData.ratings.stability,
          performance: 5, // Default for now
          documentation: 5 // Default for now
        },
        comment: ratingData.comment,
        isAnonymous: false
      }
      
      await apiService.submitFeedback(feedbackData)
      
      // Refresh ratings after submission
      await fetchRatingsForApp(id)
      
    } catch (error) {
      console.error('Error submitting rating:', error)
      setError('Failed to submit rating. Please try again.')
    } finally {
      setIsSubmittingRating(false)
    }
  }

  const toggleRatingVisibility = (ratingId) => {
    setRatings(ratings.map(rating => {
      if (rating.id === ratingId) {
        // Users can only hide/unhide their own ratings, admins can hide/unhide all
        // Users cannot unhide comments that were hidden by admin
        // Admins cannot unhide comments that were hidden by user
        if (rating.canEdit || hasPermission('admin')) {
          // Users cannot unhide if it was hidden by admin (unless they are admin)
          if (rating.hiddenByAdmin && !hasPermission('admin')) {
            return rating
          }
          
          // Admins cannot unhide if it was hidden by user (unless they own the rating)
          if (rating.hiddenByUser && hasPermission('admin') && !rating.canEdit) {
            return rating
          }
          
          const newHiddenState = !rating.isHidden
          
          // Store hidden ratings in localStorage to persist across pages
          const hiddenRatings = JSON.parse(localStorage.getItem('hiddenRatings') || '[]')
          const adminHiddenRatings = JSON.parse(localStorage.getItem('adminHiddenRatings') || '[]')
          
          if (newHiddenState) {
            // Add to appropriate hidden list
            if (hasPermission('admin')) {
              if (!adminHiddenRatings.includes(ratingId)) {
                adminHiddenRatings.push(ratingId)
              }
            } else {
              if (!hiddenRatings.includes(ratingId)) {
                hiddenRatings.push(ratingId)
              }
            }
          } else {
            // Remove from appropriate hidden list
            if (hasPermission('admin')) {
              const index = adminHiddenRatings.indexOf(ratingId)
              if (index > -1) {
                adminHiddenRatings.splice(index, 1)
              }
            } else {
              const index = hiddenRatings.indexOf(ratingId)
              if (index > -1) {
                hiddenRatings.splice(index, 1)
              }
            }
          }
          
          localStorage.setItem('hiddenRatings', JSON.stringify(hiddenRatings))
          localStorage.setItem('adminHiddenRatings', JSON.stringify(adminHiddenRatings))
          
          return { 
            ...rating, 
            isHidden: newHiddenState,
            hiddenByAdmin: newHiddenState && hasPermission('admin'),
            hiddenByUser: newHiddenState && !hasPermission('admin')
          }
        }
      }
      return rating
    }))
  }

  const handleLifecycleChange = (event) => {
    const newLifecycle = event.target.value
    
    // Don't show modal if selecting the same lifecycle
    if (newLifecycle === application?.lifecycle) {
      return
    }
    
    // Store the pending lifecycle and show modal
    setPendingLifecycle(newLifecycle)
    setLifecycleModalOpen(true)
  }

  const handleLifecycleConfirm = async () => {
    if (!changeReason.trim()) {
      return // Don't proceed without a reason
    }
    
    try {
      setUpdatingLifecycle(true)
      await apiService.updateApplicationLifecycle(id, pendingLifecycle, changeReason.trim())
      
      // Update local application state
      setApplication(prev => ({
        ...prev,
        lifecycle: pendingLifecycle,
        lastUpdated: new Date().toISOString()
      }))
      
      // Clear any previous errors and close modal
      setError(null)
      setLifecycleModalOpen(false)
      setChangeReason('')
      setPendingLifecycle('')
      
    } catch (error) {
      console.error('Error updating lifecycle:', error)
      setError('Failed to update lifecycle. Please try again.')
    } finally {
      setUpdatingLifecycle(false)
    }
  }

  const handleLifecycleCancel = () => {
    setLifecycleModalOpen(false)
    setChangeReason('')
    setPendingLifecycle('')
  }

  const getLifecycleColor = (lifecycle) => {
    switch (lifecycle) {
      case 'In Dev': return '#ff9800'
      case 'Pilot': return '#2196f3'  
      case 'Active': return '#4caf50'
      case 'Maintenance': return '#9c27b0'
      case 'Retiring': return '#ff5722'
      case 'Deprecated': return '#9e9e9e'
      default: return '#666'
    }
  }

  if (loading) {
    return <Box sx={{ p: 3 }}>Loading...</Box>
  }

  if (error || !application) {
    return <Box sx={{ p: 3 }}>Application not found</Box>
  }

  const averageRating = application.averageRatings?.usability || 4.3

  return (
    <Container maxWidth="lg" sx={{ py: 3 }}>
      {/* Breadcrumb */}
      <Breadcrumbs sx={{ mb: 3 }}>
        <Link 
          onClick={() => navigate('/')} 
          sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: 0.5, 
            color: '#1976d2', 
            textDecoration: 'none',
            cursor: 'pointer',
            '&:hover': { textDecoration: 'underline' }
          }}
        >
          <HomeIcon fontSize="small" />
          Home
        </Link>
        <Typography color="text.primary">{application.name}</Typography>
      </Breadcrumbs>

      <Grid container spacing={4}>
        {/* Left Column - Main Content */}
        <Grid item xs={12} md={8}>
          {/* App Title */}
          <Typography variant="h4" sx={{ mb: 3, fontWeight: 'bold' }}>
            {application.name}
          </Typography>

          {/* Description */}
          <Typography variant="body1" sx={{ mb: 3, lineHeight: 1.6 }}>
            An internal application used by &#123;domain/teams&#125; to &#123;outcome&#125;. It supports &#123;capability list&#125; and is 
            designed to be reused across products. Check the lifecycle stage and stability ratings before 
            adopting. If it fits your need, submit a reuse request to get access and onboarding...{' '}
            <Link href="#" sx={{ color: '#1976d2' }}>[read more]</Link>
          </Typography>

          {/* Ratings */}
          <Box sx={{ mb: 4 }}>
            <Typography variant="subtitle2" sx={{ mb: 2, fontWeight: 'bold' }}>
              RATINGS:
            </Typography>
            <Box sx={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Typography variant="body2">Usability</Typography>
                <Typography variant="body2" sx={{ fontWeight: 'bold' }}>4.3 (80)</Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Typography variant="body2">Stability</Typography>
                <Typography variant="body2" sx={{ fontWeight: 'bold' }}>5 (75)</Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Typography variant="body2">Median</Typography>
                <Typography variant="body2" sx={{ fontWeight: 'bold' }}>4.6 (155)</Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Typography variant="body2">Overall</Typography>
                <Typography variant="body2" sx={{ fontWeight: 'bold' }}>2/102</Typography>
              </Box>
            </Box>
          </Box>

          {/* Tabs */}
          <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
            <Tabs value={activeTab} onChange={handleTabChange}>
              <Tab 
                label="Make a request" 
                sx={{ 
                  fontWeight: activeTab === 0 ? 'bold' : 'normal',
                  borderBottom: activeTab === 0 ? '3px solid #333' : 'none'
                }}
              />
              <Tab 
                label={`Ratings (${ratings.filter(rating => !rating.isHidden || rating.canEdit || hasPermission('admin')).length})`}
                sx={{ 
                  fontWeight: activeTab === 1 ? 'bold' : 'normal',
                  borderBottom: activeTab === 1 ? '3px solid #333' : 'none'
                }}
              />
            </Tabs>
          </Box>

          {/* Tab Content */}
          {activeTab === 0 && (
            <Box>
              {hasPermission('admin') ? (
                // Show admin requests view
                <Box>
                  {allAppRequests.length === 0 ? (
                    <Paper sx={{ p: 4, textAlign: 'center', backgroundColor: '#f5f5f5', border: '1px solid #e0e0e0' }}>
                      <Typography variant="body1" sx={{ color: '#666' }}>
                        No requests found for this application.
                      </Typography>
                    </Paper>
                  ) : (
                    <Box>
                      {allAppRequests.map((request) => (
                        <Paper key={request.id} sx={{ p: 3, mb: 3, backgroundColor: '#f9f9f9', border: '1px solid #e0e0e0' }}>
                          {/* Request Header */}
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                            <Typography variant="body2" sx={{ fontWeight: 'bold', color: '#1976d2' }}>
                              {request.requesterName}
                            </Typography>
                            <Typography variant="body2" sx={{ color: '#666' }}>
                              • {request.timeAgo}
                            </Typography>
                          </Box>
                          
                          {/* Request Text */}
                          <Typography variant="body1" sx={{ 
                            whiteSpace: 'pre-wrap',
                            lineHeight: 1.6,
                            mb: 2,
                            color: '#333'
                          }}>
                            {request.text}
                          </Typography>
                          
                          {/* Status and Action Buttons */}
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Box>
                              {request.status === 'approved' ? (
                                <Typography 
                                  variant="body2" 
                                  sx={{ 
                                    backgroundColor: '#e8f5e8',
                                    color: '#2e7d32',
                                    fontWeight: 'bold',
                                    px: 2,
                                    py: 0.5,
                                    borderRadius: 1,
                                    fontSize: '12px'
                                  }}
                                >
                                  STATUS: Approved by {request.approver?.name || 'Admin'} • {request.reviewedAt ? new Date(request.reviewedAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : 'Unknown date'}
                                </Typography>
                              ) : request.status === 'rejected' ? (
                                <Typography 
                                  variant="body2" 
                                  sx={{ 
                                    backgroundColor: '#ffebee',
                                    color: '#c62828',
                                    fontWeight: 'bold',
                                    px: 2,
                                    py: 0.5,
                                    borderRadius: 1,
                                    fontSize: '12px'
                                  }}
                                >
                                  STATUS: Rejected by {request.approver?.name || 'Admin'} • {request.reviewedAt ? new Date(request.reviewedAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : 'Unknown date'}
                                </Typography>
                              ) : request.status === 'deleted' ? (
                                <Typography 
                                  variant="body2" 
                                  sx={{ 
                                    backgroundColor: '#f5f5f5',
                                    color: '#666',
                                    fontWeight: 'bold',
                                    px: 2,
                                    py: 0.5,
                                    borderRadius: 1,
                                    fontSize: '12px'
                                  }}
                                >
                                  STATUS: Deleted by requestor • {request.reviewedAt ? new Date(request.reviewedAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : 'Unknown date'}
                                </Typography>
                              ) : (
                                <Typography 
                                  variant="body2" 
                                  sx={{ 
                                    backgroundColor: '#fff3e0',
                                    color: '#f57c00',
                                    fontWeight: 'bold',
                                    px: 2,
                                    py: 0.5,
                                    borderRadius: 1,
                                    fontSize: '12px'
                                  }}
                                >
                                  STATUS: Submitted
                                </Typography>
                              )}
                            </Box>
                            
                            {/* Only show action buttons for submitted requests - deleted requests are read-only */}
                            {console.log('Request status for ID', request.id, ':', request.status, 'Type:', typeof request.status)}
                            {request.status === 'submitted' && (
                              <Box sx={{ display: 'flex', gap: 1 }}>
                                <Button
                                  variant="outlined"
                                  size="small"
                                  onClick={() => handleAdminAction(request.id, 'rejected')}
                                  disabled={processingRequestId === request.id}
                                  sx={{ 
                                    textTransform: 'none',
                                    borderColor: '#d32f2f',
                                    color: '#d32f2f',
                                    '&:hover': {
                                      borderColor: '#b71c1c',
                                      color: '#b71c1c',
                                      backgroundColor: '#ffebee'
                                    },
                                    '&:disabled': {
                                      borderColor: '#ccc',
                                      color: '#ccc'
                                    }
                                  }}
                                >
                                  {processingRequestId === request.id ? 'Processing...' : 'Reject'}
                                </Button>
                                <Button
                                  variant="outlined"
                                  size="small"
                                  onClick={() => handleAdminAction(request.id, 'approved')}
                                  disabled={processingRequestId === request.id}
                                  sx={{ 
                                    textTransform: 'none',
                                    borderColor: '#2e7d32',
                                    color: '#2e7d32',
                                    '&:hover': {
                                      borderColor: '#1b5e20',
                                      color: '#1b5e20',
                                      backgroundColor: '#e8f5e8'
                                    },
                                    '&:disabled': {
                                      borderColor: '#ccc',
                                      color: '#ccc'
                                    }
                                  }}
                                >
                                  {processingRequestId === request.id ? 'Processing...' : 'Approve'}
                                </Button>
                              </Box>
                            )}
                          </Box>
                        </Paper>
                      ))}
                    </Box>
                  )}
                </Box>
              ) : !submittedRequest ? (
                // Show request form for regular users
                <>
                  <TextField
                    fullWidth
                    multiline
                    rows={8}
                    placeholder="Add text"
                    variant="outlined"
                    value={requestText}
                    onChange={(e) => setRequestText(e.target.value)}
                    sx={{ mb: 3 }}
                  />
                  
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, justifyContent: 'flex-end' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="body2">Request type</Typography>
                      <FormControl size="small">
                        <Select
                          value={requestType}
                          onChange={(e) => setRequestType(e.target.value)}
                          sx={{ minWidth: 120 }}
                        >
                          <MenuItem value="access">access</MenuItem>
                          <MenuItem value="reuse">reuse</MenuItem>
                          <MenuItem value="support">support</MenuItem>
                        </Select>
                      </FormControl>
                    </Box>
                    <Button 
                      variant="contained" 
                      onClick={handleSubmitRequest}
                      disabled={!requestText.trim() || isSubmitting}
                      sx={{ 
                        backgroundColor: '#7b1fa2',
                        '&:hover': { backgroundColor: '#6a1b9a' },
                        borderRadius: 2,
                        px: 3
                      }}
                    >
                      {isSubmitting ? 'Submitting...' : 'Request'}
                    </Button>
                  </Box>
                </>
              ) : (
                // Show submitted request
                <Paper sx={{ p: 3, backgroundColor: '#f9f9f9', border: '1px solid #e0e0e0' }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      {submittedRequest.date}
                    </Typography>
                    <Box sx={{ textAlign: 'right' }}>
                      {submittedRequest.status === 'approved' || submittedRequest.status === 'rejected' ? (
                        <Typography 
                          variant="body2" 
                          sx={{ 
                            backgroundColor: submittedRequest.status === 'approved' ? '#e8f5e8' : '#ffebee',
                            color: submittedRequest.status === 'approved' ? '#2e7d32' : '#c62828',
                            fontWeight: 'bold',
                            px: 2,
                            py: 0.5,
                            borderRadius: 1,
                            fontSize: '12px'
                          }}
                        >
                          STATUS: {submittedRequest.status === 'approved' ? 'Approved' : 'Rejected'} by {submittedRequest.approver?.name || 'Admin'} • {submittedRequest.reviewedAt ? new Date(submittedRequest.reviewedAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : 'Unknown date'}
                        </Typography>
                      ) : submittedRequest.status === 'deleted' ? (
                        <Typography 
                          variant="body2" 
                          sx={{ 
                            backgroundColor: '#f5f5f5',
                            color: '#666',
                            fontWeight: 'bold',
                            px: 2,
                            py: 0.5,
                            borderRadius: 1,
                            fontSize: '12px'
                          }}
                        >
                          STATUS: Deleted by requestor • {submittedRequest.reviewedAt ? new Date(submittedRequest.reviewedAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : 'Unknown date'}
                        </Typography>
                      ) : (
                        <Chip 
                          label={`STATUS: ${submittedRequest.status}`}
                          size="small"
                          sx={{ 
                            backgroundColor: '#fff3e0',
                            color: '#f57c00',
                            fontWeight: 'bold'
                          }}
                        />
                      )}
                    </Box>
                  </Box>
                  
                  <Typography variant="body1" sx={{ 
                    whiteSpace: 'pre-wrap',
                    lineHeight: 1.6,
                    mb: 2
                  }}>
                    Hi {submittedRequest.owner && submittedRequest.owner !== 'Unknown' ? submittedRequest.owner : '{OwnerTeam}'},
                    {"\n\n"}
                    I'd like to {submittedRequest.type} {submittedRequest.application} for our project/team. {submittedRequest.text}
                    {"\n\n"}
                    Requested outcome:
                    • Access for users in our environment (e.g., prod / UAT), or
                    • Integration guidance (API/docs) for system/process, and any prerequisites.
                    {"\n\n"}
                    Timeline: {'{when we need it}'}
                    Notes / constraints: {'{data sensitivity, region, dependencies, etc.}'}
                    {"\n\n"}
                    If this isn't the right fit, please suggest the closest alternative app in the category.
                    Thanks!
                  </Typography>
                  
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 3 }}>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      {submittedRequest.status === 'submitted' || submittedRequest.status === 'Submitted' ? (
                        <Button
                          variant="outlined"
                          size="small"
                          onClick={handleDeleteRequest}
                          disabled={isDeleting}
                          sx={{ 
                            textTransform: 'none',
                            borderColor: '#d32f2f',
                            color: '#d32f2f',
                            '&:hover': {
                              borderColor: '#b71c1c',
                              color: '#b71c1c',
                              backgroundColor: '#ffebee'
                            },
                            '&:disabled': {
                              borderColor: '#ccc',
                              color: '#ccc'
                            }
                          }}
                        >
                          {isDeleting ? 'Deleting...' : 'Delete Request'}
                        </Button>
                      ) : null}
                    </Box>
                    <Box>
                      {submittedRequest.status === 'deleted' || submittedRequest.status === 'rejected' ? (
                        <Button
                          variant="outlined"
                          size="small"
                          onClick={() => setSubmittedRequest(null)}
                          sx={{ 
                            textTransform: 'none',
                            borderColor: '#666',
                            color: '#666',
                            '&:hover': {
                              borderColor: '#333',
                              color: '#333'
                            }
                          }}
                        >
                          Submit new request
                        </Button>
                      ) : null}
                    </Box>
                  </Box>
                </Paper>
              )}
            </Box>
          )}

          {activeTab === 1 && (
            <Box>
              {/* Comment and Rate Section */}
              <Box sx={{ mb: 3 }}>
                <Button
                  onClick={() => setCommentModalOpen(true)}
                  sx={{ 
                    color: '#1976d2',
                    textDecoration: 'none',
                    fontSize: '14px',
                    textTransform: 'none',
                    p: 0,
                    minWidth: 'auto',
                    '&:hover': { 
                      textDecoration: 'underline',
                      backgroundColor: 'transparent'
                    }
                  }}
                >
                  Comment and rate
                </Button>
              </Box>

              {/* Ratings List */}
              <Box>
                {ratings
                  .filter((rating) => {
                    // Users can only see:
                    // 1. Non-hidden ratings
                    // 2. Their own hidden ratings
                    // 3. All ratings if they are admin
                    return !rating.isHidden || rating.canEdit || hasPermission('admin')
                  })
                  .map((rating) => (
                  <Paper 
                    key={rating.id} 
                    sx={{ 
                      p: 3, 
                      mb: 2, 
                      backgroundColor: rating.isHidden ? '#f5f5f5' : 'white',
                      opacity: rating.isHidden ? 0.7 : 1,
                      border: '1px solid #e0e0e0'
                    }}
                  >
                    {/* Rating Header */}
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                        <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                          {rating.user}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {rating.date}
                        </Typography>
                      </Box>
                      
                      {/* Hide/Unhide Button or Admin/User Message */}
                      {(rating.canEdit || hasPermission('admin')) && (
                        <>
                          {rating.hiddenByAdmin && rating.canEdit && !hasPermission('admin') ? (
                            // Show message for users whose comments were hidden by admin
                            <Typography 
                              variant="body2" 
                              sx={{ 
                                color: '#d32f2f',
                                fontSize: '12px',
                                fontStyle: 'italic'
                              }}
                            >
                              hidden by admin
                            </Typography>
                          ) : rating.hiddenByUser && hasPermission('admin') && !rating.canEdit ? (
                            // Show message for admins viewing user-hidden comments
                            <Typography 
                              variant="body2" 
                              sx={{ 
                                color: '#1976d2',
                                fontSize: '12px',
                                fontStyle: 'italic'
                              }}
                            >
                              hidden by user
                            </Typography>
                          ) : (
                            // Show hide/unhide button for other cases
                            <Button
                              size="small"
                              onClick={() => toggleRatingVisibility(rating.id)}
                              sx={{ 
                                color: '#666',
                                textTransform: 'none',
                                fontSize: '12px',
                                '&:hover': { backgroundColor: 'transparent', color: '#1976d2' }
                              }}
                            >
                              {rating.isHidden ? 'unhide' : 'hide'}
                            </Button>
                          )}
                        </>
                      )}
                    </Box>

                    {/* Star Ratings - Only show if ratings exist */}
                    {(rating.usability > 0 || rating.stability > 0) && (
                      <Box sx={{ mb: 2 }}>
                        {/* Usability - Only show if > 0 */}
                        {rating.usability > 0 && (
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
                            <Typography variant="body2" sx={{ minWidth: '60px' }}>
                              Usability
                            </Typography>
                            <Rating 
                              value={rating.usability} 
                              readOnly 
                              size="small"
                              sx={{ '& .MuiRating-iconFilled': { color: '#ffc107' } }}
                            />
                          </Box>
                        )}
                        {/* Stability - Only show if > 0 */}
                        {rating.stability > 0 && (
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                            <Typography variant="body2" sx={{ minWidth: '60px' }}>
                              Stability
                            </Typography>
                            <Rating 
                              value={rating.stability} 
                              readOnly 
                              size="small"
                              sx={{ '& .MuiRating-iconFilled': { color: '#ffc107' } }}
                            />
                          </Box>
                        )}
                      </Box>
                    )}

                    {/* Comment */}
                    {rating.comment && (
                      <Typography variant="body2" sx={{ mb: 2, lineHeight: 1.5 }}>
                        {rating.comment}
                      </Typography>
                    )}

                    {/* Recommendation */}
                    {rating.recommendation && (
                      <Typography variant="body2" color="text.secondary" sx={{ lineHeight: 1.5 }}>
                        {rating.recommendation}
                      </Typography>
                    )}
                  </Paper>
                ))}
              </Box>
            </Box>
          )}
        </Grid>

        {/* Right Column - Metadata */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, backgroundColor: '#f9f9f9' }}>
            {/* Lifecycle Stage */}
            <Box sx={{ mb: 3 }}>
              {hasPermission('admin') ? (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Typography variant="subtitle2" sx={{ color: '#666', minWidth: 'fit-content' }}>
                    LIFECYCLE STAGE:
                  </Typography>
                  <FormControl size="small" sx={{ minWidth: 120 }}>
                    <Select
                      value={application?.lifecycle || ''}
                      onChange={handleLifecycleChange}
                      disabled={updatingLifecycle}
                      displayEmpty
                      sx={{
                        '& .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#e0e0e0'
                        },
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#bdbdbd'
                        }
                      }}
                    >
                      <MenuItem value="" disabled>
                        <em>Select lifecycle stage</em>
                      </MenuItem>
                      <MenuItem value="In Dev">In Dev</MenuItem>
                      <MenuItem value="Pilot">Pilot</MenuItem>
                      <MenuItem value="Active">Active</MenuItem>
                      <MenuItem value="Maintenance">Maintenance</MenuItem>
                      <MenuItem value="Retiring">Retiring</MenuItem>
                      <MenuItem value="Deprecated">Deprecated</MenuItem>
                    </Select>
                  </FormControl>
                  {updatingLifecycle && (
                    <Typography variant="body2" sx={{ color: '#666', fontSize: '12px' }}>
                      Updating...
                    </Typography>
                  )}
                </Box>
              ) : (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Typography variant="subtitle2" sx={{ color: '#666', minWidth: 'fit-content' }}>
                    LIFECYCLE STAGE:
                  </Typography>
                  <Chip 
                    label={application?.lifecycle || 'Unknown'} 
                    sx={{ 
                      backgroundColor: getLifecycleColor(application?.lifecycle),
                      color: 'white',
                      fontWeight: 'bold'
                    }}
                  />
                </Box>
              )}
            </Box>

            {/* Tags */}
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle2" sx={{ mb: 1, color: '#666' }}>
                TAGS
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                <Chip 
                  label="JPA" 
                  size="small" 
                  clickable
                  onClick={() => navigate(`/findapp?tag=JPA`)}
                  sx={{ 
                    backgroundColor: '#e8f5e8',
                    '&:hover': {
                      backgroundColor: '#d4edda'
                    }
                  }} 
                />
                <Chip 
                  label="JMA" 
                  size="small" 
                  clickable
                  onClick={() => navigate(`/findapp?tag=JMA`)}
                  sx={{ 
                    backgroundColor: '#fff3e0',
                    '&:hover': {
                      backgroundColor: '#ffe0b2'
                    }
                  }} 
                />
                <Chip 
                  label="COMMON JAB" 
                  size="small" 
                  clickable
                  onClick={() => navigate(`/findapp?tag=COMMON JAB`)}
                  sx={{ 
                    backgroundColor: '#e3f2fd',
                    '&:hover': {
                      backgroundColor: '#bbdefb'
                    }
                  }} 
                />
              </Box>
            </Box>

            {/* Links */}
            <Box sx={{ mb: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                <LaunchIcon fontSize="small" color="primary" />
                <Link href="#" sx={{ color: '#1976d2', textDecoration: 'none' }}>
                  example.com
                </Link>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <LaunchIcon fontSize="small" color="primary" />
                <Link href="#" sx={{ color: '#1976d2', textDecoration: 'none' }}>
                  example.com
                </Link>
              </Box>
            </Box>

            <Divider sx={{ my: 2 }} />

            {/* Owner */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle2" sx={{ color: '#666' }}>
                OWNER:
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <PersonIcon fontSize="small" color="action" />
                <Typography variant="body2">Team Grub</Typography>
              </Box>
            </Box>

            {/* Contact */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle2" sx={{ color: '#666' }}>
                CONTACT
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <EmailIcon fontSize="small" color="action" />
                <Link href="mailto:eman@domain.com" sx={{ color: '#1976d2', textDecoration: 'none' }}>
                  eman@domain.com
                </Link>
              </Box>
            </Box>

            {/* Verified */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle2" sx={{ color: '#666' }}>
                VERIFIED:
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <VerifiedIcon fontSize="small" color="action" />
                <Typography variant="body2">DD MM YYYY</Typography>
              </Box>
            </Box>

            {/* Access */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle2" sx={{ color: '#666' }}>
                ACCESS:
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <LockIcon fontSize="small" color="action" />
                <Typography variant="body2">Open to all</Typography>
              </Box>
            </Box>

            {/* How to Reuse */}
            <Box>
              <Typography variant="subtitle2" sx={{ color: '#666' }}>
                HOW TO REUSE:
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <InfoIcon fontSize="small" color="action" />
                <Link href="#" sx={{ color: '#1976d2', textDecoration: 'none' }}>
                  example.com
                </Link>
              </Box>
            </Box>
          </Paper>
        </Grid>
      </Grid>

      {/* Lifecycle Change Reason Modal */}
      <Dialog 
        open={lifecycleModalOpen} 
        onClose={handleLifecycleCancel}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          Lifecycle Stage Change
        </DialogTitle>
        <DialogContent>
          <Typography variant="body1" sx={{ mb: 2 }}>
            You are about to change the lifecycle stage from <strong>{application?.lifecycle}</strong> to <strong>{pendingLifecycle}</strong>.
          </Typography>
          <Typography variant="body2" sx={{ mb: 2, color: '#666' }}>
            Please provide a reason for this change (required for audit trail):
          </Typography>
          <TextField
            fullWidth
            multiline
            rows={4}
            placeholder="Enter reason for lifecycle change..."
            value={changeReason}
            onChange={(e) => setChangeReason(e.target.value)}
            sx={{ mt: 1 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleLifecycleCancel} disabled={updatingLifecycle}>
            Cancel
          </Button>
          <Button 
            onClick={handleLifecycleConfirm} 
            variant="contained"
            disabled={updatingLifecycle || !changeReason.trim()}
          >
            {updatingLifecycle ? 'Updating...' : 'Confirm Change'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Comment Rate Modal */}
      <CommentRateModal
        open={commentModalOpen}
        onClose={() => setCommentModalOpen(false)}
        onSubmit={handleRatingSubmit}
        title="Comment or rate"
        isSubmitting={isSubmittingRating}
      />
    </Container>
  )
}

export default ApplicationDetail
