import { useState, useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import {
  Box,
  Container,
  Typography,
  TextField,
  InputAdornment,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Rating,
  Link,
  CircularProgress,
  Alert,
  Button,
} from '@mui/material'
import {
  Search as SearchIcon,
} from '@mui/icons-material'
import { apiService } from '../services/api'
import PageHeader from '../components/PageHeader'

function FindApp() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const [applications, setApplications] = useState([])
  const [feedback, setFeedback] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedFilter, setSelectedFilter] = useState('All')

  useEffect(() => {
    fetchApplications()
  }, [])

  useEffect(() => {
    // Check for tag parameter and set it as search query
    const tagParam = searchParams.get('tag')
    if (tagParam) {
      setSearchQuery(tagParam)
    }
  }, [searchParams])

  const fetchApplications = async () => {
    try {
      setLoading(true)
      const [appsResponse, feedbackResponse] = await Promise.all([
        apiService.getApplications(),
        apiService.getFeedback()
      ])
      setApplications(appsResponse.data)
      setFeedback(feedbackResponse.data)
    } catch (err) {
      setError('Failed to load applications')
      console.error('Error fetching applications:', err)
    } finally {
      setLoading(false)
    }
  }

  // Filter applications based on search and lifecycle filter
  const filteredApplications = applications.filter(app => {
    const matchesSearch = !searchQuery || 
      app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.technology.some(tech => tech.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesFilter = selectedFilter === 'All' || app.lifecycle === selectedFilter

    return matchesSearch && matchesFilter
  })

  // Get count for each lifecycle stage
  const getFilterCount = (stage) => {
    if (stage === 'All') return applications.length
    return applications.filter(app => app.lifecycle === stage).length
  }

  const filters = [
    { label: 'All', count: getFilterCount('All') },
    { label: 'In Dev', count: getFilterCount('In Dev') },
    { label: 'Pilot', count: getFilterCount('Pilot') },
    { label: 'Active', count: getFilterCount('Active') },
    { label: 'Maintenance', count: getFilterCount('Maintenance') },
    { label: 'Retiring', count: getFilterCount('Retiring') },
    { label: 'Deprecated', count: getFilterCount('Deprecated') },
  ]

  const getStageDisplayName = (lifecycle) => {
    // Return the lifecycle stage as-is since they match the filter labels
    return lifecycle
  }

  const getRatingDisplay = (app) => {
    if (!app.averageRatings || !app.feedbackCount) {
      return 'No ratings'
    }
    
    // Get visible rating count (exclude hidden ratings)
    const visibleFeedbackCount = getVisibleFeedbackCount(app.id)
    
    if (visibleFeedbackCount === 0) {
      return 'No visible ratings'
    }
    
    const avgRating = parseFloat(app.averageRatings.usability)
    return `${avgRating.toFixed(1)} (${visibleFeedbackCount})`
  }

  const getVisibleFeedbackCount = (applicationId) => {
    // Get hidden ratings from localStorage
    const hiddenRatings = JSON.parse(localStorage.getItem('hiddenRatings') || '[]')
    
    // Filter feedback for this app and exclude hidden ones
    const appFeedback = feedback.filter(f => 
      f.applicationId === applicationId && !hiddenRatings.includes(f.id)
    )
    
    return appFeedback.length
  }


  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress size={60} />
      </Box>
    )
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    )
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <PageHeader 
        showBreadcrumb={true}
        breadcrumbItems={[
          { label: 'Home', active: true },
          { label: 'Most reused', onClick: () => navigate('/most-reused') },
          { label: 'Most needs filled', onClick: () => navigate('/most-needs-filled') },
          { label: 'Most verified', onClick: () => navigate('/most-verified') },
          { label: 'Most improved', onClick: () => navigate('/most-improved') }
        ]}
      />

      {/* Header */}
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Typography variant="h3" sx={{ fontWeight: 'bold', color: '#333', mb: 4 }}>
          Find an app
        </Typography>
        
        <TextField
          fullWidth
          variant="outlined"
          placeholder="Search by name, purpose, domain or tag"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          sx={{ 
            maxWidth: 600,
            '& .MuiOutlinedInput-root': {
              borderRadius: 3,
              backgroundColor: 'white',
              '& fieldset': {
                borderColor: '#e0e0e0',
              },
              '&:hover fieldset': {
                borderColor: '#424242',
              },
            }
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon color="action" />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      {/* Filters */}
      <Box sx={{ mb: 4, display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
        <Typography variant="body2" sx={{ color: '#666', fontWeight: 500 }}>
          Filter by:
        </Typography>
          {filters.map((filter) => (
            <Chip
              key={filter.label}
              label={`${filter.label} (${filter.count})`}
              clickable
              variant={selectedFilter === filter.label ? 'filled' : 'outlined'}
              onClick={() => setSelectedFilter(filter.label)}
              sx={{
                borderRadius: 2,
                backgroundColor: selectedFilter === filter.label ? '#616161' : '#e0e0e0',
                color: selectedFilter === filter.label ? 'white' : '#666',
                borderColor: selectedFilter === filter.label ? '#616161' : '#bdbdbd',
                '&:hover': {
                  backgroundColor: selectedFilter === filter.label ? '#424242' : '#f5f5f5',
                  borderColor: '#9e9e9e'
                }
              }}
            />
          ))}
      </Box>

      {/* Applications Table */}
      <Paper sx={{ borderRadius: 2, overflow: 'hidden' }}>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '200px', minWidth: '200px' }}>Name</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '140px', minWidth: '140px' }}>Stage</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '50%' }}>Purpose</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '120px', minWidth: '120px', textAlign: 'right' }}>Rating</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredApplications.map((app, index) => (
                <TableRow 
                  key={app.id}
                  hover
                  onClick={() => navigate(`/applications/${app.id}`)}
                  sx={{ 
                    backgroundColor: index % 2 === 0 ? 'white' : '#f8f9fa',
                    cursor: 'pointer',
                    height: '72px',
                    '&:hover': { 
                      backgroundColor: '#e0e0e0'
                    }
                  }}
                >
                  <TableCell sx={{ verticalAlign: 'middle' }}>
                    <Typography
                      sx={{ 
                        color: '#1976d2',
                        fontWeight: 500,
                        '&:hover': { textDecoration: 'underline' }
                      }}
                    >
                      {app.name}
                    </Typography>
                  </TableCell>
                  <TableCell sx={{ verticalAlign: 'middle' }}>
                    <Chip 
                      label={getStageDisplayName(app.lifecycle)}
                      size="small"
                      sx={{ 
                        borderRadius: 1, 
                        border: 'none', 
                        backgroundColor: 'transparent',
                        minWidth: '80px',
                        justifyContent: 'flex-start',
                        '& .MuiChip-label': {
                          fontSize: '0.75rem',
                          fontWeight: 500,
                          px: 1
                        }
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ 
                    color: '#666',
                    verticalAlign: 'top',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'normal',
                    lineHeight: 1.4
                  }}>
                    {app.description}
                    {app.name.includes('AI') && ' 💝'}
                  </TableCell>
                  <TableCell sx={{ textAlign: 'right' }}>
                    <Box 
                      sx={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        justifyContent: 'flex-end', 
                        gap: 1,
                        cursor: 'pointer',
                        '&:hover': { opacity: 0.8 }
                      }}
                      onClick={(e) => {
                        e.stopPropagation() // Prevent row click
                        navigate(`/applications/${app.id}?tab=ratings`)
                      }}
                    >
                      {app.averageRatings && app.feedbackCount ? (
                        <Typography variant="body2" color="text.secondary">
                          {getRatingDisplay(app)}
                        </Typography>
                      ) : (
                        <Typography variant="body2" color="text.secondary">
                          No ratings
                        </Typography>
                      )}
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {filteredApplications.length === 0 && (
        <Paper sx={{ p: 6, textAlign: 'center', mt: 4 }}>
          <Typography variant="h6" sx={{ mb: 3, color: '#333' }}>
            No matching apps found
          </Typography>
          <Typography variant="body1" sx={{ mb: 3, color: '#333' }}>
            Submit{' '}
            <Typography 
              component="span" 
              sx={{ 
                color: '#333',
                textDecoration: 'underline',
                cursor: 'pointer',
                '&:hover': { color: '#1976d2' }
              }}
            >
              no match
            </Typography>
            {' '}or{' '}
            <Typography 
              component="span" 
              sx={{ 
                color: '#333',
                textDecoration: 'underline', 
                cursor: 'pointer',
                '&:hover': { color: '#1976d2' }
              }}
            >
              add your app
            </Typography>
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Tell us what you're trying to build or add a missing app to the catalogue
          </Typography>
        </Paper>
      )}
    </Container>
  )
}

export default FindApp
