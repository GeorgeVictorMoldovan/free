import { useState, useEffect } from 'react'
import {
  Box,
  Container,
  Typography,
  TextField,
  InputAdornment,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableSortLabel,
  Paper,
  CircularProgress,
  Alert,
  Link,
  Badge,
} from '@mui/material'
import {
  Search as SearchIcon,
} from '@mui/icons-material'
import { apiService } from '../services/api'
import { useAuth } from '../contexts/AuthContext'
import { useRequestsContext } from '../contexts/RequestsContext'
import { useNavigate } from 'react-router-dom'
import PageHeader from '../components/PageHeader'

function RequestsInbox() {
  const { user, hasPermission } = useAuth()
  const { decrementUnreadCount } = useRequestsContext()
  const navigate = useNavigate()
  const [requests, setRequests] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedFilter, setSelectedFilter] = useState('All')
  const [sortField, setSortField] = useState('requestedAt')
  const [sortDirection, setSortDirection] = useState('desc')
  const [stats, setStats] = useState({
    all: 0,
    open: 0,
    approved: 0,
    rejected: 0,
    deleted: 0
  })

  useEffect(() => {
    if (hasPermission('admin')) {
      fetchRequests()
    }
  }, [])

  const fetchRequests = async () => {
    try {
      setLoading(true)
      const response = await apiService.getAllRequests()
      const requestData = response.data || response
      setRequests(requestData)
      
      // Calculate stats
      const newStats = {
        all: requestData.length,
        open: requestData.filter(r => r.status === 'submitted' && !r.readBy).length, // Only unread submitted requests
        approved: requestData.filter(r => r.status === 'approved').length,
        rejected: requestData.filter(r => r.status === 'rejected').length,
        deleted: requestData.filter(r => r.status === 'deleted').length
      }
      setStats(newStats)
    } catch (err) {
      setError('Failed to load requests')
      console.error('Error fetching requests:', err)
    } finally {
      setLoading(false)
    }
  }

  // Filter requests based on search and status filter
  const filteredRequests = requests.filter(request => {
    const matchesSearch = !searchQuery || 
      request.requester?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.application?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.title.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesFilter = selectedFilter === 'All' || 
      (selectedFilter === 'Open' && request.status === 'submitted' && !request.readBy) ||
      (selectedFilter === 'Approved' && request.status === 'approved') ||
      (selectedFilter === 'Rejected' && request.status === 'rejected') ||
      (selectedFilter === 'Deleted' && request.status === 'deleted')

    return matchesSearch && matchesFilter
  })

  const getTimeAgo = (dateString) => {
    const now = new Date()
    const date = new Date(dateString)
    const diffInMinutes = Math.floor((now - date) / (1000 * 60))
    
    if (diffInMinutes < 60) {
      // Show minimum of 1 minute instead of 0 minutes
      const minutes = Math.max(1, diffInMinutes)
      return `${minutes} min`
    } else if (diffInMinutes < 1440) { // Less than 24 hours
      const hours = Math.floor(diffInMinutes / 60)
      return `${hours} hour${hours !== 1 ? 's' : ''}`
    } else if (diffInMinutes < 525600) { // Less than 365 days
      const days = Math.floor(diffInMinutes / 1440)
      return `${days} day${days !== 1 ? 's' : ''}`
    } else {
      const years = Math.floor(diffInMinutes / 525600)
      return `${years} Year${years !== 1 ? 's' : ''}`
    }
  }

  const getRowColor = (age) => {
    const diffInMinutes = new Date() - new Date(age)
    const days = Math.floor(diffInMinutes / (1000 * 60 * 60 * 24))
    
    if (days >= 365) {
      return '#ffebee' // Light red for very old requests
    }
    return 'inherit'
  }

  const handleRowClick = async (request) => {
    try {
      // Mark request as read if it's unread and submitted
      if (request.status === 'submitted' && !request.readBy) {
        await apiService.markRequestAsRead(request.id)
        
        // Update local state to reflect read status
        setRequests(prevRequests => 
          prevRequests.map(r => 
            r.id === request.id 
              ? { ...r, readBy: user?.id, readAt: new Date().toISOString() }
              : r
          )
        )
        
        // Update stats to reflect new unread count
        setStats(prevStats => ({
          ...prevStats,
          open: prevStats.open - 1
        }))
        
        // Update global unread count in context
        decrementUnreadCount()
      }
    } catch (error) {
      console.error('Error marking request as read:', error)
    }
    
    // Navigate to application details with requests tab opened
    navigate(`/applications/${request.applicationId}?tab=requests`)
  }

  const handleSort = (field) => {
    const isAsc = sortField === field && sortDirection === 'asc'
    setSortDirection(isAsc ? 'desc' : 'asc')
    setSortField(field)
  }

  const sortedAndFilteredRequests = filteredRequests.sort((a, b) => {
    let aValue = a[sortField]
    let bValue = b[sortField]

    // Handle special cases
    if (sortField === 'requesterName') {
      aValue = a.requesterName || ''
      bValue = b.requesterName || ''
    } else if (sortField === 'applicationName') {
      aValue = a.applicationName || ''
      bValue = b.applicationName || ''
    } else if (sortField === 'requestedAt') {
      aValue = new Date(a.requestedAt || 0)
      bValue = new Date(b.requestedAt || 0)
    }

    if (aValue < bValue) {
      return sortDirection === 'asc' ? -1 : 1
    }
    if (aValue > bValue) {
      return sortDirection === 'asc' ? 1 : -1
    }
    return 0
  })

  const filters = [
    { label: 'All', count: stats.all },
    { label: 'Open', count: stats.open },
    { label: 'Approved', count: stats.approved },
    { label: 'Rejected', count: stats.rejected },
    { label: 'Deleted', count: stats.deleted },
  ]

  if (!hasPermission('admin')) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">Access denied. Admin privileges required.</Alert>
      </Box>
    )
  }

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress size={60} />
      </Box>
    )
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    )
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <PageHeader 
        showBreadcrumb={true}
        breadcrumbItems={[
          { label: 'Home', onClick: () => navigate('/') },
          { label: 'Requests', active: true }
        ]}
      />

      {/* Header with notification */}
      <Box sx={{ textAlign: 'center', mb: 6, position: 'relative' }}>
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', mb: 4 }}>
          <Typography variant="h3" sx={{ fontWeight: 'bold', color: '#333' }}>
            Requests Inbox
          </Typography>
        </Box>
        
        <TextField
          fullWidth
          variant="outlined"
          placeholder="Search by requester, reason, or app"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          sx={{ 
            maxWidth: 600,
            '& .MuiOutlinedInput-root': {
              borderRadius: 3,
              backgroundColor: 'white',
              '& fieldset': {
                borderColor: '#e0e0e0',
              },
              '&:hover fieldset': {
                borderColor: '#424242',
              },
            }
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon color="action" />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      {/* Filters */}
      <Box sx={{ mb: 4, display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
        <Typography variant="body2" sx={{ color: '#666', fontWeight: 500 }}>
          Filter by:
        </Typography>
        {filters.map((filter) => (
          <Chip
            key={filter.label}
            label={`${filter.label} ${filter.count}`}
            clickable
            variant={selectedFilter === filter.label ? 'filled' : 'outlined'}
            onClick={() => setSelectedFilter(filter.label)}
            sx={{
              borderRadius: 2,
              backgroundColor: selectedFilter === filter.label ? '#616161' : '#e0e0e0',
              color: selectedFilter === filter.label ? 'white' : '#666',
              borderColor: selectedFilter === filter.label ? '#616161' : '#bdbdbd',
              '&:hover': {
                backgroundColor: selectedFilter === filter.label ? '#424242' : '#f5f5f5',
                borderColor: '#9e9e9e'
              }
            }}
          />
        ))}
      </Box>

      {/* Requests Table */}
      <Paper sx={{ borderRadius: 2, overflow: 'hidden' }}>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '15%' }}>
                  <TableSortLabel
                    active={sortField === 'requesterName'}
                    direction={sortField === 'requesterName' ? sortDirection : 'asc'}
                    onClick={() => handleSort('requesterName')}
                  >
                    Requester
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '15%' }}>
                  <TableSortLabel
                    active={sortField === 'applicationName'}
                    direction={sortField === 'applicationName' ? sortDirection : 'asc'}
                    onClick={() => handleSort('applicationName')}
                  >
                    App Name
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '55%' }}>
                  <TableSortLabel
                    active={sortField === 'purpose'}
                    direction={sortField === 'purpose' ? sortDirection : 'asc'}
                    onClick={() => handleSort('purpose')}
                  >
                    Reason
                  </TableSortLabel>
                </TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '15%', textAlign: 'right' }}>
                  <TableSortLabel
                    active={sortField === 'requestedAt'}
                    direction={sortField === 'requestedAt' ? sortDirection : 'asc'}
                    onClick={() => handleSort('requestedAt')}
                  >
                    Age
                  </TableSortLabel>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {sortedAndFilteredRequests.map((request, index) => (
                <TableRow 
                  key={request.id}
                  hover
                  onClick={() => handleRowClick(request)}
                  sx={{ 
                    backgroundColor: request.status === 'submitted' && !request.readBy 
                      ? '#f5f5f5' // Light grey for unread requests
                      : index % 2 === 0 ? 'white' : '#f8f9fa',
                    borderLeft: request.status === 'submitted' && !request.readBy 
                      ? '4px solid #9e9e9e' // Grey left border for unread
                      : 'none',
                    cursor: 'pointer',
                    '&:hover': { 
                      backgroundColor: '#e0e0e0'
                    }
                  }}
                >
                  <TableCell>
                    <Typography variant="body2" sx={{ 
                      fontWeight: request.status === 'submitted' && !request.readBy ? 'bold' : 'medium' 
                    }}>
                      {request.requester?.name || 'Unknown User'}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Link
                      onClick={(e) => {
                        e.stopPropagation()
                        navigate(`/applications/${request.applicationId}`)
                      }}
                      sx={{ 
                        color: '#1976d2',
                        cursor: 'pointer',
                        textDecoration: 'none',
                        fontWeight: request.status === 'submitted' && !request.readBy ? 'bold' : 'normal',
                        '&:hover': { textDecoration: 'underline' }
                      }}
                    >
                      {request.application?.name || 'Unknown App'}
                    </Link>
                  </TableCell>
                  <TableCell sx={{ color: '#666' }}>
                    <Typography variant="body2" sx={{ 
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                      lineHeight: 1.4,
                      fontWeight: request.status === 'submitted' && !request.readBy ? 'bold' : 'normal'
                    }}>
                      {request.description}
                    </Typography>
                  </TableCell>
                  <TableCell sx={{ textAlign: 'right' }}>
                    <Typography 
                      variant="body2" 
                      sx={{ 
                        color: getTimeAgo(request.requestedAt).includes('Year') ? '#f44336' : '#666',
                        fontWeight: (request.status === 'submitted' && !request.readBy) || getTimeAgo(request.requestedAt).includes('Year') ? 'bold' : 'normal'
                      }}
                    >
                      {getTimeAgo(request.requestedAt)}
                    </Typography>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {filteredRequests.length === 0 && (
        <Paper sx={{ p: 6, textAlign: 'center', mt: 4 }}>
          <Typography variant="h6" sx={{ mb: 2, color: '#333' }}>
            No matching requests found
          </Typography>
          <Typography variant="body1" sx={{ color: '#666' }}>
            {selectedFilter === 'All' ? 'No requests in the system.' : `No ${selectedFilter.toLowerCase()} requests found.`}
          </Typography>
        </Paper>
      )}
    </Container>
  )
}

export default RequestsInbox
