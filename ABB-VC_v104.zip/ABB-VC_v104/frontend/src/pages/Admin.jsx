import { useState, useEffect } from 'react'
import {
  Box,
  Paper,
  Typography,
  CircularProgress,
  Alert,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Chip,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  Card,
  CardContent,
  Grid,
  Tabs,
  Tab,
  Divider,
} from '@mui/material'
import { DataGrid } from '@mui/x-data-grid'
import {
  CheckCircle as ApproveIcon,
  Cancel as RejectIcon,
  Pending as PendingIcon,
  AdminPanelSettings as AdminIcon,
  Timeline as LifecycleIcon,
  Security as SecurityIcon,
} from '@mui/icons-material'
import { apiService } from '../services/api'

function TabPanel({ children, value, index, ...other }) {
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`admin-tabpanel-${index}`}
      aria-labelledby={`admin-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  )
}

function Admin() {
  const [approvals, setApprovals] = useState([])
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [tabValue, setTabValue] = useState(0)
  const [open, setOpen] = useState(false)
  const [selectedApproval, setSelectedApproval] = useState(null)
  const [decision, setDecision] = useState('')
  const [notes, setNotes] = useState('')

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [approvalsRes, usersRes] = await Promise.all([
        apiService.getApprovals(),
        apiService.getUsers()
      ])
      setApprovals(approvalsRes.data)
      setUsers(usersRes.data)
    } catch (err) {
      setError('Failed to load admin data')
    } finally {
      setLoading(false)
    }
  }

  const handleProcessApproval = async () => {
    try {
      await apiService.processApproval({
        approvalId: selectedApproval.id,
        decision,
        reviewerId: 1, // Current admin user ID
        notes
      })
      setOpen(false)
      setSelectedApproval(null)
      setDecision('')
      setNotes('')
      fetchData() // Refresh data
    } catch (err) {
      setError('Failed to process approval')
    }
  }

  const openApprovalDialog = (approval, approvalDecision) => {
    setSelectedApproval(approval)
    setDecision(approvalDecision)
    setOpen(true)
  }

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'approved':
        return 'success'
      case 'pending':
        return 'warning'
      case 'rejected':
        return 'error'
      default:
        return 'default'
    }
  }

  const getChangeTypeIcon = (changeType) => {
    switch (changeType) {
      case 'lifecycle_promotion':
        return <LifecycleIcon />
      case 'technology_update':
        return <SecurityIcon />
      default:
        return <AdminIcon />
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A'
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const approvalsColumns = [
    {
      field: 'id',
      headerName: 'ID',
      width: 80,
    },
    {
      field: 'application',
      headerName: 'Application',
      width: 180,
      renderCell: (params) => (
        <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
          {params.value?.name}
        </Typography>
      ),
    },
    {
      field: 'changeType',
      headerName: 'Change Type',
      width: 150,
      renderCell: (params) => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          {getChangeTypeIcon(params.value)}
          <Typography variant="body2">
            {params.value === 'lifecycle_promotion' ? 'Lifecycle' : 'Technology'}
          </Typography>
        </Box>
      ),
    },
    {
      field: 'requester',
      headerName: 'Requester',
      width: 150,
      renderCell: (params) => (
        <Typography variant="body2">
          {params.value?.name}
        </Typography>
      ),
    },
    {
      field: 'requestedAt',
      headerName: 'Requested',
      width: 120,
      renderCell: (params) => formatDate(params.value),
    },
    {
      field: 'status',
      headerName: 'Status',
      width: 120,
      renderCell: (params) => (
        <Chip
          label={params.value}
          color={getStatusColor(params.value)}
          size="small"
        />
      ),
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 200,
      renderCell: (params) => (
        params.row.status === 'pending' ? (
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button
              size="small"
              color="success"
              startIcon={<ApproveIcon />}
              onClick={() => openApprovalDialog(params.row, 'approved')}
            >
              Approve
            </Button>
            <Button
              size="small"
              color="error"
              startIcon={<RejectIcon />}
              onClick={() => openApprovalDialog(params.row, 'rejected')}
            >
              Reject
            </Button>
          </Box>
        ) : (
          <Typography variant="body2" color="text.secondary">
            {params.row.status}
          </Typography>
        )
      ),
    },
  ]

  const usersColumns = [
    {
      field: 'id',
      headerName: 'ID',
      width: 80,
    },
    {
      field: 'name',
      headerName: 'Name',
      width: 200,
    },
    {
      field: 'email',
      headerName: 'Email',
      width: 250,
    },
    {
      field: 'role',
      headerName: 'Role',
      width: 130,
      renderCell: (params) => (
        <Chip
          label={params.value}
          color={params.value === 'Administrator' ? 'error' : 'primary'}
          size="small"
        />
      ),
    },
    {
      field: 'department',
      headerName: 'Department',
      width: 150,
    },
    {
      field: 'status',
      headerName: 'Status',
      width: 120,
      renderCell: (params) => (
        <Chip
          label={params.value}
          color={params.value === 'active' ? 'success' : 'default'}
          size="small"
        />
      ),
    },
  ]

  if (loading) {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: 400,
        }}
      >
        <CircularProgress size={60} />
      </Box>
    )
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    )
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" sx={{ fontWeight: 'bold', mb: 3 }}>
        Admin Panel
      </Typography>

      {/* Summary Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="warning.main" sx={{ fontWeight: 'bold' }}>
                {approvals.filter(a => a.status === 'pending').length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Pending Approvals
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="primary.main" sx={{ fontWeight: 'bold' }}>
                {users.filter(u => u.status === 'active').length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Active Users
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="success.main" sx={{ fontWeight: 'bold' }}>
                {approvals.filter(a => a.status === 'approved').length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Processed Today
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Tabs */}
      <Paper sx={{ mb: 3 }}>
        <Tabs
          value={tabValue}
          onChange={(event, newValue) => setTabValue(newValue)}
          indicatorColor="primary"
          textColor="primary"
        >
          <Tab label="Approvals" />
          <Tab label="User Management" />
        </Tabs>
      </Paper>

      {/* Approvals Tab */}
      <TabPanel value={tabValue} index={0}>
        <Paper sx={{ height: 600, width: '100%' }}>
          <DataGrid
            rows={approvals}
            columns={approvalsColumns}
            pageSize={10}
            rowsPerPageOptions={[10, 25, 50]}
            disableSelectionOnClick
            sx={{
              border: 'none',
              '& .MuiDataGrid-cell:focus': {
                outline: 'none',
              },
            }}
          />
        </Paper>
      </TabPanel>

      {/* Users Tab */}
      <TabPanel value={tabValue} index={1}>
        <Paper sx={{ height: 600, width: '100%' }}>
          <DataGrid
            rows={users}
            columns={usersColumns}
            pageSize={10}
            rowsPerPageOptions={[10, 25, 50]}
            disableSelectionOnClick
            sx={{
              border: 'none',
              '& .MuiDataGrid-cell:focus': {
                outline: 'none',
              },
            }}
          />
        </Paper>
      </TabPanel>

      {/* Approval Dialog */}
      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>
          {decision === 'approved' ? 'Approve Request' : 'Reject Request'}
        </DialogTitle>
        <DialogContent>
          {selectedApproval && (
            <Box>
              <Typography variant="h6" sx={{ mb: 2 }}>
                {selectedApproval.application?.name}
              </Typography>
              
              <Box sx={{ mb: 2 }}>
                <Typography variant="body2" color="text.secondary">
                  Change Type: {selectedApproval.changeType === 'lifecycle_promotion' ? 'Lifecycle Promotion' : 'Technology Update'}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Requested by: {selectedApproval.requester?.name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Requested on: {formatDate(selectedApproval.requestedAt)}
                </Typography>
              </Box>

              <Divider sx={{ my: 2 }} />

              <Typography variant="body2" sx={{ mb: 2 }}>
                <strong>Reason:</strong> {selectedApproval.reason}
              </Typography>

              {selectedApproval.changeType === 'lifecycle_promotion' && (
                <Typography variant="body2" sx={{ mb: 2 }}>
                  <strong>Lifecycle Change:</strong> {selectedApproval.fromStage} → {selectedApproval.toStage}
                </Typography>
              )}

              {selectedApproval.details && (
                <Typography variant="body2" sx={{ mb: 2 }}>
                  <strong>Details:</strong> {selectedApproval.details}
                </Typography>
              )}

              <TextField
                label="Admin Notes"
                multiline
                rows={4}
                fullWidth
                variant="outlined"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                sx={{ mt: 2 }}
                placeholder={
                  decision === 'approved' 
                    ? 'Add any notes about the approval...' 
                    : 'Explain the reason for rejection...'
                }
              />
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button 
            onClick={handleProcessApproval} 
            variant="contained"
            color={decision === 'approved' ? 'success' : 'error'}
          >
            {decision === 'approved' ? 'Approve' : 'Reject'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default Admin
