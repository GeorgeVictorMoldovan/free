import { useState, useEffect } from 'react'
import {
  Container,
  Typography,
  Button,
  Box,
  Paper,
  Modal,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Grid,
  Alert,
  CircularProgress
} from '@mui/material'
import { Add as AddIcon, Close as CloseIcon } from '@mui/icons-material'
import { useAuth } from '../contexts/AuthContext'
import { apiService } from '../services/api'

function Settings() {
  const { hasPermission } = useAuth()
  const [addModalOpen, setAddModalOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitMessage, setSubmitMessage] = useState('')
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    owner: '',
    team: '',
    technology: [],
    lifecycle: '',
    version: '',
    documentation: '',
    repository: '',
    dependencies: [],
    tags: []
  })

  const lifecycleStages = [
    'In Dev',
    'Pilot',
    'Active',
    'Maintenance',
    'Retiring',
    'Deprecated'
  ]

  const technologies = [
    'React',
    'Angular',
    'Vue',
    'Node.js',
    'Python',
    'Java',
    '.NET',
    'PHP',
    'MySQL'
  ]

  const teams = [
    'Engineering',
    'Platform Engineering',
    'Customer Experience',
    'Supply Chain',
    'Human Resources',
    'Finance',
    'Accounting',
    'DevOps',
    'HR',
    'SRE',
    'Security',
    'Business Process',
    'Data Engineering',
    'Quality Assurance',
    'Cloud Operations'
  ]

  // Check if user has admin permissions
  if (!hasPermission || !hasPermission('admin')) {
    return (
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Alert severity="error">
          Access denied. Admin permissions required.
        </Alert>
      </Container>
    )
  }

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleArrayFieldChange = (field, value) => {
    const items = value.split(',').map(item => item.trim()).filter(item => item.length > 0)
    setFormData(prev => ({
      ...prev,
      [field]: items
    }))
  }

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      owner: '',
      team: '',
      technology: [],
      lifecycle: '',
      version: '',
      documentation: '',
      repository: '',
      dependencies: [],
      tags: []
    })
    setSubmitMessage('')
  }

  const handleAddApplication = async () => {
    if (!formData.name || !formData.description || !formData.owner || !formData.team || !formData.lifecycle) {
      setSubmitMessage('Please fill in all required fields (Name, Description, Owner, Team, Lifecycle)')
      return
    }

    setIsSubmitting(true)
    setSubmitMessage('')

    try {
      const applicationData = {
        ...formData,
        deploymentDate: new Date().toISOString(),
        lastUpdated: new Date().toISOString(),
        usageMetrics: {
          monthlyUsers: 0,
          uptime: 95.0,
          performance: 500
        }
      }

      // This would call the API to create a new application
      // For now, we'll simulate the call
      await new Promise(resolve => setTimeout(resolve, 1500)) // Simulate API call
      
      setSubmitMessage('Application added successfully!')
      setTimeout(() => {
        setAddModalOpen(false)
        resetForm()
      }, 2000)
      
    } catch (error) {
      setSubmitMessage('Error adding application. Please try again.')
      console.error('Error adding application:', error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleCloseModal = () => {
    setAddModalOpen(false)
    resetForm()
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" sx={{ fontWeight: 'bold', color: '#333', mb: 2 }}>
          Admin Settings
        </Typography>
        <Typography variant="body1" sx={{ color: '#666' }}>
          Manage applications and system settings
        </Typography>
      </Box>

      {/* Applications Management Section */}
      <Paper sx={{ p: 4, mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h6" sx={{ fontWeight: 'bold', color: '#333' }}>
            Application Management
          </Typography>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => setAddModalOpen(true)}
            sx={{
              backgroundColor: '#1976d2',
              '&:hover': { backgroundColor: '#1565c0' }
            }}
          >
            Add Application
          </Button>
        </Box>
        <Typography variant="body2" sx={{ color: '#666' }}>
          Add new applications to the catalog manually. All fields marked with * are required.
        </Typography>
      </Paper>

      {/* Add Application Modal */}
      <Modal
        open={addModalOpen}
        onClose={handleCloseModal}
        sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      >
        <Box sx={{
          backgroundColor: 'white',
          borderRadius: 2,
          p: 4,
          width: '90%',
          maxWidth: 600,
          maxHeight: '90vh',
          overflow: 'auto',
          position: 'relative'
        }}>
          {/* Modal Header */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
              Add New Application
            </Typography>
            <Button
              onClick={handleCloseModal}
              sx={{ minWidth: 'auto', p: 1 }}
            >
              <CloseIcon />
            </Button>
          </Box>

          {/* Form Fields */}
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Application Name *"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="e.g., CacheWhisperer"
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Description *"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                placeholder="Brief description of what the application does"
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Owner *"
                value={formData.owner}
                onChange={(e) => handleInputChange('owner', e.target.value)}
                placeholder="e.g., Alice Johnson"
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Team *</InputLabel>
                <Select
                  value={formData.team}
                  label="Team *"
                  onChange={(e) => handleInputChange('team', e.target.value)}
                >
                  {teams.map(team => (
                    <MenuItem key={team} value={team}>{team}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>Lifecycle Stage *</InputLabel>
                <Select
                  value={formData.lifecycle}
                  label="Lifecycle Stage *"
                  onChange={(e) => handleInputChange('lifecycle', e.target.value)}
                >
                  {lifecycleStages.map(stage => (
                    <MenuItem key={stage} value={stage}>{stage}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Version"
                value={formData.version}
                onChange={(e) => handleInputChange('version', e.target.value)}
                placeholder="e.g., 2.1.0"
              />
            </Grid>

            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Technologies</InputLabel>
                <Select
                  multiple
                  value={formData.technology}
                  label="Technologies"
                  onChange={(e) => handleInputChange('technology', e.target.value)}
                  renderValue={(selected) => (
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {selected.map((value) => (
                        <Chip key={value} label={value} size="small" />
                      ))}
                    </Box>
                  )}
                >
                  {technologies.map(tech => (
                    <MenuItem key={tech} value={tech}>{tech}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Documentation URL"
                value={formData.documentation}
                onChange={(e) => handleInputChange('documentation', e.target.value)}
                placeholder="https://wiki.company.com/app-name"
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Repository URL"
                value={formData.repository}
                onChange={(e) => handleInputChange('repository', e.target.value)}
                placeholder="https://git.company.com/apps/app-name"
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Dependencies"
                value={formData.dependencies.join(', ')}
                onChange={(e) => handleArrayFieldChange('dependencies', e.target.value)}
                placeholder="Auth Service, Database API (comma-separated)"
                helperText="Enter dependencies separated by commas"
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Tags"
                value={formData.tags.join(', ')}
                onChange={(e) => handleArrayFieldChange('tags', e.target.value)}
                placeholder="performance, backend, high-priority (comma-separated)"
                helperText="Enter tags separated by commas"
              />
            </Grid>
          </Grid>

          {/* Submit Message */}
          {submitMessage && (
            <Alert 
              severity={submitMessage.includes('Error') ? 'error' : 'success'} 
              sx={{ mt: 2 }}
            >
              {submitMessage}
            </Alert>
          )}

          {/* Modal Actions */}
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2, mt: 4 }}>
            <Button
              variant="outlined"
              onClick={handleCloseModal}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              variant="contained"
              onClick={handleAddApplication}
              disabled={isSubmitting}
              sx={{
                backgroundColor: '#1976d2',
                '&:hover': { backgroundColor: '#1565c0' }
              }}
            >
              {isSubmitting ? (
                <>
                  <CircularProgress size={20} sx={{ mr: 1 }} />
                  Adding...
                </>
              ) : (
                'Add Application'
              )}
            </Button>
          </Box>
        </Box>
      </Modal>
    </Container>
  )
}

export default Settings
