import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Box,
  Container,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Rating,
  Chip,
  CircularProgress,
  Alert,
} from '@mui/material'
import { CheckCircle, Verified, Star } from '@mui/icons-material'
import { apiService } from '../services/api'
import PageHeader from '../components/PageHeader'

function MostVerified() {
  const navigate = useNavigate()
  const [applications, setApplications] = useState([])
  const [feedback, setFeedback] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [appsResponse, feedbackResponse] = await Promise.all([
        apiService.getApplications(),
        apiService.getFeedback()
      ])
      setApplications(appsResponse.data)
      setFeedback(feedbackResponse.data)
    } catch (err) {
      setError('Failed to load data')
    } finally {
      setLoading(false)
    }
  }

  // Calculate verification metrics for each application
  const getApplicationsWithVerificationMetrics = () => {
    return applications.map(app => {
      let verificationScore = 0
      const verificationCriteria = []

      // 1. Documentation Quality (25 points)
      const appFeedback = feedback.filter(fb => fb.applicationId === app.id)
      if (appFeedback.length > 0) {
        const docRatings = appFeedback.map(fb => fb.ratings.documentation).filter(r => r > 0)
        if (docRatings.length > 0) {
          const avgDocRating = docRatings.reduce((sum, r) => sum + r, 0) / docRatings.length
          if (avgDocRating >= 4.0) {
            verificationScore += 25
            verificationCriteria.push('Documentation')
          }
        }
      }

      // 2. Reliability (20 points)
      if (app.usageMetrics && app.usageMetrics.uptime >= 98.0) {
        verificationScore += 20
        verificationCriteria.push('Reliability')
      }

      // 3. Information Completeness (20 points)
      const hasCompleteInfo = app.description && 
                             app.owner && 
                             app.team && 
                             app.technology && app.technology.length > 0 &&
                             app.documentation &&
                             app.repository
      if (hasCompleteInfo) {
        verificationScore += 20
        verificationCriteria.push('Complete Info')
      }

      // 4. User Confidence (20 points)
      if (appFeedback.length >= 3) {
        const avgRating = appFeedback.reduce((sum, fb) => {
          const ratings = Object.values(fb.ratings).filter(r => r > 0)
          const fbAvg = ratings.length > 0 ? ratings.reduce((s, r) => s + r, 0) / ratings.length : 0
          return sum + fbAvg
        }, 0) / appFeedback.length

        if (avgRating >= 4.0) {
          verificationScore += 20
          verificationCriteria.push('User Trust')
        }
      }

      // 5. Production Readiness (15 points)
      const isProductionReady = app.lifecycle === 'Active' || 
                               app.lifecycle === 'Pilot' ||
                               app.lifecycle === 'Maintenance'
      if (isProductionReady && app.version && !app.version.includes('alpha')) {
        verificationScore += 15
        verificationCriteria.push('Production Ready')
      }

      // 6. Active Maintenance (10 points)
      if (app.lastUpdated) {
        const lastUpdate = new Date(app.lastUpdated)
        const now = new Date()
        const daysSinceUpdate = (now - lastUpdate) / (1000 * 60 * 60 * 24)
        if (daysSinceUpdate <= 90) { // Updated within last 3 months
          verificationScore += 10
          verificationCriteria.push('Active Maintenance')
        }
      }

      // Calculate verification level based on score
      let verificationLevel = 'Unverified'
      let verificationColor = '#999'
      
      if (verificationScore >= 80) {
        verificationLevel = 'Fully Verified'
        verificationColor = '#2e7d32' // Green
      } else if (verificationScore >= 60) {
        verificationLevel = 'Well Verified'  
        verificationColor = '#1976d2' // Blue
      } else if (verificationScore >= 40) {
        verificationLevel = 'Partially Verified'
        verificationColor = '#f57c00' // Orange
      }

      return {
        ...app,
        verificationScore,
        verificationCriteria,
        verificationLevel,
        verificationColor
      }
    })
    .filter(app => app.verificationScore >= 40) // Only show apps with meaningful verification
    .sort((a, b) => b.verificationScore - a.verificationScore) // Sort by verification score
    .slice(0, 10) // Top 10 most verified
  }

  const getVerificationIcon = (level) => {
    switch (level) {
      case 'Fully Verified':
        return <Verified sx={{ color: '#2e7d32', fontSize: '1.2rem' }} />
      case 'Well Verified':
        return <CheckCircle sx={{ color: '#1976d2', fontSize: '1.2rem' }} />
      case 'Partially Verified':
        return <Star sx={{ color: '#f57c00', fontSize: '1.2rem' }} />
      default:
        return null
    }
  }

  const getRatingDisplay = (app) => {
    if (!app.averageRatings || !app.feedbackCount) {
      return 'No ratings'
    }
    
    // Calculate overall rating from averages
    const ratings = app.averageRatings
    const ratingValues = Object.values(ratings).map(r => parseFloat(r))
    const validRatings = ratingValues.filter(r => r > 0)
    
    if (validRatings.length === 0) {
      return 'No ratings'
    }
    
    const overall = validRatings.reduce((sum, rating) => sum + rating, 0) / validRatings.length
    return `${overall.toFixed(1)} (${app.feedbackCount})`
  }

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ py: 4, display: 'flex', justifyContent: 'center' }}>
        <CircularProgress />
      </Container>
    )
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    )
  }

  const topApplications = getApplicationsWithVerificationMetrics()

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <PageHeader 
        showBreadcrumb={true}
        breadcrumbItems={[
          { label: 'Home', onClick: () => navigate('/') },
          { label: 'Most reused', onClick: () => navigate('/most-reused') },
          { label: 'Most needs filled', onClick: () => navigate('/most-needs-filled') },
          { label: 'Most verified', active: true },
          { label: 'Most improved', onClick: () => navigate('/most-improved') }
        ]}
      />

      {/* Header */}
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Typography variant="h3" sx={{ fontWeight: 'bold', color: '#333', mb: 4 }}>
          Most verified
        </Typography>
        
        <Typography variant="body1" sx={{ color: '#666', maxWidth: 800, mx: 'auto', lineHeight: 1.6 }}>
          These apps have earned trust. Verified status reflects clarity, completeness, and confidence in
          the information provided. Being here shows that your app is well-documented, reliable, and
          ready for broader adoption.
        </Typography>
      </Box>

      {/* Applications Table */}
      <Paper sx={{ borderRadius: 2, overflow: 'hidden' }}>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '60px' }}>Nr.</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333' }}>Name</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333' }}>Stage</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', width: '50%' }}>Purpose</TableCell>
                <TableCell sx={{ fontWeight: 'bold', color: '#333', textAlign: 'right' }}>Rating</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {topApplications.map((app, index) => (
                <TableRow 
                  key={app.id}
                  hover
                  onClick={() => navigate(`/applications/${app.id}`)}
                  sx={{ 
                    backgroundColor: index % 2 === 0 ? 'white' : '#f8f9fa',
                    cursor: 'pointer',
                    '&:hover': { 
                      backgroundColor: '#e0e0e0'
                    }
                  }}
                >
                  <TableCell>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                      {index + 1}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography
                      sx={{ 
                        color: '#1976d2',
                        fontWeight: 500,
                        '&:hover': { textDecoration: 'underline' }
                      }}
                    >
                      {app.name}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ color: '#666' }}>
                      {app.lifecycle}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ lineHeight: 1.4 }}>
                      {app.description}
                    </Typography>
                  </TableCell>
                  <TableCell sx={{ textAlign: 'right' }}>
                    {app.averageRatings && app.feedbackCount > 0 ? (
                      <Typography variant="body2" sx={{ color: '#666' }}>
                        {getRatingDisplay(app)}
                      </Typography>
                    ) : (
                      <Typography variant="body2" sx={{ color: '#999' }}>
                        No ratings
                      </Typography>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {topApplications.length === 0 && (
        <Box sx={{ textAlign: 'center', py: 6 }}>
          <Typography variant="h6" sx={{ color: '#666', mb: 2 }}>
            No verified applications found
          </Typography>
          <Typography variant="body2" sx={{ color: '#999' }}>
            No applications meet the minimum verification criteria yet.
          </Typography>
        </Box>
      )}
    </Container>
  )
}

export default MostVerified
