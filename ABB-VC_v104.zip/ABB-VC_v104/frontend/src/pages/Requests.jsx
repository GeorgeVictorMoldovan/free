import { useState, useEffect } from 'react'
import {
  Box,
  Container,
  Typography,
  TextField,
  InputAdornment,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableSortLabel,
  Paper,
  CircularProgress,
  Alert,
  Link,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
} from '@mui/material'
import {
  Search as SearchIcon,
  Add as AddIcon,
} from '@mui/icons-material'
import { apiService } from '../services/api'
import { useAuth } from '../contexts/AuthContext'
import { useNavigate } from 'react-router-dom'

function Requests() {
  const { user, hasPermission } = useAuth()
  const navigate = useNavigate()
  const [requests, setRequests] = useState([])
  const [applications, setApplications] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [open, setOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedFilter, setSelectedFilter] = useState('All')
  const [sortField, setSortField] = useState('requestedAt')
  const [sortDirection, setSortDirection] = useState('desc')
  const [stats, setStats] = useState({
    all: 0,
    pending: 0,
    approved: 0,
    rejected: 0,
    deleted: 0
  })
  const [newRequest, setNewRequest] = useState({
    type: 'reuse',
    applicationId: '',
    title: '',
    description: '',
    businessJustification: '',
    timeline: '',
    priority: 'medium'
  })

  useEffect(() => {
    fetchData()
  }, [user])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [requestsRes, appsRes] = await Promise.all([
        hasPermission('admin') ? apiService.getAllRequests() : apiService.getRequestsByUser(user?.id),
        apiService.getApplications()
      ])
      const requestData = requestsRes.data || requestsRes
      setRequests(requestData)
      setApplications(appsRes.data)
      
      // Calculate stats
      const newStats = {
        all: requestData.length,
        pending: requestData.filter(r => r.status === 'submitted').length,
        approved: requestData.filter(r => r.status === 'approved').length,
        rejected: requestData.filter(r => r.status === 'rejected').length,
        deleted: requestData.filter(r => r.status === 'deleted').length
      }
      setStats(newStats)
    } catch (err) {
      setError('Failed to load requests')
      console.error('Error fetching requests:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmitRequest = async () => {
    try {
      await apiService.submitRequest(newRequest)
      setOpen(false)
      setNewRequest({
        type: 'reuse',
        applicationId: '',
        title: '',
        description: '',
        businessJustification: '',
        timeline: '',
        priority: 'medium'
      })
      fetchData()
    } catch (err) {
      setError('Failed to submit request')
      console.error('Error submitting request:', err)
    }
  }

  // Filter requests based on search and status filter
  const filteredRequests = requests.filter(request => {
    const matchesSearch = !searchQuery || 
      request.requester?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.application?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.title.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesFilter = selectedFilter === 'All' || 
      (selectedFilter === 'Pending' && request.status === 'submitted') ||
      (selectedFilter === 'Approved' && request.status === 'approved') ||
      (selectedFilter === 'Rejected' && request.status === 'rejected') ||
      (selectedFilter === 'Deleted' && request.status === 'deleted')

    return matchesSearch && matchesFilter
  })

  const getTimeAgo = (dateString) => {
    const now = new Date()
    const date = new Date(dateString)
    const diffInMinutes = Math.floor((now - date) / (1000 * 60))
    
    if (diffInMinutes < 60) {
      const minutes = Math.max(1, diffInMinutes)
      return `${minutes} min`
    } else if (diffInMinutes < 1440) { // Less than 24 hours
      const hours = Math.floor(diffInMinutes / 60)
      return `${hours} hour${hours !== 1 ? 's' : ''}`
    } else if (diffInMinutes < 525600) { // Less than 365 days
      const days = Math.floor(diffInMinutes / 1440)
      return `${days} day${days !== 1 ? 's' : ''}`
    } else {
      const years = Math.floor(diffInMinutes / 525600)
      return `${years} Year${years !== 1 ? 's' : ''}`
    }
  }

  const handleSort = (field) => {
    const isAsc = sortField === field && sortDirection === 'asc'
    setSortDirection(isAsc ? 'desc' : 'asc')
    setSortField(field)
  }

  const sortedAndFilteredRequests = filteredRequests.sort((a, b) => {
    let aValue = a[sortField]
    let bValue = b[sortField]

    // Handle special cases
    if (sortField === 'requester') {
      aValue = a.requester?.name || ''
      bValue = b.requester?.name || ''
    } else if (sortField === 'application') {
      aValue = a.application?.name || ''
      bValue = b.application?.name || ''
    } else if (sortField === 'requestedAt') {
      aValue = new Date(a.requestedAt || 0)
      bValue = new Date(b.requestedAt || 0)
    }

    if (aValue < bValue) {
      return sortDirection === 'asc' ? -1 : 1
    }
    if (aValue > bValue) {
      return sortDirection === 'asc' ? 1 : -1
    }
    return 0
  })

  const filters = [
    { label: 'All', count: stats.all },
    { label: 'Pending', count: stats.pending },
    { label: 'Approved', count: stats.approved },
    { label: 'Rejected', count: stats.rejected },
    { label: 'Deleted', count: stats.deleted },
  ]

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress size={60} />
      </Box>
    )
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    )
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      {/* Breadcrumb Navigation */}
      <Box sx={{ mb: 3, textAlign: 'left' }}>
        <Typography variant="body1" sx={{ color: '#666' }}>
          <Link
            onClick={() => navigate('/')}
            sx={{ 
              color: '#1976d2',
              cursor: 'pointer',
              textDecoration: 'none',
              '&:hover': { textDecoration: 'underline' }
            }}
          >
            Home
          </Link>
          {' / Requests'}
        </Typography>
      </Box>

      {/* Header */}
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Typography variant="h3" sx={{ fontWeight: 'bold', color: '#333', mb: 4 }}>
          My Requests
        </Typography>
        
        <TextField
          fullWidth
          variant="outlined"
          placeholder="Search by app name, reason, or status"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          sx={{ 
            maxWidth: 600,
            '& .MuiOutlinedInput-root': {
              borderRadius: 3,
              backgroundColor: 'white',
              '& fieldset': {
                borderColor: '#e0e0e0',
              },
              '&:hover fieldset': {
                borderColor: '#424242',
              },
            }
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon color="action" />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      {/* Filter Pills */}
      <Box sx={{ mb: 4, display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
        <Typography variant="body2" sx={{ color: '#666', fontWeight: 500 }}>
          Filter by:
        </Typography>
        {filters.map((filter) => (
          <Chip
            key={filter.label}
            label={`${filter.label} (${filter.count})`}
            clickable
            variant={selectedFilter === filter.label ? 'filled' : 'outlined'}
            onClick={() => setSelectedFilter(filter.label)}
            sx={{
              borderRadius: 2,
              backgroundColor: selectedFilter === filter.label ? '#616161' : '#e0e0e0',
              color: selectedFilter === filter.label ? 'white' : '#666',
              borderColor: selectedFilter === filter.label ? '#616161' : '#bdbdbd',
              '&:hover': {
                backgroundColor: selectedFilter === filter.label ? '#424242' : '#f5f5f5',
                borderColor: '#9e9e9e'
              }
            }}
          />
        ))}
      </Box>

      {/* Requests Table */}
      <TableContainer component={Paper} sx={{ boxShadow: 3, borderRadius: 2 }}>
        <Table>
          <TableHead>
            <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
              <TableCell sx={{ fontWeight: 'bold' }}>
                <TableSortLabel
                  active={sortField === 'application'}
                  direction={sortField === 'application' ? sortDirection : 'asc'}
                  onClick={() => handleSort('application')}
                >
                  App Name
                </TableSortLabel>
              </TableCell>
              <TableCell sx={{ fontWeight: 'bold' }}>
                <TableSortLabel
                  active={sortField === 'description'}
                  direction={sortField === 'description' ? sortDirection : 'asc'}
                  onClick={() => handleSort('description')}
                >
                  Reason
                </TableSortLabel>
              </TableCell>
              <TableCell sx={{ fontWeight: 'bold' }}>
                <TableSortLabel
                  active={sortField === 'status'}
                  direction={sortField === 'status' ? sortDirection : 'asc'}
                  onClick={() => handleSort('status')}
                >
                  Status
                </TableSortLabel>
              </TableCell>
              <TableCell sx={{ fontWeight: 'bold' }}>
                <TableSortLabel
                  active={sortField === 'requestedAt'}
                  direction={sortField === 'requestedAt' ? sortDirection : 'asc'}
                  onClick={() => handleSort('requestedAt')}
                >
                  Age
                </TableSortLabel>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {sortedAndFilteredRequests.map((request, index) => (
              <TableRow 
                key={request.id}
                hover
                onClick={() => navigate(`/applications/${request.applicationId}`)}
                sx={{ 
                  backgroundColor: index % 2 === 0 ? 'white' : '#f8f9fa',
                  cursor: 'pointer',
                  '&:hover': { 
                    backgroundColor: '#e0e0e0'
                  }
                }}
              >
                <TableCell>
                  <Link
                    onClick={(e) => {
                      e.stopPropagation()
                      navigate(`/applications/${request.applicationId}`)
                    }}
                    sx={{ 
                      color: '#1976d2',
                      cursor: 'pointer',
                      textDecoration: 'none',
                      '&:hover': { textDecoration: 'underline' }
                    }}
                  >
                    {request.application?.name || 'Unknown App'}
                  </Link>
                </TableCell>
                <TableCell sx={{ color: '#666' }}>
                  <Typography variant="body2" sx={{ 
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                    maxWidth: '300px'
                  }}>
                    {request.description || request.title || 'No description'}
                  </Typography>
                </TableCell>
                <TableCell>
                  <Chip
                    label={request.status === 'submitted' ? 'Pending' : 
                           request.status === 'approved' ? 'Approved' :
                           request.status === 'rejected' ? 'Rejected' :
                           request.status === 'deleted' ? 'Deleted' :
                           request.status}
                    size="small"
                    sx={{
                      backgroundColor: '#e0e0e0',
                      color: '#666',
                      borderRadius: 2
                    }}
                  />
                </TableCell>
                <TableCell sx={{ color: '#666', fontSize: '0.875rem' }}>
                  {getTimeAgo(request.requestedAt)}
                </TableCell>
              </TableRow>
            ))}
            {sortedAndFilteredRequests.length === 0 && (
              <TableRow>
                <TableCell colSpan={4} align="center" sx={{ py: 8 }}>
                  <Typography variant="body1" color="text.secondary">
                    No requests found matching your criteria
                  </Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Submit Request Dialog */}
      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Submit Request</DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3, mt: 1 }}>
            Submit a request for application access, reuse, support, or other needs.
          </Typography>
          
          <TextField
            label="Request Title"
            fullWidth
            variant="outlined"
            value={newRequest.title}
            onChange={(e) =>
              setNewRequest({ ...newRequest, title: e.target.value })
            }
            sx={{ mb: 3 }}
            placeholder="Brief title for your request..."
            required
          />
          
          <FormControl fullWidth sx={{ mb: 3 }}>
            <InputLabel>Application to Reuse</InputLabel>
            <Select
              value={newRequest.applicationId}
              label="Application to Reuse"
              onChange={(e) =>
                setNewRequest({ ...newRequest, applicationId: e.target.value })
              }
            >
              {applications.filter(app => app.lifecycle !== 'Retired').map((app) => (
                <MenuItem key={app.id} value={app.id}>
                  {app.name} - {app.team} ({app.lifecycle})
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <TextField
            label="Description"
            multiline
            rows={3}
            fullWidth
            variant="outlined"
            value={newRequest.description}
            onChange={(e) =>
              setNewRequest({ ...newRequest, description: e.target.value })
            }
            sx={{ mb: 3 }}
            placeholder="Detailed description of your request..."
            required
          />

          <TextField
            label="Business Justification"
            multiline
            rows={3}
            fullWidth
            variant="outlined"
            value={newRequest.businessJustification}
            onChange={(e) =>
              setNewRequest({ ...newRequest, businessJustification: e.target.value })
            }
            sx={{ mb: 3 }}
            placeholder="Explain the business case and benefits of reusing this application..."
          />

          <TextField
            label="Timeline"
            fullWidth
            variant="outlined"
            value={newRequest.timeline}
            onChange={(e) =>
              setNewRequest({ ...newRequest, timeline: e.target.value })
            }
            placeholder="e.g., Q2 2024, By end of March, ASAP"
            helperText="When do you need to implement this reuse?"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button 
            onClick={handleSubmitRequest} 
            variant="contained"
            disabled={!newRequest.applicationId || !newRequest.title || !newRequest.description}
          >
            Submit Request
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  )
}

export default Requests
