import { useState, useEffect } from 'react'
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  CircularProgress,
  Alert,
} from '@mui/material'
import {
  Apps as AppsIcon,
  Feedback as FeedbackIcon,
  Pending as PendingIcon,
  CheckCircle as ProductionIcon,
  Build as DevelopmentIcon,
  BugReport as TestingIcon,
} from '@mui/icons-material'
import { apiService } from '../services/api'

function Dashboard() {
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true)
        const response = await apiService.getStats()
        setStats(response.data)
      } catch (err) {
        setError('Failed to load dashboard stats')
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [])

  const statCards = [
    {
      title: 'Total Applications',
      value: stats?.totalApplications || 0,
      icon: <AppsIcon fontSize="large" />,
      color: '#1976d2',
      subtitle: 'In portfolio',
    },
    {
      title: 'Production Apps',
      value: stats?.lifecycleStats?.production || 0,
      icon: <ProductionIcon fontSize="large" />,
      color: '#2e7d32',
      subtitle: 'Live systems',
    },
    {
      title: 'In Development',
      value: (stats?.lifecycleStats?.development || 0) + (stats?.lifecycleStats?.testing || 0),
      icon: <DevelopmentIcon fontSize="large" />,
      color: '#ed6c02',
      subtitle: 'Active projects',
    },
    {
      title: 'Feedback Items',
      value: stats?.totalFeedback || 0,
      icon: <FeedbackIcon fontSize="large" />,
      color: '#7b1fa2',
      subtitle: `Avg: ${stats?.averageRating?.usability || 0}/5`,
    },
  ]

  const lifecycleCards = [
    {
      title: 'Planning',
      value: stats?.lifecycleStats?.planning || 0,
      color: '#9e9e9e',
    },
    {
      title: 'Development', 
      value: stats?.lifecycleStats?.development || 0,
      color: '#ff9800',
    },
    {
      title: 'Testing',
      value: stats?.lifecycleStats?.testing || 0,
      color: '#2196f3',
    },
    {
      title: 'Production',
      value: stats?.lifecycleStats?.production || 0,
      color: '#4caf50',
    },
    {
      title: 'Maintenance',
      value: stats?.lifecycleStats?.maintenance || 0,
      color: '#ff5722',
    },
    {
      title: 'Retired',
      value: stats?.lifecycleStats?.retired || 0,
      color: '#607d8b',
    },
  ]

  if (loading) {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: 400,
        }}
      >
        <CircularProgress size={60} />
      </Box>
    )
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    )
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" sx={{ mb: 3, fontWeight: 'bold' }}>
        Application Lifecycle Dashboard
      </Typography>

      {/* Main Stats Cards */}
      <Grid container spacing={3}>
        {statCards.map((card, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <Card
              sx={{
                height: '100%',
                background: `linear-gradient(135deg, ${card.color}20, ${card.color}10)`,
                border: `2px solid ${card.color}20`,
                transition: 'transform 0.2s, box-shadow 0.2s',
                '&:hover': {
                  transform: 'translateY(-4px)',
                  boxShadow: `0 8px 25px ${card.color}30`,
                },
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    mb: 2,
                  }}
                >
                  <Box sx={{ color: card.color }}>
                    {card.icon}
                  </Box>
                  <Typography
                    variant="h4"
                    sx={{ fontWeight: 'bold', color: card.color }}
                  >
                    {card.value}
                  </Typography>
                </Box>
                <Typography variant="h6" sx={{ mb: 1, fontWeight: 'medium' }}>
                  {card.title}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {card.subtitle}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Lifecycle Breakdown */}
      <Grid container spacing={3} sx={{ mt: 2 }}>
        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" sx={{ mb: 3, fontWeight: 'bold' }}>
              Application Lifecycle Breakdown
            </Typography>
            <Grid container spacing={2}>
              {lifecycleCards.map((lifecycle, index) => (
                <Grid item xs={12} sm={6} md={2} key={index}>
                  <Box
                    sx={{
                      p: 2,
                      borderRadius: 2,
                      backgroundColor: `${lifecycle.color}10`,
                      border: `2px solid ${lifecycle.color}20`,
                      textAlign: 'center',
                    }}
                  >
                    <Typography
                      variant="h4"
                      sx={{ fontWeight: 'bold', color: lifecycle.color, mb: 1 }}
                    >
                      {lifecycle.value}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {lifecycle.title}
                    </Typography>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </Paper>
        </Grid>
      </Grid>

      {/* Quick Actions */}
      <Grid container spacing={3} sx={{ mt: 2 }}>
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
              Portal Overview
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 2 }}>
              Welcome to the Internal Application Lifecycle Portal! Track, manage, and discover applications across your organization.
            </Typography>
            <Box sx={{ mt: 2 }}>
              <Typography variant="body2" sx={{ mb: 1 }}>
                • <strong>App Inventory:</strong> Browse and search the complete application catalog
              </Typography>
              <Typography variant="body2" sx={{ mb: 1 }}>
                • <strong>Feedback Hub:</strong> Review ratings and feedback for applications
              </Typography>
              <Typography variant="body2" sx={{ mb: 1 }}>
                • <strong>Reuse Requests:</strong> Submit and track requests to reuse existing applications
              </Typography>
              <Typography variant="body2">
                • <strong>Admin Panel:</strong> Manage approvals and application lifecycle transitions
              </Typography>
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
              Pending Actions
            </Typography>
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" color="text.secondary">
                Pending Approvals
              </Typography>
              <Typography variant="h5" sx={{ color: '#ff9800', fontWeight: 'bold' }}>
                {stats?.pendingApprovals || 0}
              </Typography>
            </Box>
            <Box>
              <Typography variant="body2" color="text.secondary">
                Pending Reuse Requests
              </Typography>
              <Typography variant="h5" sx={{ color: '#2196f3', fontWeight: 'bold' }}>
                {stats?.pendingRequests || 0}
              </Typography>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  )
}

export default Dashboard
