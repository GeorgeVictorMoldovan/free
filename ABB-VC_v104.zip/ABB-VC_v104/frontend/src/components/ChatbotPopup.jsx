import React, { useState, useRef, useEffect } from 'react'
import {
  IconButton,
  TextField,
  Button,
  Typography,
  Card,
  CardContent,
  Chip,
  Box,
  Paper,
  Avatar,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemButton,
  CircularProgress,
  Slide
} from '@mui/material'
import {
  Close as CloseIcon,
  Send as SendIcon,
  SmartToy as BotIcon,
  Person as UserIcon,
  Search as SearchIcon,
  AddBox as AddIcon,
  NoteAdd as NeedIcon
} from '@mui/icons-material'
import { useNavigate } from 'react-router-dom'
import { apiService } from '../services/api'

const ChatbotPopup = ({ open, onClose }) => {
  const [messages, setMessages] = useState([])
  const [inputValue, setInputValue] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [applications, setApplications] = useState([])
  const [currentStep, setCurrentStep] = useState('need') // need, search, evaluate, request
  const [searchResults, setSearchResults] = useState([])
  const navigate = useNavigate()
  const messagesEndRef = useRef(null)

  useEffect(() => {
    if (open) {
      initializeChatbot()
      loadApplications()
    }
  }, [open])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const initializeChatbot = () => {
    const baseTime = Date.now()
    const welcomeMessages = [
      "Hey there! I'm Abby, your friendly app discovery assistant. I'm here to help you find exactly what you need!",
      "Hi! I'm Abby, and I love helping people discover the perfect tools for their work. What's on your mind today?",
      "Hello! I'm Abby, your go-to person for finding apps that'll make your life easier. What can I help you with?"
    ]
    
    const exampleMessages = [
      "Feel free to describe what you need in your own words - like 'I'm drowning in incident reports' or 'Our vendor approval process is a nightmare!' I'll help you find something that fits.",
      "Just tell me what's bugging you at work - maybe 'I need to track bugs better' or 'Our team needs a better way to collaborate.' I'm here to listen and help!",
      "Don't worry about using fancy tech terms! Just say something like 'I'm tired of manual reporting' or 'We need something for project tracking.' I speak human, not robot!"
    ]
    
    const randomWelcome = welcomeMessages[Math.floor(Math.random() * welcomeMessages.length)]
    const randomExample = exampleMessages[Math.floor(Math.random() * exampleMessages.length)]
    
    setMessages([
      {
        id: `${baseTime}-welcome`,
        sender: 'bot',
        text: randomWelcome,
        timestamp: new Date()
      },
      {
        id: `${baseTime}-examples`,
        sender: 'bot',
        text: randomExample,
        timestamp: new Date()
      }
    ])
    setCurrentStep('need')
    setInputValue('')
    setSearchResults([])
  }

  const loadApplications = async () => {
    try {
      const response = await apiService.getApplications()
      setApplications(response.data || [])
    } catch (error) {
      // Silently handle error
    }
  }

  const addMessage = (sender, text, data = null) => {
    const newMessage = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`, // Unique ID with timestamp + random
      sender,
      text,
      data,
      timestamp: new Date()
    }
    setMessages(prev => [...prev, newMessage])
  }

  const generateNoResultsMessage = (userQuery, isRefinedSearch = false) => {
    // Extract key terms from user query for contextual response
    const query = userQuery.toLowerCase()
    
    // Detect specific categories the user might be looking for
    const categories = {
      design: ['logo', 'design', 'graphic', 'creative', 'visual', 'branding', 'ui', 'ux'],
      communication: ['chat', 'messaging', 'email', 'communication', 'slack', 'teams'],
      media: ['video', 'audio', 'photo', 'image', 'media', 'editing'],
      sales: ['crm', 'sales', 'customer', 'leads', 'pipeline'],
      marketing: ['marketing', 'campaign', 'social', 'advertising'],
      finance: ['accounting', 'payroll', 'expense', 'budget', 'invoice'],
      hr: ['recruitment', 'hiring', 'onboarding', 'employee', 'hr'],
      productivity: ['notes', 'todo', 'calendar', 'scheduling', 'time'],
      collaboration: ['project', 'team', 'collaboration', 'wiki', 'knowledge']
    }
    
    // Find what category the user is looking for
    let detectedCategory = null
    let categoryName = null
    
    for (const [category, keywords] of Object.entries(categories)) {
      if (keywords.some(keyword => query.includes(keyword))) {
        detectedCategory = category
        categoryName = category.charAt(0).toUpperCase() + category.slice(1)
        break
      }
    }
    
    // Available categories in our database
    const availableCategories = [
      "Development & DevOps tools (deployment, CI/CD, code management)",
      "Data & Analytics (logging, metrics, database tools)", 
      "IT Operations (monitoring, incident tracking, security)",
      "Business Process (workflow, automation, documentation)",
      "Productivity (meeting tools, time tracking, file management)"
    ]
    
    if (detectedCategory) {
      if (isRefinedSearch) {
        return `I'm still not finding ${categoryName.toLowerCase()} applications in our current catalog. Our portal focuses on internal business and IT tools rather than ${categoryName.toLowerCase()} software. Here's what I can help you with instead:`
      } else {
        return `I don't see any ${categoryName.toLowerCase()} applications in our current catalog. Our internal app portal focuses mainly on business and IT tools. The types of apps I can help you find include: ${availableCategories.slice(0, 3).join(', ')}. Would any of these be helpful, or would you like to request a new app?`
      }
    }
    
    // Generic contextual message
    const genericMessages = [
      `I couldn't find apps matching "${userQuery}" in our current catalog. Our portal specializes in internal business and IT tools. Here's what I can do to help:`,
      `No matches for "${userQuery}" in our available applications. Our catalog focuses on workplace productivity and IT solutions. Let me show you some alternatives:`,
      `I'm not seeing anything for "${userQuery}" right now. Our app collection centers around business process and development tools. Here are your options:`
    ]
    
    if (isRefinedSearch) {
      return `Still no luck finding something that matches "${userQuery}" exactly. This might mean you need something quite specific! Here's how I can help:`
    }
    
    return genericMessages[Math.floor(Math.random() * genericMessages.length)]
  }

  const searchApplications = (query) => {
    console.log('Search query:', query) // Debug
    
    // Comprehensive stop words list - exclude all filler words and focus on domain terms
    const stopWords = [
      // Pronouns
      'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your', 'yours', 
      'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', 'her', 'hers', 
      'herself', 'it', 'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves',
      
      // Question words
      'what', 'which', 'who', 'whom', 'this', 'that', 'these', 'those', 'when', 'where', 'why', 'how',
      
      // Verbs
      'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 
      'do', 'does', 'did', 'doing', 'can', 'will', 'would', 'could', 'should', 'may', 'might', 'must',
      
      // Articles & Prepositions  
      'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 
      'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 'during', 'before', 
      'after', 'above', 'below', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under',
      
      // Adverbs & Adjectives
      'again', 'further', 'then', 'once', 'here', 'there', 'all', 'any', 'both', 'each', 
      'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 
      'same', 'so', 'than', 'too', 'very', 'just', 'now',
      
      // App/Software generic terms (as requested by user)
      'app', 'apps', 'application', 'applications', 'tool', 'tools', 'system', 'systems', 
      'software', 'program', 'platform', 'service', 'solution', 'product',
      
      // Action/Helper words
      'need', 'want', 'help', 'find', 'looking', 'search', 'get', 'use', 'work', 'make',
      'create', 'build', 'develop', 'manage', 'handle', 'deal', 'something', 'anything'
    ]
    
    const searchTerms = query.toLowerCase().split(' ')
      .filter(term => term.length >= 2 && !stopWords.includes(term))  // Accept 2+ characters if not stop word
      .filter(term => /^[a-zA-Z]+$/.test(term)) // Only letters, no punctuation
    
    console.log('Filtered search terms:', searchTerms) // Debug
    
    // If no meaningful terms remain, return no results
    if (searchTerms.length === 0) {
      console.log('No meaningful search terms found') // Debug
      return []
    }
    
    const results = []
    const MINIMUM_RELEVANCE_SCORE = 5 // Increased minimum score

    applications.forEach(app => {
      let score = 0
      let hasStrongMatch = false
      let matchedTermsCount = 0
      
      // Include name, description (purpose), and tags in search
      const tagsText = Array.isArray(app.tags) ? app.tags.join(' ') : ''
      const searchableText = `${app.name} ${app.description} ${tagsText}`.toLowerCase()

      searchTerms.forEach(term => {
        let termMatched = false
        
        if (app.name.toLowerCase().includes(term)) {
          console.log(`Strong match in name: ${app.name} contains "${term}"`) // Debug
          score += 10 // Highest score for name matches
          hasStrongMatch = true
          termMatched = true
        } else if (app.description.toLowerCase().includes(term)) {
          console.log(`Strong match in description/purpose: ${app.name} description contains "${term}"`) // Debug
          score += 8 // High score for description/purpose matches
          hasStrongMatch = true
          termMatched = true
        } else if (app.tags && app.tags.some(tag => tag.toLowerCase().includes(term))) {
          console.log(`Strong match in tags: ${app.name} tags contain "${term}"`) // Debug
          score += 6 // Medium-high score for tag matches
          hasStrongMatch = true
          termMatched = true
        }
        
        if (termMatched) {
          matchedTermsCount++
        }
      })

      // For multi-word queries, require matching multiple terms OR very high single-term relevance
      const requiresMultipleTerms = searchTerms.length > 1
      const hasMultipleTermMatches = matchedTermsCount > 1
      const hasVeryHighScore = score >= 10 // Name match or very relevant

      const shouldInclude = hasStrongMatch && score >= MINIMUM_RELEVANCE_SCORE && 
        (!requiresMultipleTerms || hasMultipleTermMatches || hasVeryHighScore)

      if (shouldInclude) {
        console.log(`Including app: ${app.name} with score ${score}, matched ${matchedTermsCount}/${searchTerms.length} terms`) // Debug
        results.push({ ...app, relevanceScore: score })
      } else if (score > 0) {
        console.log(`Excluding app: ${app.name} with score ${score}, matched ${matchedTermsCount}/${searchTerms.length} terms`) // Debug
      }
    })

    const finalResults = results.sort((a, b) => b.relevanceScore - a.relevanceScore).slice(0, 5)
    console.log('Final results:', finalResults) // Debug
    return finalResults
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return

    const userMessage = inputValue.trim()
    addMessage('user', userMessage)
    setInputValue('')
    setIsLoading(true)

    try {
      if (currentStep === 'need') {
        // Search for matching applications
        const results = searchApplications(userMessage)
        setSearchResults(results)

        if (results.length > 0) {
          const successMessages = [
            `Awesome! I found ${results.length} app${results.length > 1 ? 's' : ''} that might be exactly what you need. Check these out:`,
            `Great news! I discovered ${results.length} promising option${results.length > 1 ? 's' : ''} for you. Let's see if any of these hit the mark:`,
            `Perfect! I've got ${results.length} solid suggestion${results.length > 1 ? 's' : ''} that could solve your problem. Take a peek:`,
            `Brilliant! Found ${results.length} app${results.length > 1 ? 's' : ''} that look like they could be game-changers for you:`
          ]
          
          const followUpMessages = [
            "Click on any that catch your eye for the full details, or just let me know if I'm on the right track!",
            "Feel free to click through these - and don't worry if none are quite right, we can keep looking together!",
            "Take your time browsing these. If nothing feels perfect, just say the word and I'll dig deeper!",
            "Have a look through these options. If they're not hitting the sweet spot, I've got more tricks up my sleeve!"
          ]
          
          const randomSuccess = successMessages[Math.floor(Math.random() * successMessages.length)]
          const randomFollowUp = followUpMessages[Math.floor(Math.random() * followUpMessages.length)]
          
          addMessage('bot', randomSuccess)
          addMessage('bot', '', { type: 'search-results', results })
          addMessage('bot', randomFollowUp)
          setCurrentStep('evaluate')
        } else {
          // Generate a more contextual no-results message
          const contextualMessage = generateNoResultsMessage(userMessage)
          addMessage('bot', contextualMessage)
          addMessage('bot', '', { type: 'fallback-options' })
          setCurrentStep('request')
        }
      } else if (currentStep === 'evaluate') {
        // Handle follow-up questions with empathy
        if (userMessage.toLowerCase().includes("couldn't find") || 
            userMessage.toLowerCase().includes("not what") || 
            userMessage.toLowerCase().includes("none of these") ||
            userMessage.toLowerCase().includes("not quite") ||
            userMessage.toLowerCase().includes("close but")) {
          const empathyMessages = [
            "No worries at all! Sometimes it takes a few tries to find the perfect match. Let's explore some other avenues:",
            "Totally get that! Finding the right tool is like finding the right pair of shoes - it has to fit just right. Here's what we can do:",
            "I hear you! Sometimes the first search doesn't nail it completely. Good thing I've got more ideas up my sleeve:",
            "Fair enough! It's better to be picky and find something that really works for you. Let's try a different approach:"
          ]
          
          const randomEmpathy = empathyMessages[Math.floor(Math.random() * empathyMessages.length)]
          addMessage('bot', randomEmpathy)
          addMessage('bot', '', { type: 'fallback-options' })
          setCurrentStep('request')
        } else {
          // Treat any other response as a new search query
          const results = searchApplications(userMessage)
          setSearchResults(results)

          if (results.length > 0) {
            const refinedSearchMessages = [
              `Oh, interesting! With that new info, I found ${results.length} different option${results.length > 1 ? 's' : ''} that might be more on target:`,
              `Aha! That helps narrow it down. Here are ${results.length} app${results.length > 1 ? 's' : ''} that better match what you're after:`,
              `Got it! Let me show you ${results.length} app${results.length > 1 ? 's' : ''} that might be more your speed:`,
              `Perfect clarification! I've got ${results.length} better match${results.length > 1 ? 'es' : ''} for you now:`
            ]
            
            const randomRefined = refinedSearchMessages[Math.floor(Math.random() * refinedSearchMessages.length)]
            addMessage('bot', randomRefined)
            addMessage('bot', '', { type: 'search-results', results })
            addMessage('bot', "How do these look? Getting warmer?")
            // Stay in evaluate step
          } else {
            const contextualMessage = generateNoResultsMessage(userMessage, true)
            addMessage('bot', contextualMessage)
            addMessage('bot', '', { type: 'fallback-options' })
            setCurrentStep('request')
          }
        }
      } else if (currentStep === 'request') {
        // Reset to start a new search with enthusiasm
        const restartMessages = [
          "Alright, let's start fresh! What's the next challenge you're trying to tackle?",
          "Sure thing! I'm all ears - what other work headaches can I help solve for you?",
          "Absolutely! Let's dive into something new. What else is on your wishlist?",
          "You got it! I'm ready for round two. What's the next puzzle we're solving together?"
        ]
        
        const randomRestart = restartMessages[Math.floor(Math.random() * restartMessages.length)]
        addMessage('bot', randomRestart)
        setCurrentStep('need')
      }
    } catch (error) {
      const errorMessages = [
        "Oops! Something went a bit wonky on my end. Mind giving that another shot?",
        "Uh oh! I seem to have hit a snag. Let's try that again, shall we?",
        "Sorry about that! I got a bit tangled up there. Could you give it another go?",
        "Whoops! Technical hiccup on my side. Let's try once more!"
      ]
      
      const randomError = errorMessages[Math.floor(Math.random() * errorMessages.length)]
      addMessage('bot', randomError)
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyPress = (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault()
      handleSendMessage()
    }
  }

  const handleAppClick = (appId) => {
    navigate(`/applications/${appId}`)
    onClose()
  }

  const handleSubmitNeed = () => {
    navigate('/requests')
    onClose()
  }

  const handleSuggestApp = () => {
    navigate('/settings')
    onClose()
  }

  const getLifecycleColor = (lifecycle) => {
    switch (lifecycle?.toLowerCase()) {
      case 'active': return '#4caf50'
      case 'pilot': return '#ff9800'  
      case 'in dev': return '#2196f3'
      case 'maintenance': return '#9c27b0'
      case 'retiring': return '#f44336'
      case 'deprecated': return '#757575'
      default: return '#666'
    }
  }

  const renderMessage = (message) => {
    const isBot = message.sender === 'bot'

    return (
      <Box key={message.id} sx={{ mb: 2, display: 'flex', flexDirection: isBot ? 'row' : 'row-reverse' }}>
        <Avatar sx={{ 
          bgcolor: isBot ? '#1976d2' : '#666', 
          mr: isBot ? 1 : 0, 
          ml: isBot ? 0 : 1, 
          width: 32, 
          height: 32 
        }}>
          {isBot ? <BotIcon sx={{ fontSize: 18 }} /> : <UserIcon sx={{ fontSize: 18 }} />}
        </Avatar>
        
        <Paper sx={{
          p: 2,
          maxWidth: '75%',
          bgcolor: isBot ? '#f5f5f5' : '#1976d2',
          color: isBot ? '#000' : '#fff',
          borderRadius: isBot ? '18px 18px 18px 4px' : '18px 18px 4px 18px'
        }}>
          {message.text && (
            <Typography variant="body2" sx={{ mb: message.data ? 1 : 0 }}>
              {message.text}
            </Typography>
          )}

          {/* Search Results */}
          {message.data?.type === 'search-results' && (
            <Box sx={{ mt: 1 }}>
              {message.data.results.map(app => (
                <Card 
                  key={app.id} 
                  sx={{ mb: 1, cursor: 'pointer', '&:hover': { bgcolor: '#e3f2fd' } }}
                  onClick={() => handleAppClick(app.id)}
                >
                  <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}>
                      <Typography variant="subtitle2" sx={{ fontWeight: 'bold', color: '#1976d2' }}>
                        {app.name}
                      </Typography>
                      <Chip 
                        label={app.lifecycle} 
                        size="small"
                        sx={{ 
                          bgcolor: getLifecycleColor(app.lifecycle),
                          color: 'white',
                          fontSize: '10px',
                          height: 20
                        }}
                      />
                    </Box>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 1, fontSize: '12px' }}>
                      {app.description}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      Team: {app.team} | Owner: {app.owner}
                    </Typography>
                  </CardContent>
                </Card>
              ))}
            </Box>
          )}

          {/* Fallback Options */}
          {message.data?.type === 'fallback-options' && (
            <Box sx={{ p: 3 }}>
              <Typography variant="body2" sx={{ mb: 2, color: '#666', fontSize: '0.9rem' }}>
                Available app categories:
              </Typography>
              <Box sx={{ mb: 3 }}>
                {[
                  "Development & DevOps tools",
                  "Data & Analytics platforms", 
                  "IT Operations & Security",
                  "Business Process automation",
                  "Productivity & Collaboration"
                ].map((category, index) => (
                  <Chip 
                    key={index}
                    label={category}
                    size="small"
                    sx={{ 
                      mr: 1, 
                      mb: 1, 
                      bgcolor: '#f0f7ff', 
                      color: '#1976d2',
                      fontSize: '0.75rem'
                    }}
                  />
                ))}
              </Box>
              
              <Typography variant="body2" sx={{ mb: 3, color: '#666' }}>
                Or help us expand our catalog:
              </Typography>
              
              <Button
                variant="outlined"
                startIcon={<NeedIcon />}
                onClick={handleSubmitNeed}
                size="small"
                sx={{ mb: 1, mr: 2, minWidth: '180px' }}
              >
                Request new app
              </Button>
              
              <Button
                variant="outlined"
                startIcon={<AddIcon />}
                onClick={handleSuggestApp}
                size="small"
                sx={{ mb: 1, minWidth: '180px' }}
              >
                Suggest an app
              </Button>
            </Box>
          )}
        </Paper>
      </Box>
    )
  }

  return (
    <Slide direction="up" in={open} mountOnEnter unmountOnExit>
      <Paper
        sx={{
          position: 'fixed',
          bottom: 100, // Above the chat button
          right: 24,
          width: 400,
          height: 600,
          display: 'flex',
          flexDirection: 'column',
          borderRadius: '12px',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.12)',
          zIndex: 1300,
          overflow: 'hidden'
        }}
      >
        {/* Header */}
        <Box sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'space-between',
          bgcolor: '#1976d2',
          color: 'white',
          p: 2
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <BotIcon sx={{ mr: 1 }} />
            <Typography variant="h6" sx={{ fontSize: '1rem' }}>Abby - Your App Discovery Buddy</Typography>
          </Box>
          <IconButton onClick={onClose} sx={{ color: 'white' }} size="small">
            <CloseIcon />
          </IconButton>
        </Box>

        {/* Messages Area */}
        <Box sx={{ 
          flex: 1, 
          overflowY: 'auto', 
          p: 2,
          bgcolor: '#fafafa'
        }}>
          {messages.map(renderMessage)}
          {isLoading && (
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Avatar sx={{ bgcolor: '#1976d2', mr: 1, width: 32, height: 32 }}>
                <BotIcon sx={{ fontSize: 18 }} />
              </Avatar>
              <Paper sx={{ p: 2, bgcolor: '#f5f5f5', borderRadius: '18px 18px 18px 4px' }}>
                <CircularProgress size={16} sx={{ mr: 1 }} />
                <Typography variant="body2" component="span">Let me think...</Typography>
              </Paper>
            </Box>
          )}
          <div ref={messagesEndRef} />
        </Box>

        <Divider />

        {/* Input Area */}
        <Box sx={{ p: 2, display: 'flex', alignItems: 'center', bgcolor: 'white' }}>
          <TextField
            fullWidth
            multiline
            maxRows={3}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Just tell me what's bugging you at work..."
            disabled={isLoading}
            variant="outlined"
            size="small"
            sx={{ mr: 1 }}
          />
          <IconButton 
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || isLoading}
            color="primary"
          >
            <SendIcon />
          </IconButton>
        </Box>
      </Paper>
    </Slide>
  )
}

export default ChatbotPopup
