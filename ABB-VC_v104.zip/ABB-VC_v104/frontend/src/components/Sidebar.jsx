import {
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Divider,
} from '@mui/material'
import {
  Dashboard as DashboardIcon,
  Apps as AppsIcon,
  Feedback as FeedbackIcon,
  AdminPanelSettings as AdminIcon,
  Search as SearchIcon,
  Inbox as InboxIcon,
  Settings as SettingsIcon,
} from '@mui/icons-material'
import { useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'

const drawerWidth = 240

function Sidebar() {
  const navigate = useNavigate()
  const location = useLocation()
  const { hasPermission } = useAuth()

  const handleNavigation = (path) => {
    navigate(path)
  }

  // Dynamic menu items based on user permissions
  const menuItems = [
    { text: 'Find an App', icon: <SearchIcon />, path: '/' },
    // Show Requests Inbox as second item for admins
    ...(hasPermission('admin') ? [
      { text: 'Requests Inbox', icon: <InboxIcon />, path: '/requests-inbox' }
    ] : []),
    { text: 'Dashboard', icon: <DashboardIcon />, path: '/dashboard' },
    { text: 'App Inventory', icon: <AppsIcon />, path: '/applications' },
    { text: 'Feedback Hub', icon: <FeedbackIcon />, path: '/feedback' },
    { text: 'Reuse Requests', icon: <SearchIcon />, path: '/requests' },
    // Admin-only items
    ...(hasPermission('admin') ? [
      { text: 'Settings', icon: <SettingsIcon />, path: '/settings' }
    ] : []),
    // Only show Admin Panel to users with approval permission
    ...(hasPermission('approve') ? [
      { text: 'Admin Panel', icon: <AdminIcon />, path: '/admin' }
    ] : [])
  ]

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: drawerWidth,
        flexShrink: 0,
        [`& .MuiDrawer-paper`]: {
          width: drawerWidth,
          boxSizing: 'border-box',
          backgroundColor: '#f8f9fa',
          borderRight: '1px solid #e0e0e0',
        },
      }}
    >
      <Toolbar />
      <Divider />
      <List>
        {menuItems.map((item) => (
          <ListItem key={item.text} disablePadding>
            <ListItemButton
              onClick={() => handleNavigation(item.path)}
              selected={location.pathname === item.path}
              sx={{
                '&.Mui-selected': {
                  backgroundColor: '#f5f5f5',
                  color: '#424242',
                  '& .MuiListItemIcon-root': {
                    color: '#424242',
                  },
                },
                '&:hover': {
                  backgroundColor: '#f0f0f0',
                },
              }}
            >
              <ListItemIcon>{item.icon}</ListItemIcon>
              <ListItemText primary={item.text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Drawer>
  )
}

export default Sidebar
