import React, { useState } from 'react'
import { Fab, Badge, Tooltip, Zoom } from '@mui/material'
import { SmartToy as BotIcon, Close as CloseIcon } from '@mui/icons-material'
import ChatbotPopup from './ChatbotPopup'

const ChatbotButton = () => {
  const [chatbotOpen, setChatbotOpen] = useState(false)
  const [hasNewMessage, setHasNewMessage] = useState(true) // Can be used for notifications

  const handleToggleChatbot = () => {
    setChatbotOpen(!chatbotOpen)
    if (hasNewMessage) {
      setHasNewMessage(false)
    }
  }

  return (
    <>
      {/* Floating Action Button */}
      <Zoom in={true}>
        <Tooltip title={chatbotOpen ? "Close chat with Abby" : "Hey! Need help finding an app? Chat with Abby!"} placement="left">
          <Fab
            color="primary"
            onClick={handleToggleChatbot}
            sx={{
              position: 'fixed',
              bottom: 24,
              right: 24,
              zIndex: 1300,
              width: 64,
              height: 64,
              transition: 'all 0.3s ease',
              transform: chatbotOpen ? 'rotate(180deg)' : 'rotate(0deg)',
              '&:hover': {
                transform: chatbotOpen ? 'rotate(180deg) scale(1.1)' : 'scale(1.1)',
                boxShadow: '0 8px 25px rgba(25, 118, 210, 0.3)'
              }
            }}
          >
            <Badge 
              badgeContent={hasNewMessage && !chatbotOpen ? "!" : 0}
              color="error"
              sx={{
                '& .MuiBadge-badge': {
                  fontSize: '12px',
                  minWidth: '18px',
                  height: '18px'
                }
              }}
            >
              {chatbotOpen ? <CloseIcon /> : <BotIcon />}
            </Badge>
          </Fab>
        </Tooltip>
      </Zoom>

      {/* Chatbot Popup */}
      <ChatbotPopup 
        open={chatbotOpen} 
        onClose={() => setChatbotOpen(false)}
      />
    </>
  )
}

export default ChatbotButton
