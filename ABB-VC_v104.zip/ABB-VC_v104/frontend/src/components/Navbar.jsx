import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Badge,
  Menu,
  MenuItem,
  Avatar,
  Box,
} from '@mui/material'
import {
  Notifications as NotificationsIcon,
  AccountCircle,
  Settings as SettingsIcon,
  Logout as LogoutIcon,
  AdminPanelSettings as AdminIcon,
} from '@mui/icons-material'
import { useState, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { useRequestsContext } from '../contexts/RequestsContext'
import { useNavigate } from 'react-router-dom'
import { apiService } from '../services/api'

function Navbar() {
  const [anchorEl, setAnchorEl] = useState(null)
  const { user, logout, isAdmin, hasPermission } = useAuth()
  const { unreadCount, refreshUnreadCount, markRequestsAsViewed } = useRequestsContext()
  const navigate = useNavigate()

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const handleLogout = () => {
    logout()
    handleClose()
  }

  const handleRequestsClick = async () => {
    if (hasPermission('admin')) {
      navigate('/requests-inbox')
    } else {
      // Mark user's requests as viewed when they click
      await markRequestsAsViewed()
      navigate('/requests')
    }
  }

  useEffect(() => {
    if (hasPermission && (hasPermission('admin') || user)) {
      refreshUnreadCount(hasPermission, user)
    }
  }, [user, hasPermission, refreshUnreadCount])

  return (
    <AppBar
      position="fixed"
      sx={{
        zIndex: (theme) => theme.zIndex.drawer + 1,
        backgroundColor: '#424242',
      }}
    >
      <Toolbar>
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          Application Lifecycle Portal
        </Typography>


        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          {/* Requests Notification */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mr: 2, position: 'relative' }}>
            <Typography 
              variant="body2" 
              onClick={handleRequestsClick}
              sx={{ 
                color: 'rgba(255, 255, 255, 0.9)',
                cursor: 'pointer',
                '&:hover': { color: 'white' }
              }}
            >
              {hasPermission('admin') 
                ? 'Request Inbox' 
                : `My requests${unreadCount > 0 ? ` (${unreadCount} new)` : ''}`
              }
            </Typography>
            {hasPermission('admin') && unreadCount > 0 && (
              <Badge 
                badgeContent={unreadCount} 
                sx={{
                  position: 'absolute',
                  top: -8,
                  right: -12,
                  '& .MuiBadge-badge': {
                    backgroundColor: '#d32f2f',
                    color: 'white',
                    fontSize: '10px',
                    fontWeight: 'bold',
                    height: '16px',
                    minWidth: '16px',
                    borderRadius: '8px'
                  }
                }}
              />
            )}
          </Box>


          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Typography variant="body2" sx={{ display: { xs: 'none', sm: 'block' } }}>
              {user?.name}
            </Typography>
            <IconButton
              size="large"
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleMenu}
              color="inherit"
            >
              <Avatar src={user?.avatar} sx={{ width: 32, height: 32 }}>
                {isAdmin() ? <AdminIcon /> : <AccountCircle />}
              </Avatar>
            </IconButton>
          </Box>

          <Menu
            id="menu-appbar"
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            keepMounted
            transformOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            <MenuItem disabled>
              <Box>
                <Typography variant="body2">{user?.name}</Typography>
                <Typography variant="caption" color="text.secondary">
                  {user?.role === 'admin' ? 'Catalog Admin' : 'Requester'} • {user?.department}
                </Typography>
              </Box>
            </MenuItem>
            <MenuItem onClick={handleClose}>
              <AccountCircle sx={{ mr: 1 }} />
              Profile
            </MenuItem>
            <MenuItem onClick={handleLogout}>
              <LogoutIcon sx={{ mr: 1 }} />
              Logout
            </MenuItem>
          </Menu>
        </Box>
      </Toolbar>
    </AppBar>
  )
}

export default Navbar
