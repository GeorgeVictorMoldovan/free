import { useState } from 'react'
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  TextField,
  Button,
  Box,
  Rating,
  IconButton,
} from '@mui/material'
import {
  Star as StarIcon,
  StarBorder as StarBorderIcon,
  Close as CloseIcon,
} from '@mui/icons-material'

function CommentRateModal({ 
  open, 
  onClose, 
  onSubmit, 
  title = "Comment or rate",
  isSubmitting = false 
}) {
  const [ratings, setRatings] = useState({
    usability: 0,
    stability: 0
  })
  const [comment, setComment] = useState('')

  const handleRatingChange = (category, value) => {
    setRatings(prev => ({
      ...prev,
      [category]: value
    }))
  }

  const handleSubmit = async () => {
    if (onSubmit) {
      await onSubmit({
        ratings,
        comment: comment.trim()
      })
    }
    handleClose()
  }


  const handleClose = () => {
    // Reset form when closing
    setRatings({
      usability: 0,
      stability: 0
    })
    setComment('')
    onClose()
  }

  return (
    <Dialog 
      open={open} 
      onClose={handleClose} 
      maxWidth="sm" 
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: '12px',
          p: 1
        }
      }}
    >
      {/* Custom Dialog Header */}
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        p: 3,
        pb: 2
      }}>
        <Typography variant="h5" sx={{ 
          fontWeight: 'normal',
          color: '#333',
          fontSize: '28px'
        }}>
          {title}
        </Typography>
        <IconButton 
          onClick={handleClose}
          sx={{ 
            color: '#666',
            '&:hover': {
              backgroundColor: '#f5f5f5'
            }
          }}
        >
          <CloseIcon />
        </IconButton>
      </Box>

      <DialogContent sx={{ p: 3, pt: 1 }}>
        {/* Usability Rating */}
        <Box sx={{ mb: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
            <Typography variant="body1" sx={{ 
              color: '#666',
              fontSize: '16px',
              minWidth: '110px'
            }}>
              Rate Usability
            </Typography>
            <Rating
              value={ratings.usability}
              onChange={(event, newValue) => {
                handleRatingChange('usability', newValue)
              }}
              size="large"
              icon={<StarIcon fontSize="inherit" sx={{ color: '#ffc107' }} />}
              emptyIcon={<StarBorderIcon fontSize="inherit" sx={{ color: '#e0e0e0' }} />}
              sx={{
                '& .MuiRating-iconFilled': {
                  color: '#ffc107'
                },
                '& .MuiRating-iconEmpty': {
                  color: '#e0e0e0'
                }
              }}
            />
          </Box>
        </Box>

        {/* Stability Rating */}
        <Box sx={{ mb: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
            <Typography variant="body1" sx={{ 
              color: '#666',
              fontSize: '16px',
              minWidth: '110px'
            }}>
              Rate stability
            </Typography>
            <Rating
              value={ratings.stability}
              onChange={(event, newValue) => {
                handleRatingChange('stability', newValue)
              }}
              size="large"
              icon={<StarIcon fontSize="inherit" sx={{ color: '#ffc107' }} />}
              emptyIcon={<StarBorderIcon fontSize="inherit" sx={{ color: '#e0e0e0' }} />}
              sx={{
                '& .MuiRating-iconFilled': {
                  color: '#ffc107'
                },
                '& .MuiRating-iconEmpty': {
                  color: '#e0e0e0'
                }
              }}
            />
          </Box>
        </Box>

        {/* Message Section */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="body1" sx={{ 
            color: '#666',
            fontSize: '16px',
            mb: 1
          }}>
            Message
          </Typography>
          <TextField
            multiline
            rows={6}
            fullWidth
            placeholder="Add text"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            variant="outlined"
            sx={{
              '& .MuiOutlinedInput-root': {
                borderRadius: '8px',
                backgroundColor: '#fafafa',
                '& fieldset': {
                  borderColor: '#e0e0e0',
                },
                '&:hover fieldset': {
                  borderColor: '#bdbdbd',
                },
                '&.Mui-focused fieldset': {
                  borderColor: '#7c4dff',
                  borderWidth: '2px'
                }
              },
              '& .MuiInputBase-input': {
                fontSize: '16px',
                '&::placeholder': {
                  color: '#999',
                  opacity: 1
                }
              }
            }}
          />
        </Box>
        
      </DialogContent>

      {/* Custom Dialog Actions */}
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'flex-end', 
        gap: 2, 
        p: 3,
        pt: 1
      }}>
        <Button
          onClick={handleClose}
          variant="text"
          sx={{
            color: '#7c4dff',
            fontSize: '16px',
            fontWeight: 'normal',
            textTransform: 'none',
            px: 3,
            py: 1,
            '&:hover': {
              backgroundColor: 'rgba(124, 77, 255, 0.04)'
            }
          }}
        >
          Cancel
        </Button>
        <Button
          onClick={handleSubmit}
          variant="contained"
          disabled={isSubmitting}
          sx={{
            backgroundColor: '#7c4dff',
            color: 'white',
            fontSize: '16px',
            fontWeight: 'normal',
            textTransform: 'none',
            px: 4,
            py: 1,
            borderRadius: '24px',
            boxShadow: '0 4px 12px rgba(124, 77, 255, 0.3)',
            '&:hover': {
              backgroundColor: '#6a3dff',
              boxShadow: '0 6px 16px rgba(124, 77, 255, 0.4)'
            },
            '&:disabled': {
              backgroundColor: '#bdbdbd',
              color: '#fff'
            }
          }}
        >
          {isSubmitting ? 'Rating...' : 'Rate'}
        </Button>
      </Box>
    </Dialog>
  )
}

export default CommentRateModal
