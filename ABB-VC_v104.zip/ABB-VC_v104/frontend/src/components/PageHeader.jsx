import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Box, Typography, Chip, Button } from '@mui/material'
import { LogoutOutlined as LogoutIcon } from '@mui/icons-material'
import { useAuth } from '../contexts/AuthContext'
import { useRequestsContext } from '../contexts/RequestsContext'
import { apiService } from '../services/api'

function PageHeader({ showBreadcrumb = false, breadcrumbItems = [] }) {
  const navigate = useNavigate()
  const { logout, hasPermission, user } = useAuth()
  const { unreadCount, refreshUnreadCount } = useRequestsContext()

  useEffect(() => {
    // Refresh unread count when component mounts
    if (hasPermission && (hasPermission('admin') || user)) {
      refreshUnreadCount(hasPermission, user)
    }
  }, [user, hasPermission, refreshUnreadCount])

  const handleLogout = async () => {
    await logout()
    navigate('/login')
  }

  return (
    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 4 }}>
      {/* Left side - Breadcrumb navigation (if enabled) */}
      {showBreadcrumb ? (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          {breadcrumbItems.map((item, index) => (
            <Box key={index} sx={{ display: 'flex', alignItems: 'center' }}>
              <Typography 
                variant="body2" 
                onClick={item.onClick}
                sx={{ 
                  color: item.active ? '#666' : '#1976d2',
                  fontWeight: item.active ? 500 : 400,
                  cursor: item.onClick ? 'pointer' : 'default',
                  textDecoration: item.onClick && !item.active ? 'underline' : 'none',
                  mr: index === 0 ? 2 : 0,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 0.5,
                  '&:hover': item.onClick && !item.active ? { color: '#1565c0' } : {}
                }}
              >
                {item.icon && item.icon}
                {item.label}
              </Typography>
              {index < breadcrumbItems.length - 1 && (
                <Typography variant="body2" sx={{ color: '#666', mx: 1 }}>|</Typography>
              )}
            </Box>
          ))}
        </Box>
      ) : (
        <Box /> // Empty box to maintain space-between layout
      )}

      {/* Right side - Requests link and Logout button */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 3 }}>
        {/* Requests link */}
        <Typography 
          variant="body2" 
          onClick={() => navigate(hasPermission('admin') ? '/requests-inbox' : '/requests')}
          sx={{ 
            color: '#1976d2',
            cursor: 'pointer',
            textDecoration: 'none',
            '&:hover': { 
              color: '#1565c0',
              textDecoration: 'underline'
            }
          }}
        >
          {hasPermission('admin') ? 'Requests' : 'My Requests'}
          {unreadCount > 0 && (
            <Typography
              component="span"
              variant="body2"
              sx={{
                color: '#1976d2',
                ml: 0.5,
                fontWeight: 500
              }}
            >
              ({unreadCount} new)
            </Typography>
          )}
        </Typography>

        {/* Logout button */}
        <Button
          variant="outlined"
          size="small"
          startIcon={<LogoutIcon />}
          onClick={handleLogout}
          sx={{
            color: '#666',
            borderColor: '#e0e0e0',
            textTransform: 'none',
            minWidth: 'auto',
            px: 2,
            py: 0.5,
            fontSize: '0.875rem',
            '&:hover': {
              borderColor: '#bdbdbd',
              backgroundColor: '#f5f5f5',
              color: '#424242'
            }
          }}
        >
          Logout
        </Button>
      </Box>
    </Box>
  )
}

export default PageHeader
