import { createContext, useContext, useState, useCallback } from 'react'
import { apiService } from '../services/api'

const RequestsContext = createContext()

export const useRequestsContext = () => {
  const context = useContext(RequestsContext)
  if (!context) {
    throw new Error('useRequestsContext must be used within a RequestsProvider')
  }
  return context
}

export const RequestsProvider = ({ children }) => {
  const [unreadCount, setUnreadCount] = useState(0)
  const [isLoading, setIsLoading] = useState(false)

  const refreshUnreadCount = useCallback(async (hasPermission, user) => {
    if (isLoading) return
    
    try {
      setIsLoading(true)
      
      if (hasPermission && hasPermission('admin')) {
        // For admins: count only unread submitted requests
        const response = await apiService.getUnreadRequestsCount()
        const count = response.data?.count || response.count || 0
        setUnreadCount(count)
      } else if (user) {
        // For regular users: count requests with unseen status changes
        const response = await apiService.getStatusChangesCount()
        const count = response.data?.count || response.count || 0
        setUnreadCount(count)
      } else {
        setUnreadCount(0)
      }
    } catch (error) {
      setUnreadCount(0)
    } finally {
      setIsLoading(false)
    }
  }, [isLoading])

  const decrementUnreadCount = useCallback(() => {
    setUnreadCount(prev => Math.max(0, prev - 1))
  }, [])

  const markRequestsAsViewed = useCallback(async () => {
    try {
      await apiService.markRequestsAsViewed()
      setUnreadCount(0)
    } catch (error) {
      // Silently handle marking error
    }
  }, [])

  const value = {
    unreadCount,
    refreshUnreadCount,
    decrementUnreadCount,
    markRequestsAsViewed,
    isLoading
  }

  return (
    <RequestsContext.Provider value={value}>
      {children}
    </RequestsContext.Provider>
  )
}
