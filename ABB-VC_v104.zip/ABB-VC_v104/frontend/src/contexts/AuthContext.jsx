import React, { createContext, useContext, useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { apiService } from '../services/api'

const AuthContext = createContext({})

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const navigate = useNavigate()
  const [user, setUser] = useState(null)
  const [token, setToken] = useState(localStorage.getItem('token'))
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  // Check if user is authenticated on app start
  useEffect(() => {
    checkAuth()
  }, [])

  const checkAuth = async () => {
    try {
      const storedToken = localStorage.getItem('token')
      if (storedToken) {
        setToken(storedToken)
        // Verify token and get user info
        const response = await apiService.getCurrentUser()
        setUser(response.data)
      }
    } catch (error) {
      console.error('Auth check failed:', error)
      logout() // Clear invalid token
    } finally {
      setLoading(false)
    }
  }

  const login = async (email, password) => {
    try {
      setError(null)
      setLoading(true)
      
      const response = await apiService.login(email, password)
      const { user: userData, token: userToken } = response.data
      
      setUser(userData)
      setToken(userToken)
      localStorage.setItem('token', userToken)
      
      return { success: true, user: userData }
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'Login failed'
      setError(errorMessage)
      return { success: false, error: errorMessage }
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    setToken(null)
    localStorage.removeItem('token')
    setError(null)
    
    // Optional: Call logout endpoint
    if (token) {
      apiService.logout().catch(console.error)
    }
    
    // Navigate to login page
    navigate('/login')
  }

  const hasPermission = (permission) => {
    return user?.permissions?.includes(permission) || false
  }

  const hasRole = (role) => {
    return user?.role === role
  }

  const isAdmin = () => {
    return user?.role === 'admin'
  }

  const isRequester = () => {
    return user?.role === 'requester'
  }

  const value = {
    user,
    token,
    loading,
    error,
    login,
    logout,
    hasPermission,
    hasRole,
    isAdmin,
    isRequester,
    isAuthenticated: !!user && !!token,
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}
