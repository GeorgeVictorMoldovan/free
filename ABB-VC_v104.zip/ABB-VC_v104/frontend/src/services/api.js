import axios from 'axios'

const API_BASE_URL = 'http://localhost:3001/api'

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor
api.interceptors.request.use(
  (config) => {
    // Add auth token if available
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor
api.interceptors.response.use(
  (response) => {
    return response.data
  },
  (error) => {
    return Promise.reject(error)
  }
)

// API functions
export const apiService = {
  // Health check
  healthCheck: () => api.get('/health'),

  // Authentication
  login: (email, password) => api.post('/auth/login', { email, password }),
  logout: () => api.post('/auth/logout'),
  getCurrentUser: () => api.get('/auth/me'),
  refreshToken: () => api.post('/auth/refresh'),
  getDemoCredentials: () => api.get('/auth/demo-credentials'),

  // Users
  getUsers: () => api.get('/users'),
  getUserById: (id) => api.get(`/users/${id}`),

  // Applications
  getApplications: (filters = {}) => 
    api.get('/applications', { params: filters }),
  getApplicationById: (id) => api.get(`/applications/${id}`),
  createApplication: (appData) => api.post('/applications', appData),
  updateApplication: (id, appData) => api.put(`/applications/${id}`, appData),
  updateApplicationLifecycle: (id, lifecycle, reason) => api.put(`/applications/${id}/lifecycle`, { lifecycle, reason }),

  // Feedback
  getFeedback: (filters = {}) => 
    api.get('/feedback', { params: filters }),
  submitFeedback: (feedbackData) => api.post('/feedback', feedbackData),

  // Comprehensive Requests System
  getAllRequests: (filters = {}) => 
    api.get('/requests', { params: filters }),
  getRequestById: (id) => api.get(`/requests/${id}`),
  getRequestsByApp: (applicationId) => api.get(`/requests/app/${applicationId}`),
  getRequestsByUser: (userId) => api.get(`/requests/user/${userId}`),
  getRequestStats: () => api.get('/requests/stats'),
  getRequestTypes: () => api.get('/requests/types'),
  submitRequest: (requestData) => api.post('/requests', requestData),
  updateRequestStatus: (id, statusData) => api.put(`/requests/${id}/status`, statusData),
  markRequestAsRead: (id) => api.put(`/requests/${id}/read`),
  getUnreadRequestsCount: () => api.get('/requests/unread'),
  getStatusChangesCount: () => api.get('/requests/status-changes'),
  markRequestsAsViewed: () => api.put('/requests/mark-viewed'),
  deleteRequest: (id) => api.delete(`/requests/${id}`),
  deleteOwnRequest: (id) => api.put(`/requests/${id}/delete`),
  
  // Legacy compatibility (for existing code)
  getRequests: (filters = {}) => 
    api.get('/requests', { params: filters }),

  // Admin
  getApprovals: (filters = {}) => 
    api.get('/admin/approvals', { params: filters }),
  processApproval: (approvalData) => api.post('/admin/approve', approvalData),

  // Stats & Metadata
  getStats: () => api.get('/stats'),
  getMetadata: () => api.get('/metadata'),
}

export default api
